'use client'
import { createStore } from './store'
import { dbStore } from './db'
import { setupStore, authStore } from './session'

export const uiStore = createStore('nexora-ui', () => ({ collapsed: false, mobileOpen: false, copilot: false, profileTab: 'Profile' }), false)
export const useUI = () => uiStore.use()
export const ui = { set: (p: Partial<ReturnType<typeof uiStore.get>>) => uiStore.set((s) => ({ ...s, ...p })) }
export function hydrateAll() { dbStore.hydrate(); setupStore.hydrate(); authStore.hydrate() }
