const BASE = Date.UTC(2026, 9, 8)
const label = (off: number) => new Date(BASE - off * 86400000).toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' })
const wave = (i: number, seed: number) => Math.sin(i * 0.9 + seed) * 0.12 + Math.sin(i * 0.37 + seed * 2) * 0.08

export type Kind = 'orders' | 'revenue' | 'deliveries' | 'fulfillment'
const BASEV: Record<Kind, number> = { orders: 148, revenue: 612000, deliveries: 131, fulfillment: 94 }

export function series(kind: Kind, days: number) {
  const pts = days <= 30 ? days : Math.round(days / 3)
  const step = days / pts
  const seed = { orders: 1, revenue: 2, deliveries: 3, fulfillment: 4 }[kind]
  return Array.from({ length: pts }, (_, i) => {
    const off = Math.round((pts - 1 - i) * step)
    const growth = 1 + (i / pts) * 0.18
    const v = BASEV[kind] * growth * (1 + wave(i, seed)) * (kind === 'fulfillment' ? 0.97 : 1)
    const p = v * (0.88 + wave(i + 3, seed) * 0.4)
    const r = (n: number) => (kind === 'fulfillment' ? Math.min(99.5, Math.round(n * 10) / 10) : Math.round(n))
    return { name: label(off), value: r(v), prev: r(p) }
  })
}
export const spark = (seed: number, up = true) => Array.from({ length: 14 }, (_, i) => Math.round(50 + (up ? i * 2.2 : -i * 1.4) + Math.sin(i * 0.8 + seed) * 8))
export const PERIOD_DAYS: Record<string, number> = { Today: 1, '7 Days': 7, '30 Days': 30, '90 Days': 90, Custom: 14 }
export const PERIOD_MULT: Record<string, number> = { Today: 1, '7 Days': 6.6, '30 Days': 27, '90 Days': 78, Custom: 12 }
export const PERIOD_PREV: Record<string, string> = { Today: 'yesterday', '7 Days': 'prior 7 days', '30 Days': 'prior 30 days', '90 Days': 'prior 90 days', Custom: 'prior range' }
export const monthly = (base: number, n = 6, seed = 1) => Array.from({ length: n }, (_, i) => ({ name: ['May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'].slice(6 - n)[i], value: Math.round(base * (0.8 + i * 0.045 + wave(i, seed))) }))
