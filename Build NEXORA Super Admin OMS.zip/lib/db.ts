'use client'
import { createStore } from './store'
import { seedDB } from '@/data/seed'
import type { Collection, DB, Order, OrderStatus, Shipment } from '@/types'

export const dbStore = createStore<DB>('nexora-db-v1', seedDB)
export const useDB = () => dbStore.use()

type Item = { id: string }
export const db = {
  add<K extends Collection>(k: K, item: DB[K][number], front = true) {
    dbStore.set((s) => ({ ...s, [k]: front ? [item, ...(s[k] as Item[])] : [...(s[k] as Item[]), item] }))
  },
  patch<K extends Collection>(k: K, id: string, p: Partial<DB[K][number]>) {
    dbStore.set((s) => ({ ...s, [k]: (s[k] as Item[]).map((x) => (x.id === id ? { ...x, ...p } : x)) }))
  },
  remove(k: Collection, id: string) {
    dbStore.set((s) => ({ ...s, [k]: (s[k] as Item[]).filter((x) => x.id !== id) }))
  },
  dismissAttention(id: string) { dbStore.set((s) => ({ ...s, dismissedAttention: [...s.dismissedAttention, id] })) },
  reset() { dbStore.reset() },
  log(action: string, module: string, before: string, after: string) {
    dbStore.set((s) => ({ ...s, audit: [{ id: `AUD-${s.audit.length + 1}`, user: 'Aditi Rao', action, module, time: new Date().toISOString().slice(0, 16).replace('T', ' '), device: 'Chrome · This session', before, after }, ...s.audit] }))
  },
  notify(category: string, title: string, body: string, href: string) {
    dbStore.set((s) => ({ ...s, notices: [{ id: `NTF-${Date.now()}`, category, title, body, time: 'just now', read: false, href }, ...s.notices] }))
  },
  setOrderStatus(id: string, to: OrderStatus) {
    const s = dbStore.get()
    const o = s.orders.find((x) => x.id === id)
    if (!o || o.status === to) return
    const before = o.status
    let shipments = s.shipments
    let shipmentId = o.shipmentId
    let inventory = s.inventory
    const adjustRow = (fn: (r: DB['inventory'][number]) => DB['inventory'][number]) => { inventory = inventory.map((r) => (r.sku === o.sku && r.warehouse === o.warehouse ? fn(r) : r)) }
    if (to === 'Allocated') adjustRow((r) => ({ ...r, available: Math.max(0, r.available - o.qty), reserved: r.reserved + o.qty }))
    if (to === 'Shipped' && !shipmentId) {
      shipmentId = `SHP-${58300 + shipments.length}`
      const c = s.customers.find((x) => x.id === o.customerId)
      const sh: Shipment = { id: shipmentId, orderId: o.id, carrier: 'Delhivery', destination: c?.city ?? 'Mumbai', status: 'In Transit', eta: '2026-10-11', sla: 'On track', lastScan: 'Picked up from hub', awb: `AWB${Math.floor(100000 + Math.random() * 899999)}` }
      shipments = [sh, ...shipments]
      adjustRow((r) => ({ ...r, reserved: Math.max(0, r.reserved - o.qty) }))
    }
    if (to === 'Delivered') shipments = shipments.map((x) => (x.orderId === id ? { ...x, status: 'Delivered' } : x))
    if (to === 'Cancelled' && ['Allocated', 'Picking', 'Packed'].includes(before)) adjustRow((r) => ({ ...r, available: r.available + o.qty, reserved: Math.max(0, r.reserved - o.qty) }))
    const stockTxns = to === 'Shipped' ? [{ id: `ST-${Date.now()}`, sku: o.sku, type: 'Outbound' as const, qty: -o.qty, warehouse: o.warehouse, ref: o.id, time: 'just now' }, ...s.stockTxns] : s.stockTxns
    const orders: Order[] = s.orders.map((x) => (x.id === id ? { ...x, status: to, shipmentId } : x))
    dbStore.set({ ...s, orders, shipments, inventory, stockTxns })
    db.log(`Changed order status ${id}`, 'Orders', before, to)
    if (to === 'Shipped') db.notify('Logistics', `${id} shipped`, `Shipment ${shipmentId} created and in transit.`, '/shipment-management/shipment-directory')
  },
  advanceOrder(id: string) {
    const o = dbStore.get().orders.find((x) => x.id === id)
    if (!o) return
    const order: OrderStatus[] = ['New', 'Confirmed', 'Allocated', 'Picking', 'Packed', 'Shipped', 'Delivered']
    const i = order.indexOf(o.status)
    if (i >= 0 && i < order.length - 1) db.setOrderStatus(id, order[i + 1])
    else if (o.status === 'On Hold') db.setOrderStatus(id, 'Confirmed')
  },
}

export const inventoryStatus = (r: { available: number; reorder: number }) => (r.available === 0 ? 'Out of Stock' : r.available <= r.reorder ? 'Low Stock' : 'In Stock')
export const money = (n: number) => `₹${Math.abs(n).toLocaleString('en-IN')}`
export const compact = (n: number) => (n >= 1e7 ? `₹${(n / 1e7).toFixed(2)}Cr` : n >= 1e5 ? `₹${(n / 1e5).toFixed(1)}L` : n >= 1e3 ? `₹${(n / 1e3).toFixed(1)}K` : `₹${n}`)
