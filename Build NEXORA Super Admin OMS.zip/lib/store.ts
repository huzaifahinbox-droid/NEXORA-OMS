'use client'
import { useSyncExternalStore } from 'react'

export function createStore<T extends object>(key: string, init: () => T, persist = true) {
  const seed = init()
  let state = seed
  const subs = new Set<() => void>()
  const emit = () => subs.forEach((f) => f())
  const subscribe = (f: () => void) => { subs.add(f); return () => { subs.delete(f) } }
  return {
    get: () => state,
    set(next: T | ((s: T) => T)) {
      state = typeof next === 'function' ? (next as (s: T) => T)(state) : next
      if (persist) { try { localStorage.setItem(key, JSON.stringify(state)) } catch {} }
      emit()
    },
    hydrate() {
      try {
        const raw = localStorage.getItem(key)
        if (raw) { state = { ...init(), ...JSON.parse(raw) }; emit() }
      } catch {}
    },
    reset() { state = init(); try { localStorage.removeItem(key) } catch {}; emit() },
    use: () => useSyncExternalStore(subscribe, () => state, () => seed),
  }
}
