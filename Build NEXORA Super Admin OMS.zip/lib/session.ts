'use client'
import { createStore } from './store'

export interface SetupWarehouse { id: string; name: string; code: string; address: string; city: string; state: string; country: string; contact: string; capacity: string; hours: string }
export interface Partner { id: string; name: string; service: string; zones: string }
export interface SetupState {
  biz: { name: string; type: string; industry: string; country: string; currency: string; timezone: string; tax: string; logo: string; email: string; phone: string; address: string; city: string; state: string; zip: string }
  channels: Record<string, 'Not connected' | 'Connected' | 'Testing' | 'Verified'>
  warehouses: SetupWarehouse[]
  channelCfg: Record<string, { store: string; key: string }>
  step: number
  inventory: { tracking: string; lowStock: string; backorders: boolean; allowNegative: boolean; autoReorder: boolean; reorderPolicy: string; skuStructure: string; categories: string; units: string; reorder: string; safety: string; batch: boolean; serial: boolean; expiry: boolean; saved: boolean }
  logistics: { partners: Partner[]; zones: string; methods: string; pickup: string; sla: string; tracking: boolean }
  plan: { id: string; cycle: 'Monthly' | 'Yearly' }
  completed: boolean
}
export const initialSetup = (): SetupState => ({
  biz: { name: '', type: '', industry: '', country: 'India', currency: 'INR', timezone: 'Asia/Kolkata', tax: '', logo: '', email: '', phone: '', address: '', city: '', state: '', zip: '' },
  channels: {},
  channelCfg: {},
  step: 1,
  warehouses: [],
  inventory: { tracking: 'SKU', lowStock: '20', backorders: false, allowNegative: false, autoReorder: true, reorderPolicy: 'Min / Max', skuStructure: 'CAT-STYLE-SIZE', categories: 'Apparel, Footwear, Accessories', units: 'Pieces', reorder: '100', safety: '40', batch: false, serial: false, expiry: false, saved: false },
  logistics: { partners: [], zones: 'Metro, Tier 1, Tier 2, Remote', methods: 'Standard, Express', pickup: '', sla: '3', tracking: true },
  plan: { id: 'growth', cycle: 'Monthly' },
  completed: false,
})
export const setupStore = createStore<SetupState>('nexora-setup-v1', initialSetup)
export const useSetup = () => setupStore.use()

export interface AuthState { account: { name: string; email: string; password: string } | null; signedIn: boolean; email: string; resetUsed: boolean; billing: { plan: string; cycle: 'Monthly' | 'Yearly' }; profile: { name: string; email: string; phone: string; role: string; department: string; language: string; timezone: string; dateFormat: string; twoFA: boolean } }
export const DEMO = { email: 'aditi@dtcops.in', password: 'Nexora@2026' }
export const authStore = createStore<AuthState>('nexora-auth-v1', () => ({ account: null, signedIn: false, email: '', resetUsed: false, billing: { plan: 'growth', cycle: 'Monthly' }, profile: { name: 'Aditi Rao', email: 'aditi@dtcops.in', phone: '+91 98765 43210', role: 'Super Admin', department: 'Executive', language: 'English', timezone: 'Asia/Kolkata', dateFormat: 'DD/MM/YYYY', twoFA: true } }))
export const useAuth = () => authStore.use()

export const PLANS = [
  { id: 'starter', name: 'Starter', monthly: 49, yearly: 39, orders: '1,000 / mo', users: '3', warehouses: '1', ai: '500 credits', integrations: '2', support: 'Email' },
  { id: 'growth', name: 'Growth', monthly: 149, yearly: 119, orders: '10,000 / mo', users: '15', warehouses: '3', ai: '5,000 credits', integrations: '6', support: 'Priority chat' },
  { id: 'scale', name: 'Scale', monthly: 449, yearly: 359, orders: '75,000 / mo', users: '60', warehouses: '10', ai: '30,000 credits', integrations: 'Unlimited', support: '24/7 phone' },
  { id: 'enterprise', name: 'Enterprise', monthly: 0, yearly: 0, orders: 'Unlimited', users: 'Unlimited', warehouses: 'Unlimited', ai: 'Custom', integrations: 'Unlimited + SSO', support: 'Dedicated manager' },
]
