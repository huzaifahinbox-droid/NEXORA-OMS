import { Activity, BarChart3, Bell, Boxes, Building2, ClipboardList, CreditCard, FileClock, HelpCircle, LayoutDashboard, LifeBuoy, LineChart, MapPinOff, Package, PackageSearch, Route, Settings, ShoppingCart, Sparkles, Truck, UserCog, Users, Warehouse, Zap, Store, Network, Headphones, Receipt, type LucideIcon } from 'lucide-react'

export const slugify = (s: string) => s.toLowerCase().replace(/&/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')

export interface NavModule { name: string; slug: string; icon: LucideIcon; pages: { name: string; slug: string }[] }
export interface NavLeaf { name: string; href: string; icon: LucideIcon }
export interface NavGroup { label: string; leaves?: NavLeaf[]; modules?: NavModule[] }

const mod = (name: string, icon: LucideIcon, pages: string[]): NavModule => ({ name, slug: slugify(name), icon, pages: pages.map((p) => ({ name: p, slug: slugify(p) })) })

export const NAV: NavGroup[] = [
  { label: 'Command Center', leaves: [{ name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard }, { name: 'AI Insights', href: '/ai-insights', icon: Sparkles }] },
  { label: 'Customer Operations', modules: [mod('Customer Management', Users, ['Overview', 'Customer Directory', 'Customer Segments', 'Customer Activity'])] },
  { label: 'Order Operations', modules: [
    mod('Order Management', ShoppingCart, ['Overview', 'All Orders', 'New Orders', 'Processing Orders', 'On Hold', 'Cancelled Orders', 'Returns']),
    mod('Order Procurement', ClipboardList, ['Overview', 'Procurement Queue', 'Purchase Requests', 'Purchase Orders', 'Approvals', 'Supplier Assignment']),
  ] },
  { label: 'Inventory', modules: [
    mod('Inventory Management', Boxes, ['Overview', 'Stock Overview', 'SKU Catalog', 'Stock Transactions', 'Low Stock', 'Out of Stock', 'Stock Transfers', 'Stock Adjustments']),
    mod('Inventory Forecasting', LineChart, ['Overview', 'Demand Forecast', 'Reorder Recommendations', 'Stock Risk', 'Forecast Accuracy']),
  ] },
  { label: 'Fulfillment', modules: [
    mod('Shipment Management', Package, ['Overview', 'Shipment Directory', 'Tracking', 'Delivery Management']),
    mod('Warehouse Management', Warehouse, ['Overview', 'Warehouse Directory', 'Receiving', 'Putaway', 'Picking', 'Packing', 'Dispatch', 'Warehouse Performance']),
  ] },
  { label: 'Logistics', modules: [
    mod('Logistics Management', Truck, ['Overview', 'Active Shipments', 'In Transit', 'Delivered', 'Delayed', 'Failed Deliveries', 'Carrier Management', 'Tracking']),
    mod('Logistics Actions', Zap, ['Overview', 'Pickup Requests', 'Carrier Actions', 'Delivery Reattempts', 'Escalations', 'Address Changes']),
  ] },
  { label: 'Delivery', modules: [mod('Delivery Not Happening', MapPinOff, ['Overview', 'Delayed Deliveries', 'Failed Deliveries', 'No Movement', 'Address Issues', 'Carrier Exceptions', 'SLA Breaches'])] },
  { label: 'Supply Chain', modules: [
    mod('Supply Chain Management', Network, ['Overview', 'Supply Chain Overview', 'Procurement Flow', 'Supplier Performance', 'Supply Risks', 'Bottlenecks', 'Lead Time Analysis']),
    mod('Vendors', Store, ['Overview', 'Vendor Directory', 'Vendor Performance', 'Products', 'Purchase Orders', 'Contracts', 'Payments', 'Compliance']),
    mod('Buyers', PackageSearch, ['Overview', 'Buyer Directory', 'Purchase Requests', 'Approval Queue', 'Purchase History', 'Spend Analysis']),
  ] },
  { label: 'Customer', modules: [mod('Customer Support', Headphones, ['Overview', 'Support Tickets', 'Open Tickets', 'Pending Tickets', 'Escalated Tickets', 'Resolved Tickets', 'SLA Breaches', 'AI Support'])] },
  { label: 'Finance', modules: [mod('Account & Billing', Receipt, ['Overview', 'Financial Overview', 'Transactions', 'Invoices', 'Payments', 'Refunds', 'Taxes', 'Billing History'])] },
  { label: 'Administration', modules: [mod('User Management', UserCog, ['Overview', 'User Directory', 'Roles & Permissions', 'Pending Invitations', 'Departments', 'Activity'])] },
  { label: 'System', leaves: [{ name: 'Notifications', href: '/notifications', icon: Bell }, { name: 'Audit Logs', href: '/audit-logs', icon: FileClock }, { name: 'Settings', href: '/settings', icon: Settings }] },
]
export const BOTTOM: NavLeaf[] = [{ name: 'Subscription', href: '/subscription', icon: CreditCard }, { name: 'Help & Support', href: '/help-support', icon: LifeBuoy }, { name: 'Profile', href: '/profile', icon: Building2 }]
export const MODULES = NAV.flatMap((g) => g.modules ?? [])
export const findModule = (slug: string) => MODULES.find((m) => m.slug === slug)
export const STATIC_TITLES: Record<string, string> = { '/dashboard': 'Dashboard', '/ai-insights': 'AI Insights', '/notifications': 'Notifications', '/audit-logs': 'Audit Logs', '/settings': 'Settings', '/profile': 'Profile', '/subscription': 'Subscription', '/help-support': 'Help & Support' }
export { Activity, BarChart3, HelpCircle, Route }
