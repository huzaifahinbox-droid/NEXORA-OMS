export type OrderStatus = 'New' | 'Confirmed' | 'Allocated' | 'Picking' | 'Packed' | 'Shipped' | 'Delivered' | 'On Hold' | 'Cancelled' | 'Returned'
export const PIPELINE: OrderStatus[] = ['New', 'Confirmed', 'Allocated', 'Picking', 'Packed', 'Shipped', 'Delivered']

export interface Customer { id: string; name: string; email: string; orders: number; revenue: number; lastOrder: string; segment: 'VIP' | 'High Value' | 'Returning' | 'New' | 'At Risk'; status: 'Active' | 'Inactive'; city: string }
export interface Product { id: string; sku: string; name: string; category: string; price: number; vendorId: string }
export interface InventoryRow { id: string; sku: string; warehouse: string; available: number; reserved: number; incoming: number; reorder: number }
export interface Order { id: string; customerId: string; sku: string; qty: number; total: number; channel: string; status: OrderStatus; date: string; warehouse: string; shipmentId?: string; reason?: string }
export interface Shipment { id: string; orderId: string; carrier: string; destination: string; status: 'Active' | 'In Transit' | 'Delivered' | 'Delayed' | 'Failed' | 'Scheduled' | 'Out for Delivery'; eta: string; sla: string; lastScan: string; issue?: string; awb: string }
export interface Warehouse { id: string; name: string; city: string; state: string; capacity: number; occupancy: number; picking: number; packing: number; dispatch: number; manager: string }
export interface Vendor { id: string; name: string; category: string; products: number; volume: number; leadTime: number; reliability: number; risk: 'Low' | 'Medium' | 'High'; contract: string; compliance: string }
export interface Buyer { id: string; name: string; department: string; categories: string; pending: number; approved: number; spend: number }
export interface PurchaseRequest { id: string; sku: string; qty: number; buyer: string; vendorId: string; value: number; status: 'Pending' | 'Approved' | 'Rejected' | 'Converted'; date: string }
export interface PurchaseOrder { id: string; vendorId: string; sku: string; qty: number; value: number; status: 'Draft' | 'Sent' | 'In Transit' | 'Received' | 'Delayed'; eta: string; date: string }
export interface Ticket { id: string; customer: string; orderId: string; issue: string; priority: 'Low' | 'Medium' | 'High' | 'Urgent'; agent: string; sla: string; status: 'Open' | 'Pending' | 'Escalated' | 'Resolved'; breached: boolean }
export interface User { id: string; name: string; email: string; role: string; department: string; lastActive: string; status: 'Active' | 'Invited' | 'Suspended' }
export interface Notice { id: string; category: string; title: string; body: string; time: string; read: boolean; href: string }
export interface Insight { id: string; area: string; title: string; observation: string; why: string; impact: string; confidence: number; recommendation: string; status: 'New' | 'Applied' | 'Dismissed' | 'Reviewed'; href: string }
export interface Txn { id: string; type: 'Payment' | 'Refund' | 'Fee' | 'Payout'; orderId: string; amount: number; method: string; date: string; status: 'Settled' | 'Pending' | 'Failed' }
export interface Invoice { id: string; party: string; amount: number; tax: number; date: string; due: string; status: 'Paid' | 'Due' | 'Overdue' }
export interface AuditLog { id: string; user: string; action: string; module: string; time: string; device: string; before: string; after: string }
export interface StockTxn { id: string; sku: string; type: 'Inbound' | 'Outbound' | 'Transfer' | 'Adjustment' | 'Return'; qty: number; warehouse: string; ref: string; time: string }
export interface Transfer { id: string; from: string; to: string; sku: string; qty: number; status: 'Requested' | 'In Transit' | 'Completed' }
export interface Adjustment { id: string; sku: string; warehouse: string; qty: number; reason: string; approval: 'Pending' | 'Approved' | 'Rejected'; by: string; time: string }
export interface Action { id: string; kind: string; shipmentId: string; owner: string; priority: 'Low' | 'Medium' | 'High' | 'Critical'; sla: string; status: 'Open' | 'In Progress' | 'Done' }
export interface Dept { id: string; name: string; head: string; members: number }

export interface DB {
  customers: Customer[]; products: Product[]; inventory: InventoryRow[]; orders: Order[]; shipments: Shipment[]
  warehouses: Warehouse[]; vendors: Vendor[]; buyers: Buyer[]; requests: PurchaseRequest[]; pos: PurchaseOrder[]
  tickets: Ticket[]; users: User[]; notices: Notice[]; insights: Insight[]; txns: Txn[]; invoices: Invoice[]
  audit: AuditLog[]; stockTxns: StockTxn[]; transfers: Transfer[]; adjustments: Adjustment[]; actions: Action[]; depts: Dept[]
  dismissedAttention: string[]
}
export type Collection = Exclude<keyof DB, 'dismissedAttention'>
