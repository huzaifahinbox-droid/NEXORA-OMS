import type { DB, Order, OrderStatus, Shipment, InventoryRow } from '@/types'

let s = 7
const rnd = () => ((s = (s * 16807) % 2147483647) / 2147483647)
const pick = <T,>(a: readonly T[]) => a[Math.floor(rnd() * a.length)]
const int = (a: number, b: number) => Math.floor(a + rnd() * (b - a + 1))
const day = (offset: number) => { const d = new Date(Date.UTC(2026, 9, 8)); d.setUTCDate(d.getUTCDate() + offset); return d.toISOString().slice(0, 10) }

export const WAREHOUSE_IDS = ['WH-CHN-01', 'WH-BLR-02', 'WH-DEL-03', 'WH-MUM-04']
export const CARRIERS = ['Delhivery', 'Blue Dart', 'DTDC', 'Ecom Express', 'XpressBees']
export const CHANNELS = ['Shopify', 'Amazon', 'Flipkart', 'WooCommerce', 'POS', 'Manual']
const CITIES = ['Mumbai', 'Delhi', 'Bengaluru', 'Chennai', 'Hyderabad', 'Pune', 'Kolkata', 'Ahmedabad', 'Jaipur', 'Kochi']

const names = ['Aarav Mehta', 'Priya Nair', 'Rohan Kapoor', 'Ananya Iyer', 'Vikram Singh', 'Sneha Reddy', 'Karan Malhotra', 'Isha Gupta', 'Arjun Rao', 'Meera Pillai', 'Rahul Sharma', 'Divya Menon', 'Sanjay Verma', 'Pooja Desai', 'Nikhil Joshi', 'Tara Bose', 'Aditya Khanna', 'Kavya Shetty', 'Manish Agarwal', 'Riya Chatterjee', 'Dev Patel', 'Neha Bhatia', 'Siddharth Jain', 'Lakshmi Narayan', 'Harsh Vora', 'Simran Kaur', 'Varun Saxena', 'Nandini Rao', 'Yash Thakur', 'Zoya Khan']
const segs = ['VIP', 'High Value', 'Returning', 'New', 'At Risk'] as const

const products = ([
  { sku: 'SKU-2048', name: 'Aero Run Sneaker', category: 'Footwear', price: 4999, vendorId: 'VEN-102' },
  { sku: 'SKU-2051', name: 'Trail Pro Boot', category: 'Footwear', price: 6499, vendorId: 'VEN-102' },
  { sku: 'SKU-1107', name: 'Merino Crew Tee', category: 'Apparel', price: 1799, vendorId: 'VEN-104' },
  { sku: 'SKU-1112', name: 'Studio Hoodie', category: 'Apparel', price: 3299, vendorId: 'VEN-104' },
  { sku: 'SKU-1190', name: 'Linen Overshirt', category: 'Apparel', price: 2799, vendorId: 'VEN-107' },
  { sku: 'SKU-3301', name: 'Pulse Wireless Earbuds', category: 'Electronics', price: 5999, vendorId: 'VEN-105' },
  { sku: 'SKU-3315', name: 'Orbit Smartwatch', category: 'Electronics', price: 11999, vendorId: 'VEN-105' },
  { sku: 'SKU-3340', name: 'Volt 20K Power Bank', category: 'Electronics', price: 2499, vendorId: 'VEN-105' },
  { sku: 'SKU-4410', name: 'Canvas Weekender Bag', category: 'Accessories', price: 3899, vendorId: 'VEN-108' },
  { sku: 'SKU-4422', name: 'Leather Card Holder', category: 'Accessories', price: 1299, vendorId: 'VEN-108' },
  { sku: 'SKU-5501', name: 'Steel Insulated Bottle', category: 'Home', price: 1499, vendorId: 'VEN-110' },
  { sku: 'SKU-5512', name: 'Ceramic Pour-Over Set', category: 'Home', price: 2899, vendorId: 'VEN-110' },
]).map((p) => ({ ...p, id: p.sku }))

const customers = names.map((n, i) => ({
  id: `CUS-${3001 + i}`, name: n, email: n.toLowerCase().replace(' ', '.') + '@' + pick(['gmail.com', 'outlook.com', 'zoho.in', 'proton.me']),
  orders: int(1, 24), revenue: int(2, 140) * 1000 + 499, lastOrder: day(-int(0, 60)), segment: segs[i % 5], status: (i % 9 === 8 ? 'Inactive' : 'Active') as 'Active', city: CITIES[i % CITIES.length],
}))

const inventory: InventoryRow[] = []
products.forEach((p, i) => {
  [WAREHOUSE_IDS[i % 4], WAREHOUSE_IDS[(i + 1) % 4]].forEach((w, j) => {
    inventory.push({ id: `INV-${p.sku.slice(4)}-${w.slice(3, 6)}`, sku: p.sku, warehouse: w, available: int(40, 620), reserved: int(5, 60), incoming: j === 0 ? int(0, 300) : 0, reorder: int(60, 160) })
  })
})
const set = (id: string, patch: Partial<InventoryRow>) => {
  const row = inventory.find((r) => r.id === id)
  if (row) return Object.assign(row, patch)
  const [, n, w] = id.split('-')
  const wh = WAREHOUSE_IDS.find((x) => x.slice(3, 6) === w)!
  inventory.push({ id, sku: `SKU-${n}`, warehouse: wh, available: 0, reserved: 0, incoming: 0, reorder: 100, ...patch })
}
set('INV-2048-CHN', { available: 38, reserved: 26, incoming: 0, reorder: 120 })
set('INV-2051-BLR', { available: 0, reserved: 0, incoming: 150, reorder: 80 })
set('INV-3340-DEL', { available: 0, reserved: 0, incoming: 0, reorder: 100 })
set('INV-1112-BLR', { available: 64, reserved: 18, incoming: 0, reorder: 110 })

const statusCycle: OrderStatus[] = ['Packed', 'New', 'Confirmed', 'Allocated', 'Picking', 'Shipped', 'Shipped', 'Delivered', 'Delivered', 'Delivered', 'New', 'Picking', 'On Hold', 'Cancelled', 'Returned']
const orders: Order[] = Array.from({ length: 64 }, (_, i) => {
  let status = statusCycle[i % statusCycle.length]
  if ((status as string) === 'Processing') status = 'Picking'
  const p = i === 0 ? products[0] : pick(products)
  const qty = int(1, 3)
  const o: Order = { id: `ORD-${10482 - i}`, customerId: customers[i % customers.length].id, sku: p.sku, qty, total: p.price * qty, channel: pick(CHANNELS), status, date: day(-Math.floor(i / 3)), warehouse: inventory.find((r) => r.sku === p.sku)!.warehouse }
  if (status === 'On Hold') o.reason = pick(['Payment verification', 'Address mismatch', 'Fraud review'])
  if (status === 'Cancelled') o.reason = pick(['Customer request', 'Out of stock', 'Duplicate order', 'Payment failed'])
  return o
})
orders[0].status = 'Packed'

const shipments: Shipment[] = []
let shipN = 58291
let live = 0
orders.forEach((o, i) => {
  if (o.status !== 'Shipped' && o.status !== 'Delivered') return
  const c = customers.find((x) => x.id === o.customerId)!
  const roll = o.status === 'Shipped' ? [1, 2, 3, 1, 4, 2, 0, 1, 0][live++ % 9] : 0
  const st: Shipment['status'] = o.status === 'Delivered' ? 'Delivered' : roll === 1 ? 'Delayed' : roll === 2 ? 'Failed' : roll === 3 ? 'Out for Delivery' : roll === 4 ? 'Scheduled' : 'In Transit'
  const id = `SHP-${shipN--}`
  o.shipmentId = id
  shipments.push({ id, orderId: o.id, carrier: pick(CARRIERS), destination: c.city, status: st, eta: day(st === 'Delivered' ? -1 : int(0, 4)), sla: st === 'Delayed' || st === 'Failed' ? 'Breached' : pick(['On track', 'On track', 'At risk']), lastScan: pick(['Hub sorted', 'Out from origin', 'Reached destination hub', 'No scan 48h']), awb: `AWB${int(100000, 999999)}`, issue: st === 'Failed' ? pick(['Customer unavailable', 'Address incomplete', 'Refused delivery']) : st === 'Delayed' ? pick(['Carrier exception', 'Weather disruption', 'Hub congestion']) : undefined })
})

const wh = (id: string, name: string, city: string, state: string, cap: number, manager: string) => ({ id, name, city, state, capacity: cap, occupancy: int(52, 91), picking: int(82, 98), packing: int(85, 99), dispatch: int(80, 97), manager })

const vendors = [
  ['VEN-102', 'Stride Footwear Co.', 'Footwear'], ['VEN-104', 'Loomline Textiles', 'Apparel'], ['VEN-105', 'Auralis Electronics', 'Electronics'], ['VEN-107', 'Flaxwood Mills', 'Apparel'], ['VEN-108', 'Heritage Leatherworks', 'Accessories'], ['VEN-110', 'Kiln & Co. Housewares', 'Home'],
].map(([id, name, category], i) => ({ id, name, category, products: int(2, 6), volume: int(8, 60) * 100000, leadTime: int(6, 28), reliability: int(78, 99), risk: (['Low', 'Low', 'Medium', 'High', 'Low', 'Medium'] as const)[i], contract: `Renews ${day(int(30, 400))}`, compliance: pick(['ISO 9001 verified', 'BIS certified', 'Audit due', 'GST verified']) }))

const buyers = ['Anjali Rao|Merchandising', 'Mohit Sethi|Procurement', 'Farah Siddiqui|Merchandising', 'Gautam Nair|Operations', 'Rekha Pillai|Finance'].map((x, i) => { const [name, department] = x.split('|'); return { id: `BUY-${201 + i}`, name, department, categories: pick(['Footwear, Apparel', 'Electronics', 'Home, Accessories', 'Apparel']), pending: int(1, 6), approved: int(10, 60), spend: int(4, 40) * 100000 } })

const requests = Array.from({ length: 10 }, (_, i) => { const p = products[(i * 5) % products.length]; return { id: `PR-${7001 + i}`, sku: p.sku, qty: int(5, 30) * 10, buyer: buyers[i % 5].name, vendorId: p.vendorId, value: int(5, 40) * 10000, status: (['Pending', 'Approved', 'Pending', 'Converted', 'Rejected'] as const)[i % 5], date: day(-i) } })
const pos = Array.from({ length: 10 }, (_, i) => { const p = products[(i * 3) % products.length]; return { id: `PO-${9001 + i}`, vendorId: p.vendorId, sku: p.sku, qty: int(5, 40) * 10, value: int(6, 60) * 10000, status: (['Sent', 'In Transit', 'Delayed', 'Received', 'Draft'] as const)[i % 5], eta: day(int(-2, 14)), date: day(-int(2, 20)) } })

const issues = ['Where is my order?', 'Received wrong size', 'Refund not received', 'Delivery attempted but I was home', 'Damaged packaging', 'Change delivery address']
const tickets = Array.from({ length: 14 }, (_, i) => ({ id: `TCK-${4401 + i}`, customer: customers[i * 2 % 30].name, orderId: orders[i + 3].id, issue: issues[i % 6], priority: (['Low', 'Medium', 'High', 'Urgent'] as const)[i % 4], agent: pick(['Maya Joseph', 'Imran Qureshi', 'Sofia D\'Souza', 'AI Agent']), sla: i % 5 === 4 ? 'Breached' : `${int(1, 22)}h left`, status: (['Open', 'Pending', 'Escalated', 'Resolved', 'Open'] as const)[i % 5], breached: i % 5 === 4 }))

const users = [
  ['Aditi Rao', 'aditi@dtcops.in', 'Super Admin', 'Executive'], ['Rahul Menon', 'rahul@dtcops.in', 'Operations Manager', 'Operations'], ['Sana Sheikh', 'sana@dtcops.in', 'Warehouse Manager', 'Warehouse'], ['Dev Anand', 'dev@dtcops.in', 'Procurement Lead', 'Procurement'], ['Maya Joseph', 'maya@dtcops.in', 'Support Agent', 'Support'], ['Imran Qureshi', 'imran@dtcops.in', 'Support Agent', 'Support'], ['Nisha Kulkarni', 'nisha@dtcops.in', 'Finance Manager', 'Finance'], ['Tarun Bhatt', 'tarun@dtcops.in', 'Logistics Manager', 'Logistics'], ['Leela Fernandes', 'leela@dtcops.in', 'Analyst', 'Operations'],
].map(([name, email, role, department], i) => ({ id: `USR-${i + 1}`, name, email, role, department, lastActive: i === 8 ? '—' : `${int(1, 55)} min ago`, status: (i === 8 ? 'Invited' : i === 6 ? 'Suspended' : 'Active') as 'Active' }))

const notices = [
  ['Inventory', 'SKU-2048 predicted to stock out in 4 days', 'Chennai hub is at 38 units against a reorder point of 120.', '/inventory-management/low-stock'],
  ['Logistics', '12 shipments at risk of SLA breach', 'Delhivery northbound lane showing congestion.', '/delivery-not-happening/sla-breaches'],
  ['Orders', 'ORD-10482 is packed and ready to ship', 'Awaiting dispatch from WH-CHN-01.', '/order-management/processing-orders'],
  ['Procurement', 'PO-9003 delayed by Auralis Electronics', 'New ETA is 6 days later than promised.', '/order-procurement/purchase-orders'],
  ['Warehouse', 'Packing station queue exceeds 40 orders', 'WH-BLR-02 packing efficiency down 6%.', '/warehouse-management/packing'],
  ['Finance', 'Invoice INV-2026-0912 is overdue', 'Kiln & Co. payment is 5 days overdue.', '/account-billing/invoices'],
  ['Security', 'New sign-in from Pune, IN', 'Chrome on macOS signed into your account.', '/profile'],
  ['AI Alerts', 'AI detected an anomaly in return rate', 'Footwear returns up 2.1x week over week.', '/ai-insights'],
].map(([category, title, body, href], i) => ({ id: `NTF-${i + 1}`, category, title, body, time: `${i * 17 + 5} min ago`, read: i > 5, href }))

const ins = (id: string, area: string, title: string, observation: string, why: string, impact: string, confidence: number, recommendation: string, href: string) => ({ id, area, title, observation, why, impact, confidence, recommendation, status: 'New' as const, href })
const insights = [
  ins('AI-1', 'Inventory Risk', 'SKU-2048 stockout predicted in 4 days', 'Chennai hub holds 38 units; daily demand is 11.', 'Sell-through accelerated 42% after the influencer campaign.', '₹6.8L revenue at risk', 91, 'Raise PO for 600 units from Stride Footwear and transfer 80 units from WH-BLR-02.', '/inventory-forecasting/reorder-recommendations'),
  ins('AI-2', 'Delivery Prediction', '12 shipments likely to breach SLA', 'Delhivery northbound lane transit time up 31%.', 'Hub congestion at Gurugram sorting centre.', '12 orders, ₹58K', 86, 'Switch eligible shipments to Blue Dart for the next 48 hours.', '/delivery-not-happening/delayed-deliveries'),
  ins('AI-3', 'Demand Forecast', 'Festive demand uplift of 24% expected', 'Forecast model shows rising search and cart adds.', 'Seasonality plus early festive discounts.', '+₹14L potential revenue', 83, 'Pre-position electronics and footwear in WH-DEL-03.', '/inventory-forecasting/demand-forecast'),
  ins('AI-4', 'Supplier Risk', 'Auralis Electronics lead time drifting', 'Lead time increased from 11 to 19 days in 6 weeks.', 'Component shortage at their upstream supplier.', 'Delays on 3 SKUs', 78, 'Qualify a backup vendor and increase safety stock to 14 days.', '/vendors/vendor-performance'),
  ins('AI-5', 'Warehouse Bottlenecks', 'Packing is the constraint at WH-BLR-02', 'Pick-to-pack wait is 3.4h versus 1.1h target.', 'Two packing stations unstaffed on second shift.', '9% fulfillment drag', 88, 'Reassign 2 pickers to packing between 14:00 and 22:00.', '/warehouse-management/warehouse-performance'),
  ins('AI-6', 'Revenue Forecast', 'October net revenue forecast ₹1.92Cr', 'Tracking 6.2% above September run rate.', 'Higher AOV from bundles and VIP repeat orders.', '+₹11.4L vs plan', 80, 'Hold discount depth; protect margin on top 10 SKUs.', '/account-billing/financial-overview'),
  ins('AI-7', 'Operational Anomalies', 'Footwear returns up 2.1x', 'Return requests for SKU-2051 climbed from 4 to 17 this week.', 'Size chart mismatch referenced in 70% of tickets.', 'Return cost +₹42K', 84, 'Update size guide and pause Amazon listing for SKU-2051.', '/order-management/returns'),
  ins('AI-8', "Today's Intelligence", 'Fulfillment improved 8.4% week over week', 'Faster allocation and fewer holds.', 'Auto-allocation rules shipped Monday.', '+312 orders on time', 92, 'Extend auto-allocation to Flipkart channel.', '/dashboard'),
]

const txns = Array.from({ length: 16 }, (_, i) => ({ id: `TXN-${88001 + i}`, type: (['Payment', 'Payment', 'Refund', 'Fee', 'Payout'] as const)[i % 5], orderId: orders[i + 1].id, amount: orders[i + 1].total * (i % 5 === 2 ? -1 : 1), method: pick(['UPI', 'Card', 'Net Banking', 'COD', 'Wallet']), date: day(-i), status: (['Settled', 'Settled', 'Pending', 'Settled', 'Failed'] as const)[i % 5] }))
const invoices = Array.from({ length: 10 }, (_, i) => ({ id: `INV-2026-09${10 + i}`, party: vendors[i % 6].name, amount: int(8, 80) * 10000, tax: 0, date: day(-i * 4), due: day(-i * 4 + 15), status: (['Paid', 'Due', 'Paid', 'Overdue', 'Paid'] as const)[i % 5] })).map((x) => ({ ...x, tax: Math.round(x.amount * 0.18) }))

const audit = [
  ['Aditi Rao', 'Approved purchase order PO-9002', 'Procurement', 'Draft', 'Approved'], ['Rahul Menon', 'Changed order status ORD-10470', 'Orders', 'Picking', 'Packed'], ['Sana Sheikh', 'Adjusted stock SKU-1112', 'Inventory', '82', '64'], ['Dev Anand', 'Assigned supplier VEN-105', 'Procurement', 'Unassigned', 'VEN-105'], ['Aditi Rao', 'Updated role permissions', 'Users', 'Manager: view', 'Manager: view, edit'], ['Tarun Bhatt', 'Changed carrier for SHP-58288', 'Logistics', 'DTDC', 'Blue Dart'], ['Nisha Kulkarni', 'Issued refund TXN-88003', 'Finance', 'Pending', 'Refunded'], ['Aditi Rao', 'Enabled 2FA enforcement', 'Settings', 'Optional', 'Required'], ['Maya Joseph', 'Escalated ticket TCK-4403', 'Support', 'Open', 'Escalated'], ['Imran Qureshi', 'Resolved ticket TCK-4408', 'Support', 'Pending', 'Resolved'],
].map(([user, action, module, before, after], i) => ({ id: `AUD-${i + 1}`, user, action, module, time: `${day(-Math.floor(i / 3))} ${String(9 + i).padStart(2, '0')}:${String(i * 7 % 60).padStart(2, '0')}`, device: pick(['Chrome · macOS', 'Safari · iOS', 'Edge · Windows', 'Chrome · Linux']), before, after }))

const stockTxns = Array.from({ length: 16 }, (_, i) => ({ id: `ST-${60001 + i}`, sku: products[i % 12].sku, type: (['Inbound', 'Outbound', 'Outbound', 'Transfer', 'Adjustment', 'Return'] as const)[i % 6], qty: int(5, 200) * (i % 6 === 1 || i % 6 === 2 ? -1 : 1), warehouse: WAREHOUSE_IDS[i % 4], ref: i % 3 === 0 ? pos[i % 10].id : orders[i].id, time: `${day(-Math.floor(i / 4))} ${10 + (i % 8)}:${i * 3 % 6}0` }))
const transfers = [['WH-BLR-02', 'WH-CHN-01', 'SKU-2048', 80, 'Requested'], ['WH-DEL-03', 'WH-MUM-04', 'SKU-3301', 120, 'In Transit'], ['WH-CHN-01', 'WH-BLR-02', 'SKU-1107', 200, 'Completed'], ['WH-MUM-04', 'WH-DEL-03', 'SKU-4410', 60, 'In Transit']].map(([from, to, sku, qty, status], i) => ({ id: `TRF-${301 + i}`, from, to, sku, qty, status })) as DB['transfers']
const adjustments = [['SKU-1112', 'WH-BLR-02', -18, 'Damaged in storage', 'Approved'], ['SKU-5501', 'WH-DEL-03', 12, 'Cycle count correction', 'Pending'], ['SKU-4422', 'WH-MUM-04', -4, 'Lost item', 'Pending']].map(([sku, warehouse, qty, reason, approval], i) => ({ id: `ADJ-${501 + i}`, sku, warehouse, qty, reason, approval, by: 'Sana Sheikh', time: `${day(-i)} 11:20` })) as DB['adjustments']

const actionKinds = ['Reattempt delivery', 'Schedule pickup', 'Change carrier', 'Escalate to carrier', 'Update address', 'Contact customer', 'Reattempt delivery', 'Schedule pickup']
const actions = shipments.slice(0, 10).map((sh, i) => ({ id: `ACT-${i + 1}`, kind: actionKinds[i % 8], shipmentId: sh.id, owner: pick(['Tarun Bhatt', 'Rahul Menon', 'Maya Joseph']), priority: (['Critical', 'High', 'Medium', 'Low'] as const)[i % 4], sla: `${int(1, 24)}h`, status: (['Open', 'In Progress', 'Open', 'Done'] as const)[i % 4] }))

export const seedDB = (): DB => ({
  customers, products, inventory, orders, shipments, vendors, buyers, requests, pos, tickets, users, notices, insights, txns, invoices, audit, stockTxns, transfers, adjustments, actions,
  warehouses: [wh('WH-CHN-01', 'Chennai Fulfillment Hub', 'Chennai', 'Tamil Nadu', 48000, 'Sana Sheikh'), wh('WH-BLR-02', 'Bengaluru Fulfillment Hub', 'Bengaluru', 'Karnataka', 36000, 'Praveen Kumar'), wh('WH-DEL-03', 'Delhi NCR Distribution', 'Gurugram', 'Haryana', 60000, 'Anita Sethi'), wh('WH-MUM-04', 'Mumbai Cross-dock', 'Bhiwandi', 'Maharashtra', 28000, 'Jay Parekh')],
  depts: [{ id: 'DEP-1', name: 'Operations', head: 'Rahul Menon', members: 14 }, { id: 'DEP-2', name: 'Warehouse', head: 'Sana Sheikh', members: 38 }, { id: 'DEP-3', name: 'Procurement', head: 'Dev Anand', members: 6 }, { id: 'DEP-4', name: 'Support', head: 'Maya Joseph', members: 12 }, { id: 'DEP-5', name: 'Finance', head: 'Nisha Kulkarni', members: 5 }],
  dismissedAttention: [],
})
