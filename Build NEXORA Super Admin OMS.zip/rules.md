# NEXORA Design System — single source of truth

All screens use these tokens (defined in `styles/globals.css`) and the primitives in `components/ui`. No page-local colors, shadows or radii.

## Colors (CSS variables → Tailwind utilities `bg-surface`, `text-heading`, `border-line` …)
| Token | Light | Dark |
|---|---|---|
| bg | #F5F7FB | #0F172A |
| surface | #FFFFFF | #111827 |
| surface-2 | #F9FAFB | #1E293B |
| hover | #F3F4F6 | #273449 |
| line (border) | #E5E7EB | #334155 |
| line-strong | #D1D5DB | #475569 |
| heading | #111827 | #F8FAFC |
| text | #374151 | #E2E8F0 |
| text-2 | #6B7280 | #94A3B8 |
| muted | #9CA3AF | #64748B |
| primary | #4F46E5 | #6366F1 |
| primary-hover | #4338CA | #818CF8 |
| primary-light | #EEF2FF | #1E1B4B-ish (indigo 18% alpha) |
| purple / blue / cyan | #7C3AED / #2563EB / #0891B2 | lighter tints |
| success / warning / danger / info | text #166534 #92400E #991B1B #1D4ED8 + matching soft backgrounds | light text on translucent backgrounds |

Never pure black. No neon.

## Themes
`Light` (default), `Dark`, `System`. Stored in `localStorage["nexora-theme"]`; applied as `.dark` on `<html>` by an inline pre-hydration script and `ThemeProvider`. Charts read CSS variables so they adapt.

## Typography
Inter (400/500/600/700). Page title 28–32px/700, section 18–22px/600, card title 14–16px/600, body 14–16px, secondary 13–14px, table 13–14px, KPI 26–32px/700, button 14px/500–600.

## Spacing & grid
4px base scale. Content padding 24 (desktop) / 20 (tablet) / 16 (mobile). Cards: 12-col fluid grid, gap 16–24. Radius: 8 inputs/buttons, 12 cards, 16 modals.

## Layout
Sidebar 256px (collapsed 76px), sticky, own scroll. Topbar 72px. Main content scrolls independently. Tablet: sidebar collapsed. Mobile: drawer sidebar, stacked cards, full-screen Copilot.

## Components
- **Card**: surface, 1px line border, radius 12, shadow-xs; hover raises border color only.
- **Button**: primary / secondary / ghost / danger; 36–40px height; loading state shows spinner and disables.
- **Input**: 40px, surface bg, line border, primary focus ring (2px), label above, error text in danger.
- **Table**: 13–14px, sticky header, sortable columns, search, pagination (8/page), row hover.
- **Badge**: soft background + strong text from semantic tokens (success/warning/danger/info/neutral/primary).
- **Modal**: fade + scale 200ms, focus trapped, ESC closes, `role="dialog" aria-modal`.
- **Dropdown**: popover 150ms fade, outside click/ESC closes, chevron rotates.
- **Sidebar**: category labels, every category an accordion with Overview first; active child highlighted, parent auto-expands.
- **Topbar**: breadcrumb, global search, notifications, help, NEXORA AI, profile menu.
- **Charts** (Recharts): palette primary/cyan/purple/blue, hairline grid, tooltip on surface, animated 600–800ms, responsive.

## Accessibility
Semantic landmarks, visible 2px focus ring, aria-labels on icon buttons, labelled form fields, AA contrast, keyboard operable menus and dialogs.

## Animation
150–400ms ease-out: KPI count-up, chart draw, dropdown, chevron rotation, modal, toast, page fade, AI pulse, setup progress. Disabled under `prefers-reduced-motion`.

## States
- **Loading**: skeleton cards/tables/charts (shimmer) shown on first paint of every data page.
- **Empty**: icon + title + description + CTA.
- **Error**: "Something went wrong." / "Unable to load this information." with Retry and Go Back.
