import type { NextConfig } from 'next'

const nextConfig: NextConfig = {
  output: 'export',
  distDir: 'dist',
  trailingSlash: false,
  images: { unoptimized: true },
  allowedDevOrigins: ['*.figma.site', '*.figma.com', '*.figmaiframepreview.com', '*.figma.run'],
}

export default nextConfig
