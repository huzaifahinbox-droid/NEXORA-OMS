'use client'
import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react'
import { dbStore } from '@/lib/db'
import { setupStore, authStore } from '@/lib/session'

export type Theme = 'light' | 'dark' | 'system'
const Ctx = createContext<{ theme: Theme; setTheme: (t: Theme) => void; resolved: 'light' | 'dark' }>({ theme: 'light', setTheme: () => {}, resolved: 'light' })
export const useTheme = () => useContext(Ctx)

export const themeScript = `(function(){try{var t=localStorage.getItem('nexora-theme')||'light';var d=t==='dark'||(t==='system'&&matchMedia('(prefers-color-scheme: dark)').matches);document.documentElement.classList.toggle('dark',d)}catch(e){}})()`

export function Providers({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<Theme>('light')
  const [resolved, setResolved] = useState<'light' | 'dark'>('light')
  const apply = useCallback((t: Theme) => {
    const dark = t === 'dark' || (t === 'system' && matchMedia('(prefers-color-scheme: dark)').matches)
    document.documentElement.classList.toggle('dark', dark)
    setResolved(dark ? 'dark' : 'light')
  }, [])
  useEffect(() => {
    dbStore.hydrate(); setupStore.hydrate(); authStore.hydrate()
    const t = (localStorage.getItem('nexora-theme') as Theme) || 'light'
    setThemeState(t); apply(t)
  }, [apply])
  useEffect(() => {
    if (theme !== 'system') return
    const m = matchMedia('(prefers-color-scheme: dark)')
    const h = () => apply('system')
    m.addEventListener('change', h)
    return () => m.removeEventListener('change', h)
  }, [theme, apply])
  const setTheme = (t: Theme) => { localStorage.setItem('nexora-theme', t); setThemeState(t); apply(t) }
  return <Ctx.Provider value={{ theme, setTheme, resolved }}>{children}</Ctx.Provider>
}
