import Link from 'next/link'
import { ArrowRight, AlertTriangle, PackageX, TrendingUp, Sparkles } from 'lucide-react'
import { cn } from '@/lib/cn'

const STEPS = ['Order Placed', 'Confirmed', 'Inventory Allocated', 'Procurement', 'Warehouse', 'Packed', 'Shipped', 'In Transit', 'Delivered']
const cta = 'inline-flex h-12 items-center justify-center gap-2 rounded-lg px-6 text-sm font-semibold tracking-wide transition-all duration-150 active:scale-[0.98]'

function Workflow() {
  return (
    <div className="overflow-x-auto scroll-thin pb-2">
      <ol className="mx-auto flex min-w-[980px] items-start px-2" aria-label="Order lifecycle">
        {STEPS.map((s, i) => (
          <li key={s} className="flex flex-1 items-start last:flex-none">
            <div className="flex w-[84px] flex-col items-center gap-2 text-center">
              <span className={cn('relative grid size-10 place-items-center rounded-full border text-[13px] font-bold', i === STEPS.length - 1 ? 'border-transparent bg-success-bg text-success' : 'border-primary/40 bg-primary-light text-primary')}>
                {i === 0 && <span className="ai-pulse absolute inset-0 rounded-full" />}
                {i + 1}
              </span>
              <span className="text-[12px] font-medium leading-tight text-heading">{s}</span>
            </div>
            {i < STEPS.length - 1 && (
              <div className="relative mt-5 h-px flex-1" aria-hidden>
                <svg className="absolute inset-0 h-1 w-full overflow-visible" preserveAspectRatio="none"><line x1="0" y1="1" x2="100%" y2="1" className="flow-line" stroke="var(--primary)" strokeWidth="2" strokeOpacity="0.55" /></svg>
                <span className="absolute -top-[3px] size-2 rounded-full bg-purple shadow-[0_0_8px_var(--purple)]" style={{ animation: 'particle 2.4s linear infinite', animationDelay: `${i * 0.28}s` }} />
              </div>
            )}
          </li>
        ))}
      </ol>
    </div>
  )
}

function DashboardPreview() {
  const kpis = [['Orders today', '2,847', '+12.4%'], ['Fulfillment rate', '96.2%', '+8.4%'], ['Inventory value', '$4.8M', '+3.1%'], ['On-time delivery', '94.7%', '+1.9%']]
  const pipe = [['Placed', 82, 'var(--primary)'], ['Allocated', 68, 'var(--purple)'], ['Packed', 54, 'var(--blue)'], ['Shipped', 41, 'var(--cyan)'], ['Delivered', 77, 'var(--success)']] as const
  return (
    <div className="relative mx-auto max-w-5xl">
      <div className="absolute -inset-6 -z-10 rounded-[2rem] bg-gradient-to-tr from-primary/20 via-purple/10 to-cyan/10 blur-2xl" />
      <div className="overflow-hidden rounded-2xl border border-line bg-surface shadow-pop">
        <div className="flex items-center gap-2 border-b border-line bg-surface-2 px-4 py-2.5">
          <span className="size-2.5 rounded-full bg-danger/60" /><span className="size-2.5 rounded-full bg-warning/60" /><span className="size-2.5 rounded-full bg-success/60" />
          <span className="ml-3 rounded-md bg-hover px-3 py-0.5 text-[11px] text-text-2">app.nexora.io/dashboard</span>
        </div>
        <div className="grid gap-4 bg-bg p-4 sm:p-5">
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            {kpis.map(([l, v, d]) => (
              <div key={l} className="rounded-xl border border-line bg-surface p-3.5">
                <p className="text-[11px] text-text-2">{l}</p>
                <p className="mt-1 text-xl font-bold text-heading sm:text-2xl">{v}</p>
                <p className="mt-0.5 text-[11px] font-medium text-success">{d}</p>
              </div>
            ))}
          </div>
          <div className="grid gap-3 lg:grid-cols-5">
            <div className="rounded-xl border border-line bg-surface p-4 lg:col-span-3">
              <div className="mb-2 flex items-center justify-between"><p className="text-[13px] font-semibold text-heading">Order volume</p><span className="text-[11px] text-text-2">Last 14 days</span></div>
              <svg viewBox="0 0 400 130" className="h-32 w-full" role="img" aria-label="Order volume trend rising">
                <defs><linearGradient id="hg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="var(--primary)" stopOpacity="0.35" /><stop offset="1" stopColor="var(--primary)" stopOpacity="0" /></linearGradient></defs>
                {[20, 55, 90].map((y) => <line key={y} x1="0" x2="400" y1={y} y2={y} stroke="var(--chart-grid)" />)}
                <path d="M0 100 C40 92 60 70 100 74 S160 50 200 56 S260 30 300 38 S360 14 400 18 V130 H0Z" fill="url(#hg)" />
                <path d="M0 100 C40 92 60 70 100 74 S160 50 200 56 S260 30 300 38 S360 14 400 18" fill="none" stroke="var(--primary)" strokeWidth="2.5" strokeLinecap="round" />
                <path d="M0 112 C60 108 100 96 160 98 S280 80 400 70" fill="none" stroke="var(--cyan)" strokeWidth="2" strokeDasharray="4 4" />
              </svg>
            </div>
            <div className="rounded-xl border border-line bg-surface p-4 lg:col-span-2">
              <p className="mb-3 text-[13px] font-semibold text-heading">Fulfillment pipeline</p>
              <div className="space-y-2.5">
                {pipe.map(([l, v, c]) => (
                  <div key={l} className="flex items-center gap-3 text-[11px] text-text-2"><span className="w-16">{l}</span><div className="h-2 flex-1 overflow-hidden rounded-full bg-hover"><div className="h-full rounded-full" style={{ width: `${v}%`, background: c }} /></div><span className="w-6 text-right tabular-nums text-heading">{v}</span></div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
      <FloatCard className="-left-2 top-16 sm:-left-8" icon={AlertTriangle} tone="bg-warning-bg text-warning" text="12 shipments at risk" delay="0s" />
      <FloatCard className="-right-2 top-1/3 sm:-right-8" icon={PackageX} tone="bg-danger-bg text-danger" text="SKU-2048 stockout predicted" delay="1.2s" />
      <FloatCard className="-bottom-5 left-6 sm:left-1/4" icon={TrendingUp} tone="bg-success-bg text-success" text="Fulfillment increased 8.4%" delay="2.2s" />
    </div>
  )
}

function FloatCard({ className, icon: Icon, tone, text, delay }: { className: string; icon: typeof Sparkles; tone: string; text: string; delay: string }) {
  return (
    <div className={cn('anim-float absolute z-10 flex items-center gap-2.5 rounded-xl border border-line bg-surface px-3 py-2 shadow-pop', className)} style={{ animationDelay: delay }}>
      <span className={cn('grid size-7 place-items-center rounded-lg', tone)}><Icon size={14} /></span>
      <span className="text-xs font-semibold text-heading">{text}</span>
    </div>
  )
}

export function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div aria-hidden className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[620px] bg-[radial-gradient(60%_60%_at_50%_0%,var(--primary-light),transparent)]" />
      <div className="mx-auto max-w-7xl px-4 pb-20 pt-16 sm:px-6 sm:pt-24">
        <div className="mx-auto max-w-3xl text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-line bg-surface px-3 py-1 text-xs font-medium text-text"><Sparkles size={13} className="text-primary" />AI-native order management</span>
          <h1 className="mt-6 text-4xl font-bold leading-[1.08] tracking-tight text-heading sm:text-6xl">One intelligent command center for <span className="bg-gradient-to-r from-primary to-purple bg-clip-text text-transparent">every order.</span></h1>
          <p className="mx-auto mt-5 max-w-2xl text-base text-text-2 sm:text-lg">Connect orders, procurement, inventory, warehouses, logistics, supply chain and customer operations through one intelligent enterprise platform.</p>
          <div className="mt-8 flex flex-col items-stretch justify-center gap-3 sm:flex-row sm:items-center">
            <Link href="/business-setup" className={cn(cta, 'bg-primary text-white shadow-xs hover:bg-primary-hover')}>GET STARTED <ArrowRight size={16} /></Link>
            <Link href="/book-demo" className={cn(cta, 'border border-line-strong bg-surface text-heading hover:bg-hover')}>BOOK A DEMO</Link>
            <Link href="/login" className={cn(cta, 'text-heading hover:bg-hover')}>SIGN IN</Link>
          </div>
        </div>
        <div className="mt-14"><Workflow /></div>
        <div className="mt-12 px-1 sm:px-8"><DashboardPreview /></div>
      </div>
    </section>
  )
}
