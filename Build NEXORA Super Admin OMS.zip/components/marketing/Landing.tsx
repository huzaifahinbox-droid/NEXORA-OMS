import Link from 'next/link'
import { ArrowRight, Calendar, ClipboardList, Link2, Rocket, Zap } from 'lucide-react'
import { Logo } from '@/components/layout/Sidebar'
import { cn } from '@/lib/cn'
import { Header } from './Header'
import { Hero } from './Hero'
import { Reveal } from './Reveal'
import { Pricing } from './Pricing'
import * as V from './Visuals'

const MODULES: { id: string; eyebrow: string; title: string; body: string; points: string[]; visual: React.ReactNode }[] = [
  { id: 'unified-oms', eyebrow: 'Unified OMS', title: 'Every channel, one order brain', body: 'Pull storefront, marketplace and B2B orders into a single real-time ledger with routing rules that run themselves.', points: ['Omnichannel order capture', 'Smart sourcing and routing', 'One source of truth'], visual: <V.OmsHub /> },
  { id: 'order-management', eyebrow: 'Order Management', title: 'Track every order from click to doorstep', body: 'Hold, split, edit and fulfil orders with full audit trails and exception handling built in.', points: ['Bulk actions and filters', 'Returns and refunds', 'Exception alerts'], visual: <V.OrdersTable /> },
  { id: 'procurement', eyebrow: 'Procurement', title: 'Purchase orders with guardrails', body: 'Turn stock signals into approved purchase orders and match receipts to invoices without spreadsheets.', points: ['Approval workflows', 'Auto reorder suggestions', 'Three-way matching'], visual: <V.PoFlow /> },
  { id: 'inventory-management', eyebrow: 'Inventory Management', title: 'Know what you have, everywhere', body: 'Live stock across every warehouse with reorder points, safety stock, batch and serial tracking.', points: ['Multi-location stock', 'Batch, serial and expiry', 'Cycle counts'], visual: <V.StockBars /> },
  { id: 'inventory-forecasting', eyebrow: 'Inventory Forecasting', title: 'See demand before it arrives', body: 'AI models learn seasonality and promotions to forecast demand and recommend purchase quantities.', points: ['SKU-level forecasts', 'Stockout prediction', 'Confidence bands'], visual: <V.ForecastChart /> },
  { id: 'warehouse', eyebrow: 'Warehouse', title: 'Faster picks, fewer mistakes', body: 'Directed picking, bin management and packing stations that keep every warehouse moving.', points: ['Wave and batch picking', 'Bin heatmaps', 'Pack verification'], visual: <V.BinMap /> },
  { id: 'logistics', eyebrow: 'Logistics', title: 'Right carrier, right route, right cost', body: 'Rate-shop across carriers, print labels and track every shipment with proactive delay alerts.', points: ['Carrier rate shopping', 'Live tracking', 'SLA monitoring'], visual: <V.RouteMap /> },
  { id: 'supply-chain', eyebrow: 'Supply Chain', title: 'A network that flexes with you', body: 'Visualize flows from suppliers to customers and rebalance inventory before disruption hits.', points: ['Network visibility', 'Inter-warehouse transfers', 'Risk monitoring'], visual: <V.Network /> },
  { id: 'vendors', eyebrow: 'Vendors', title: 'Hold suppliers to a higher standard', body: 'Scorecards on lead time, quality and cost help you negotiate and choose with confidence.', points: ['Performance scoring', 'Contracts and terms', 'Vendor portal'], visual: <V.VendorCards /> },
  { id: 'customer-support', eyebrow: 'Customer Support', title: 'Answers grounded in live order data', body: 'Support teams see the full order, shipment and refund context beside every ticket.', points: ['Unified inbox', 'AI drafted replies', 'Refund workflows'], visual: <V.SupportThread /> },
  { id: 'ai-insights', eyebrow: 'AI Insights', title: 'A copilot that watches operations 24/7', body: 'NEXORA AI surfaces risks and opportunities, explains why, and takes action with one click.', points: ['Proactive alerts', 'Natural language queries', 'One-click actions'], visual: <V.CopilotPanel /> },
  { id: 'analytics', eyebrow: 'Analytics', title: 'Dashboards your whole team trusts', body: 'Revenue, margin, fulfillment and cost-to-serve analytics from the same data that runs operations.', points: ['Custom reports', 'Scheduled exports', 'Channel profitability'], visual: <V.AnalyticsCharts /> },
]

const STEPS = [
  { icon: Link2, t: 'Connect', d: 'Link channels, warehouses and carriers in minutes.' },
  { icon: ClipboardList, t: 'Configure', d: 'Set routing, reorder rules and approval workflows.' },
  { icon: Zap, t: 'Automate', d: 'Let NEXORA orchestrate orders end to end.' },
  { icon: Rocket, t: 'Optimize', d: 'Use AI insights to cut cost and delivery time.' },
]

const FOOT = [
  { h: 'Product', l: [['Unified OMS', '/#unified-oms'], ['Procurement', '/#procurement'], ['Inventory', '/#inventory-management'], ['Warehouse', '/#warehouse'], ['Logistics', '/#logistics']] },
  { h: 'Platform', l: [['AI Insights', '/#ai-insights'], ['Analytics', '/#analytics'], ['Vendors', '/#vendors'], ['Customer Support', '/#customer-support'], ['Pricing', '/#pricing']] },
  { h: 'Company', l: [['How it works', '/#how-it-works'], ['Book a Demo', '/book-demo'], ['Get Started', '/business-setup'], ['Sign In', '/login']] },
]

export function Landing() {
  return (
    <div className="min-h-screen bg-bg">
      <Header />
      <main>
        <Hero />
        {MODULES.map((m, i) => (
          <section key={m.id} id={m.id} className={cn('scroll-mt-20 py-16 sm:py-24', i % 2 === 1 && 'border-y border-line bg-surface-2/60')}>
            <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 sm:px-6 lg:grid-cols-2 lg:gap-16">
              <Reveal className={i % 2 === 1 ? 'lg:order-2' : ''}>
                <p className="text-xs font-semibold uppercase tracking-[0.14em] text-primary">{m.eyebrow}</p>
                <h2 className="mt-3 text-3xl font-bold tracking-tight text-heading sm:text-4xl">{m.title}</h2>
                <p className="mt-4 text-base text-text-2">{m.body}</p>
                <ul className="mt-6 space-y-2.5">{m.points.map((p) => <li key={p} className="flex items-center gap-3 text-sm text-heading"><span className="size-1.5 rounded-full bg-gradient-to-br from-primary to-purple" />{p}</li>)}</ul>
              </Reveal>
              <Reveal delay={120}>{m.visual}</Reveal>
            </div>
          </section>
        ))}

        <section id="how-it-works" className="scroll-mt-20 py-20 sm:py-28">
          <div className="mx-auto max-w-7xl px-4 sm:px-6">
            <Reveal className="mx-auto max-w-2xl text-center"><p className="text-xs font-semibold uppercase tracking-[0.14em] text-primary">How it works</p><h2 className="mt-3 text-3xl font-bold tracking-tight text-heading sm:text-4xl">Live in days, not quarters</h2></Reveal>
            <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {STEPS.map((s, i) => (
                <Reveal key={s.t} delay={i * 90}>
                  <div className="h-full rounded-2xl border border-line bg-surface p-6 shadow-xs">
                    <div className="flex items-center justify-between"><span className="grid size-11 place-items-center rounded-xl bg-primary-light text-primary"><s.icon size={20} /></span><span className="text-3xl font-bold text-line-strong">0{i + 1}</span></div>
                    <h3 className="mt-5 text-lg font-semibold text-heading">{s.t}</h3><p className="mt-1.5 text-sm text-text-2">{s.d}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        <section id="pricing" className="scroll-mt-20 border-y border-line bg-surface-2/60 py-20 sm:py-28">
          <div className="mx-auto max-w-7xl px-4 sm:px-6">
            <Reveal className="mx-auto mb-8 max-w-2xl text-center"><p className="text-xs font-semibold uppercase tracking-[0.14em] text-primary">Pricing</p><h2 className="mt-3 text-3xl font-bold tracking-tight text-heading sm:text-4xl">Plans that scale with your orders</h2><p className="mt-3 text-text-2">Save 20% with yearly billing. Change plans anytime.</p></Reveal>
            <Reveal><Pricing /></Reveal>
          </div>
        </section>

        <section id="demo" className="scroll-mt-20 py-20 sm:py-28">
          <Reveal className="mx-auto max-w-5xl px-4 sm:px-6">
            <div className="grid items-center gap-8 rounded-3xl border border-line bg-surface p-8 shadow-xs sm:p-12 md:grid-cols-2">
              <div><span className="grid size-12 place-items-center rounded-xl bg-primary-light text-primary"><Calendar size={22} /></span><h2 className="mt-5 text-3xl font-bold tracking-tight text-heading">See NEXORA on your own data</h2><p className="mt-3 text-text-2">Book a 30 minute walkthrough with an operations specialist and get a tailored rollout plan.</p></div>
              <div className="space-y-3">
                {['Personalized product tour', 'Integration and migration plan', 'Pricing for your volume'].map((t) => <p key={t} className="rounded-xl bg-surface-2 px-4 py-3 text-sm text-heading">{t}</p>)}
                <Link href="/book-demo" className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-lg bg-primary text-sm font-semibold text-white hover:bg-primary-hover">Book a Demo <ArrowRight size={16} /></Link>
              </div>
            </div>
          </Reveal>
        </section>

        <section className="px-4 pb-20 sm:px-6 sm:pb-28">
          <Reveal className="mx-auto max-w-5xl overflow-hidden rounded-3xl bg-gradient-to-br from-primary via-primary to-purple px-6 py-16 text-center text-white sm:px-12">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Run every order from one command center</h2>
            <p className="mx-auto mt-3 max-w-xl text-white/80">Start free setup in minutes. No credit card required.</p>
            <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
              <Link href="/business-setup" className="inline-flex h-12 items-center justify-center rounded-lg bg-white px-6 text-sm font-semibold text-slate-900 hover:bg-white/90">GET STARTED</Link>
              <Link href="/login" className="inline-flex h-12 items-center justify-center rounded-lg border border-white/40 px-6 text-sm font-semibold text-white hover:bg-white/10">SIGN IN</Link>
            </div>
          </Reveal>
        </section>
      </main>

      <footer className="border-t border-line bg-surface">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-5">
          <div className="md:col-span-2"><Link href="/" aria-label="NEXORA home"><Logo /></Link><p className="mt-4 max-w-xs text-sm text-text-2">The intelligent command center for orders, inventory and fulfillment.</p></div>
          {FOOT.map((c) => (
            <nav key={c.h} aria-label={c.h}><p className="text-sm font-semibold text-heading">{c.h}</p><ul className="mt-4 space-y-2.5">{c.l.map(([l, h]) => <li key={l}><Link href={h} className="text-sm text-text-2 hover:text-heading">{l}</Link></li>)}</ul></nav>
          ))}
        </div>
        <div className="border-t border-line py-5 text-center text-xs text-text-2">© 2026 NEXORA. All rights reserved.</div>
      </footer>
    </div>
  )
}
