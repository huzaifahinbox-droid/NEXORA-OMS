import { Bot, Boxes, Check, Globe, MessageSquare, Send, ShoppingBag, Sparkles, Store, Truck, Warehouse as WH } from 'lucide-react'
import { cn } from '@/lib/cn'
import { Badge } from '@/components/ui/core'

const Frame = ({ children, className }: { children: React.ReactNode; className?: string }) => <div className={cn('rounded-2xl border border-line bg-surface p-5 shadow-xs', className)}>{children}</div>
const Title = ({ children, right }: { children: React.ReactNode; right?: React.ReactNode }) => <div className="mb-4 flex items-center justify-between"><p className="text-sm font-semibold text-heading">{children}</p>{right}</div>

export function OmsHub() {
  const nodes = [[ShoppingBag, 'Storefront', 'left-2 top-4'], [Store, 'Marketplaces', 'right-2 top-4'], [Globe, 'B2B Portal', 'left-2 bottom-4'], [Truck, 'Carriers', 'right-2 bottom-4']] as const
  return (
    <Frame className="relative h-72 overflow-hidden">
      <svg className="absolute inset-0 h-full w-full" aria-hidden>
        {[['18%', '22%'], ['82%', '22%'], ['18%', '78%'], ['82%', '78%']].map(([x, y], i) => <line key={i} x1={x} y1={y} x2="50%" y2="50%" stroke="var(--primary)" strokeOpacity="0.5" strokeWidth="2" className="flow-line" />)}
      </svg>
      <div className="absolute left-1/2 top-1/2 grid size-20 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-2xl bg-gradient-to-br from-primary to-purple text-white ai-pulse"><Boxes size={32} /></div>
      {nodes.map(([I, l, pos]) => <div key={l} className={cn('absolute flex items-center gap-2 rounded-xl border border-line bg-surface-2 px-3 py-2 text-xs font-medium text-heading', pos)}><I size={14} className="text-primary" />{l}</div>)}
    </Frame>
  )
}

export function OrdersTable() {
  const rows = [['#10482', 'Aarav Mehta', '$248.00', 'Confirmed'], ['#10481', 'Northwind Co.', '$1,920.00', 'Packed'], ['#10480', 'Isha Kapoor', '$86.50', 'In Transit'], ['#10479', 'Zenith Retail', '$4,310.00', 'Delayed'], ['#10478', 'Rohan Das', '$129.00', 'Delivered']]
  return (
    <Frame className="p-0">
      <div className="p-5 pb-3"><Title right={<Badge tone="primary">Live</Badge>}>Orders</Title></div>
      <div className="divide-y divide-line border-t border-line text-[13px]">
        {rows.map(([id, n, a, s]) => <div key={id} className="grid grid-cols-[64px_1fr_auto] items-center gap-3 px-5 py-2.5 sm:grid-cols-[64px_1fr_90px_auto]"><span className="font-medium text-primary">{id}</span><span className="truncate text-heading">{n}</span><span className="hidden text-right tabular-nums text-text sm:block">{a}</span>
          <Badge tone={s === 'Delayed' ? 'danger' : s === 'Delivered' ? 'success' : s === 'Confirmed' ? 'warning' : 'info'} dot>{s}</Badge></div>)}
      </div>
    </Frame>
  )
}

export function PoFlow() {
  const steps = [['Requisition', true], ['Manager approval', true], ['PO sent to vendor', true], ['Goods receipt', false], ['3-way match', false]] as const
  return (
    <Frame>
      <Title right={<span className="text-xs text-text-2">PO-7741</span>}>Purchase order</Title>
      <ol className="relative space-y-4 pl-8">
        <span className="absolute bottom-2 left-[11px] top-2 w-px bg-line-strong" />
        {steps.map(([s, d]) => <li key={s} className="relative text-sm"><span className={cn('absolute -left-8 grid size-6 place-items-center rounded-full border', d ? 'border-transparent bg-primary text-white' : 'border-line-strong bg-surface text-muted')}>{d ? <Check size={13} /> : null}</span><span className={d ? 'text-heading' : 'text-text-2'}>{s}</span></li>)}
      </ol>
      <div className="mt-5 flex items-center justify-between rounded-lg bg-surface-2 px-3 py-2 text-xs text-text-2"><span>Total value</span><span className="font-semibold text-heading">$18,240.00</span></div>
    </Frame>
  )
}

export function StockBars() {
  const items = [['SKU-1001 Tee', 82, 'success'], ['SKU-2048 Sneaker', 14, 'danger'], ['SKU-3310 Cap', 46, 'warning'], ['SKU-4120 Hoodie', 68, 'success'], ['SKU-5207 Bag', 31, 'warning']] as const
  const col = { success: 'bg-success', warning: 'bg-warning', danger: 'bg-danger' }
  return (
    <Frame>
      <Title right={<Badge tone="danger" dot>1 low</Badge>}>Stock levels</Title>
      <div className="space-y-3.5">{items.map(([n, v, t]) => <div key={n}><div className="mb-1 flex justify-between text-xs"><span className="text-heading">{n}</span><span className="tabular-nums text-text-2">{v * 12} units</span></div><div className="h-2 rounded-full bg-hover"><div className={cn('h-full rounded-full', col[t])} style={{ width: `${v}%` }} /></div></div>)}</div>
    </Frame>
  )
}

export function ForecastChart() {
  return (
    <Frame>
      <Title right={<Badge tone="primary"><Sparkles size={11} />AI forecast</Badge>}>Demand · next 8 weeks</Title>
      <svg viewBox="0 0 400 170" className="w-full" role="img" aria-label="Demand forecast with confidence band">
        {[30, 80, 130].map((y) => <line key={y} x1="0" x2="400" y1={y} y2={y} stroke="var(--chart-grid)" />)}
        <path d="M220 70 C260 60 300 50 400 30 V100 C300 110 260 100 220 90Z" fill="var(--purple)" fillOpacity="0.18" />
        <path d="M0 120 C40 110 70 100 100 105 S160 80 220 80" fill="none" stroke="var(--primary)" strokeWidth="2.5" />
        <path d="M220 80 C260 78 300 62 400 62" fill="none" stroke="var(--purple)" strokeWidth="2.5" strokeDasharray="6 5" className="flow-line" />
        <line x1="220" x2="220" y1="10" y2="160" stroke="var(--line-strong)" strokeDasharray="3 3" />
        <circle cx="220" cy="80" r="4" fill="var(--primary)" />
        <text x="226" y="22" fontSize="10" fill="var(--text-2)">Today</text>
      </svg>
      <div className="mt-2 flex gap-4 text-xs text-text-2"><span className="flex items-center gap-1.5"><i className="h-0.5 w-4 bg-primary" />Actual</span><span className="flex items-center gap-1.5"><i className="h-0.5 w-4 bg-purple" />Forecast</span></div>
    </Frame>
  )
}

export function BinMap() {
  const cells = Array.from({ length: 40 }, (_, i) => (i * 7 + (i % 5) * 3) % 10)
  const tone = (v: number) => (v > 7 ? 'bg-primary' : v > 4 ? 'bg-primary/50' : v > 1 ? 'bg-primary/20' : 'bg-hover')
  return (
    <Frame>
      <Title right={<span className="flex items-center gap-1 text-xs text-text-2"><WH size={13} />Zone A · Mumbai DC</span>}>Bin utilization</Title>
      <div className="grid grid-cols-8 gap-1.5">{cells.map((v, i) => <span key={i} className={cn('aspect-square rounded-md', tone(v))} />)}</div>
      <div className="mt-4 grid grid-cols-3 gap-2 text-center text-xs"><div className="rounded-lg bg-surface-2 py-2"><p className="font-bold text-heading">142</p><p className="text-text-2">Picks / hr</p></div><div className="rounded-lg bg-surface-2 py-2"><p className="font-bold text-heading">78%</p><p className="text-text-2">Capacity</p></div><div className="rounded-lg bg-surface-2 py-2"><p className="font-bold text-heading">99.4%</p><p className="text-text-2">Accuracy</p></div></div>
    </Frame>
  )
}

export function RouteMap() {
  return (
    <Frame>
      <Title right={<Badge tone="info" dot>In transit</Badge>}>Shipment AWB-88213</Title>
      <svg viewBox="0 0 400 170" className="w-full rounded-xl bg-surface-2" role="img" aria-label="Shipment route">
        {Array.from({ length: 9 }).map((_, i) => <line key={i} x1={i * 50} x2={i * 50} y1="0" y2="170" stroke="var(--chart-grid)" strokeOpacity="0.6" />)}
        <path d="M40 130 C110 130 110 50 190 60 S300 120 360 36" fill="none" stroke="var(--primary)" strokeWidth="2.5" strokeDasharray="6 6" className="flow-line" />
        {[[40, 130], [190, 60], [360, 36]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r="7" fill={i === 2 ? 'var(--surface)' : 'var(--primary)'} stroke="var(--primary)" strokeWidth="2.5" />)}
        <circle cx="190" cy="60" r="12" fill="var(--primary)" fillOpacity="0.2" className="ai-pulse" />
      </svg>
      <div className="mt-3 flex flex-wrap gap-2 text-xs"><Badge tone="neutral">Delhivery</Badge><Badge tone="neutral">BlueDart</Badge><Badge tone="neutral">DHL</Badge><span className="ml-auto text-text-2">ETA Oct 12</span></div>
    </Frame>
  )
}

export function Network() {
  const col = (x: number, ys: number[], c: string) => ys.map((y) => <circle key={`${x}${y}`} cx={x} cy={y} r="9" fill={c} />)
  const sup = [30, 85, 140], dc = [55, 115], cu = [25, 70, 115, 155]
  return (
    <Frame>
      <Title>Supply network</Title>
      <svg viewBox="0 0 400 180" className="w-full" role="img" aria-label="Supplier to warehouse to customer network">
        {sup.flatMap((a) => dc.map((b) => <line key={`a${a}${b}`} x1="60" y1={a} x2="200" y2={b} stroke="var(--primary)" strokeOpacity="0.4" className="flow-line" />))}
        {dc.flatMap((a) => cu.map((b) => <line key={`b${a}${b}`} x1="200" y1={a} x2="340" y2={b} stroke="var(--purple)" strokeOpacity="0.4" className="flow-line" />))}
        {col(60, sup, 'var(--cyan)')}{col(200, dc, 'var(--primary)')}{col(340, cu, 'var(--purple)')}
        {[['Suppliers', 60], ['Warehouses', 200], ['Customers', 340]].map(([l, x]) => <text key={l} x={x as number} y="176" fontSize="10" textAnchor="middle" fill="var(--text-2)">{l}</text>)}
      </svg>
    </Frame>
  )
}

export function VendorCards() {
  const v = [['Apex Textiles', 96, 'success'], ['Lumen Packaging', 88, 'primary'], ['Orbit Components', 71, 'warning']] as const
  return (
    <Frame>
      <Title>Vendor scorecards</Title>
      <div className="space-y-3">
        {v.map(([n, s, t]) => {
          const c = 2 * Math.PI * 16
          return (
            <div key={n} className="flex items-center gap-4 rounded-xl border border-line bg-surface-2 p-3">
              <svg viewBox="0 0 40 40" className="size-12 -rotate-90"><circle cx="20" cy="20" r="16" fill="none" stroke="var(--line)" strokeWidth="4" /><circle cx="20" cy="20" r="16" fill="none" stroke="var(--primary)" strokeWidth="4" strokeLinecap="round" strokeDasharray={`${(c * s) / 100} ${c}`} /></svg>
              <div className="min-w-0 flex-1"><p className="truncate text-sm font-medium text-heading">{n}</p><p className="text-xs text-text-2">On-time {s}% · Quality {s - 2}%</p></div>
              <Badge tone={t}>{s}</Badge>
            </div>
          )
        })}
      </div>
    </Frame>
  )
}

export function SupportThread() {
  return (
    <Frame>
      <Title right={<Badge tone="warning" dot>Open</Badge>}><span className="flex items-center gap-2"><MessageSquare size={15} />Ticket #3921</span></Title>
      <div className="space-y-3 text-[13px]">
        <div className="max-w-[85%] rounded-2xl rounded-bl-md bg-hover px-3.5 py-2 text-heading">Where is my order #10480? It was due yesterday.</div>
        <div className="ml-auto max-w-[85%] rounded-2xl rounded-br-md bg-primary px-3.5 py-2 text-white">It is in transit and arrives tomorrow by 6 PM. Tracking sent to your email.</div>
        <div className="flex items-center gap-2 rounded-lg border border-dashed border-line-strong px-3 py-2 text-xs text-text-2"><Sparkles size={13} className="text-primary" />AI drafted this reply from live shipment data</div>
      </div>
    </Frame>
  )
}

export function CopilotPanel() {
  return (
    <Frame className="bg-gradient-to-br from-primary-light to-surface">
      <div className="mb-4 flex items-center gap-3"><span className="ai-pulse grid size-9 place-items-center rounded-full bg-gradient-to-br from-primary to-purple text-white"><Bot size={18} /></span><div><p className="text-sm font-semibold text-heading">NEXORA AI</p><p className="text-xs text-text-2">Monitoring 2,847 live orders</p></div></div>
      <div className="space-y-2.5 text-[13px]">
        {[['SKU-2048 will stock out in 6 days. Raise PO for 1,200 units?', 'Approve'], ['12 shipments at risk due to monsoon delays in Zone 3.', 'Reroute'], ['Vendor Orbit lead time up 22% this month.', 'Review']].map(([t, a]) => (
          <div key={t} className="flex items-center gap-3 rounded-xl border border-line bg-surface p-3"><p className="flex-1 text-heading">{t}</p><span className="rounded-md bg-primary px-2.5 py-1 text-xs font-medium text-white">{a}</span></div>
        ))}
      </div>
      <div className="mt-3 flex items-center gap-2 rounded-lg border border-line bg-surface px-3 py-2 text-xs text-muted"><span className="flex-1">Ask anything about your operations…</span><Send size={13} className="text-primary" /></div>
    </Frame>
  )
}

export function AnalyticsCharts() {
  const bars = [40, 62, 48, 75, 58, 88, 70, 95]
  const c = 2 * Math.PI * 40
  return (
    <Frame>
      <Title>Revenue &amp; channel mix</Title>
      <div className="grid items-center gap-5 sm:grid-cols-5">
        <div className="flex h-36 items-end gap-2 sm:col-span-3">{bars.map((h, i) => <div key={i} className="flex-1 rounded-t-md bg-gradient-to-t from-primary to-purple" style={{ height: `${h}%`, opacity: 0.5 + h / 200 }} />)}</div>
        <div className="flex items-center gap-4 sm:col-span-2">
          <svg viewBox="0 0 100 100" className="size-24 -rotate-90 shrink-0"><circle cx="50" cy="50" r="40" fill="none" stroke="var(--cyan)" strokeWidth="14" /><circle cx="50" cy="50" r="40" fill="none" stroke="var(--purple)" strokeWidth="14" strokeDasharray={`${c * 0.55} ${c}`} /><circle cx="50" cy="50" r="40" fill="none" stroke="var(--primary)" strokeWidth="14" strokeDasharray={`${c * 0.35} ${c}`} /></svg>
          <ul className="space-y-1 text-xs text-text-2"><li><i className="mr-1.5 inline-block size-2 rounded-full bg-primary" />DTC 35%</li><li><i className="mr-1.5 inline-block size-2 rounded-full bg-purple" />Marketplace 20%</li><li><i className="mr-1.5 inline-block size-2 rounded-full bg-cyan" />B2B 45%</li></ul>
        </div>
      </div>
    </Frame>
  )
}
