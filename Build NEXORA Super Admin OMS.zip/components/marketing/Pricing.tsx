'use client'
import { useState } from 'react'
import Link from 'next/link'
import { Check } from 'lucide-react'
import { PLANS } from '@/lib/session'
import { Tabs, cn } from '@/components/ui/core'

export function Pricing() {
  const [cycle, setCycle] = useState<'Monthly' | 'Yearly'>('Monthly')
  return (
    <div>
      <div className="mb-10 flex justify-center"><Tabs value={cycle} onChange={setCycle} options={['Monthly', 'Yearly'] as const} /></div>
      <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
        {PLANS.map((p) => {
          const feat = p.id === 'growth'
          const price = cycle === 'Monthly' ? p.monthly : p.yearly
          return (
            <div key={p.id} className={cn('relative flex flex-col rounded-2xl border bg-surface p-6 shadow-xs', feat ? 'border-primary ring-2 ring-primary/30' : 'border-line')}>
              {feat && <span className="absolute -top-3 left-6 rounded-full bg-primary px-3 py-0.5 text-xs font-semibold text-white">Most popular</span>}
              <h3 className="text-lg font-semibold text-heading">{p.name}</h3>
              <p className="mt-3 flex items-end gap-1">{price ? <><span className="text-4xl font-bold text-heading">${price}</span><span className="pb-1 text-sm text-text-2">/ mo{cycle === 'Yearly' ? ', billed yearly' : ''}</span></> : <span className="text-4xl font-bold text-heading">Custom</span>}</p>
              <ul className="mt-6 flex-1 space-y-2.5 text-sm text-text">
                {[`${p.orders} orders`, `${p.users} users`, `${p.warehouses} warehouses`, `${p.ai} AI`, `${p.integrations} integrations`, `${p.support} support`].map((f) => <li key={f} className="flex gap-2"><Check size={16} className="mt-0.5 shrink-0 text-primary" />{f}</li>)}
              </ul>
              <Link href={price ? '/business-setup' : '/book-demo'} className={cn('mt-7 inline-flex h-11 items-center justify-center rounded-lg text-sm font-semibold transition-colors', feat ? 'bg-primary text-white hover:bg-primary-hover' : 'border border-line-strong text-heading hover:bg-hover')}>{price ? 'Get Started' : 'Contact Sales'}</Link>
            </div>
          )
        })}
      </div>
    </div>
  )
}
