'use client'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Menu, Moon, Sun, X } from 'lucide-react'
import { Logo } from '@/components/layout/Sidebar'
import { useTheme } from '@/components/theme'
import { cn } from '@/components/ui/core'

export const NAV = [
  { label: 'Platform', href: '/#unified-oms' },
  { label: 'Solutions', href: '/#supply-chain' },
  { label: 'AI Operations', href: '/#ai-insights' },
  { label: 'Features', href: '/#inventory-management' },
  { label: 'Pricing', href: '/#pricing' },
  { label: 'Resources', href: '/#how-it-works' },
]

export function ThemeToggle() {
  const { resolved, setTheme } = useTheme()
  return (
    <button aria-label={resolved === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'} onClick={() => setTheme(resolved === 'dark' ? 'light' : 'dark')} className="grid size-10 place-items-center rounded-lg text-text-2 transition-colors hover:bg-hover hover:text-heading">
      {resolved === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
    </button>
  )
}

const btn = 'inline-flex h-10 items-center justify-center rounded-lg px-4 text-sm font-medium whitespace-nowrap transition-all duration-150'

export function Header() {
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  useEffect(() => {
    const f = () => setScrolled(window.scrollY > 8)
    f(); window.addEventListener('scroll', f, { passive: true })
    return () => window.removeEventListener('scroll', f)
  }, [])
  return (
    <header className={cn('sticky top-0 z-50 border-b backdrop-blur-xl transition-colors', scrolled || open ? 'border-line bg-surface/90' : 'border-transparent bg-bg/60')}>
      <div className="mx-auto flex h-[68px] max-w-7xl items-center gap-4 px-4 sm:px-6">
        <Link href="/" aria-label="NEXORA home"><Logo /></Link>
        <nav aria-label="Primary" className="ml-6 hidden items-center gap-1 lg:flex">
          {NAV.map((n) => <Link key={n.label} href={n.href} className="rounded-lg px-3 py-2 text-sm font-medium text-text-2 transition-colors hover:bg-hover hover:text-heading">{n.label}</Link>)}
        </nav>
        <div className="ml-auto flex items-center gap-1.5">
          <ThemeToggle />
          <Link href="/login" className={cn(btn, 'hidden text-heading hover:bg-hover sm:inline-flex')}>Sign In</Link>
          <Link href="/book-demo" className={cn(btn, 'hidden border border-line-strong bg-surface text-heading hover:bg-hover md:inline-flex')}>Book a Demo</Link>
          <Link href="/business-setup" className={cn(btn, 'hidden bg-primary text-white shadow-xs hover:bg-primary-hover sm:inline-flex')}>Get Started</Link>
          <button aria-label={open ? 'Close menu' : 'Open menu'} aria-expanded={open} onClick={() => setOpen(!open)} className="grid size-10 place-items-center rounded-lg text-heading hover:bg-hover lg:hidden">{open ? <X size={20} /> : <Menu size={20} />}</button>
        </div>
      </div>
      {open && (
        <div className="anim-fade border-t border-line bg-surface px-4 pb-5 pt-3 lg:hidden">
          <nav aria-label="Mobile" className="grid gap-1">
            {NAV.map((n) => <Link key={n.label} href={n.href} onClick={() => setOpen(false)} className="rounded-lg px-3 py-2.5 text-[15px] font-medium text-heading hover:bg-hover">{n.label}</Link>)}
          </nav>
          <div className="mt-4 grid gap-2 sm:grid-cols-3">
            <Link href="/login" onClick={() => setOpen(false)} className={cn(btn, 'border border-line-strong text-heading')}>Sign In</Link>
            <Link href="/book-demo" onClick={() => setOpen(false)} className={cn(btn, 'border border-line-strong text-heading')}>Book a Demo</Link>
            <Link href="/business-setup" onClick={() => setOpen(false)} className={cn(btn, 'bg-primary text-white')}>Get Started</Link>
          </div>
        </div>
      )}
    </header>
  )
}
