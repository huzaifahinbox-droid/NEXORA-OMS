'use client'
import { useEffect, useState } from 'react'
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { ArrowDownRight, ArrowUpRight } from 'lucide-react'
import { Card, cn, type Tone } from '@/components/ui/core'

export const PALETTE = ['var(--primary)', 'var(--cyan)', 'var(--purple)', 'var(--blue)', '#f59e0b', '#10b981']
export interface Series { key: string; label: string; color?: string }

const axis = { fontSize: 12, fill: 'var(--text-2)' }
function Tip({ active, payload, label, fmt }: { active?: boolean; payload?: { name: string; value: number; color: string }[]; label?: string; fmt?: (n: number) => string }) {
  if (!active || !payload?.length) return null
  return (
    <div className="rounded-lg border border-line bg-surface px-3 py-2 text-xs shadow-pop">
      <div className="mb-1 font-semibold text-heading">{label}</div>
      {payload.map((p) => <div key={p.name} className="flex items-center gap-2 text-text"><span className="size-2 rounded-full" style={{ background: p.color }} />{p.name}: <b className="text-heading">{fmt ? fmt(p.value) : p.value.toLocaleString('en-IN')}</b></div>)}
    </div>
  )
}

export function Chart({ type = 'area', data, series, xKey = 'name', height = 280, fmt, stacked, legend = true }: { type?: 'area' | 'line' | 'bar'; data: Record<string, string | number>[]; series: Series[]; xKey?: string; height?: number; fmt?: (n: number) => string; stacked?: boolean; legend?: boolean }) {
  const common = { data, margin: { top: 8, right: 8, left: -8, bottom: 0 } }
  const grid = <CartesianGrid stroke="var(--chart-grid)" strokeDasharray="3 3" vertical={false} />
  const xs = <XAxis dataKey={xKey} tick={axis} tickLine={false} axisLine={{ stroke: 'var(--line)' }} />
  const ys = <YAxis tick={axis} tickLine={false} axisLine={false} tickFormatter={fmt ? (v) => fmt(Number(v)) : undefined} width={fmt ? 56 : 40} />
  const tip = <Tooltip content={<Tip fmt={fmt} />} cursor={{ stroke: 'var(--line-strong)' }} />
  const leg = legend && series.length > 1 ? <Legend wrapperStyle={{ fontSize: 12, color: 'var(--text-2)' }} iconType="circle" /> : null
  const col = (s: Series, i: number) => s.color ?? PALETTE[i % PALETTE.length]
  return (
    <div style={{ height }} className="w-full">
      <ResponsiveContainer width="100%" height="100%">
        {type === 'bar' ? (
          <BarChart {...common}>{grid}{xs}{ys}<Tooltip content={<Tip fmt={fmt} />} cursor={{ fill: 'var(--hover)' }} />{leg}{series.map((s, i) => <Bar key={s.key} dataKey={s.key} name={s.label} fill={col(s, i)} radius={[4, 4, 0, 0]} stackId={stacked ? 'a' : undefined} animationDuration={700} />)}</BarChart>
        ) : type === 'line' ? (
          <LineChart {...common}>{grid}{xs}{ys}{tip}{leg}{series.map((s, i) => <Line key={s.key} type="monotone" dataKey={s.key} name={s.label} stroke={col(s, i)} strokeWidth={2.5} dot={false} activeDot={{ r: 5 }} animationDuration={900} />)}</LineChart>
        ) : (
          <AreaChart {...common}>
            <defs>{series.map((s, i) => <linearGradient key={s.key} id={`g-${s.key}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={col(s, i)} stopOpacity={0.28} /><stop offset="100%" stopColor={col(s, i)} stopOpacity={0} /></linearGradient>)}</defs>
            {grid}{xs}{ys}{tip}{leg}
            {series.map((s, i) => <Area key={s.key} type="monotone" dataKey={s.key} name={s.label} stroke={col(s, i)} strokeWidth={2.5} fill={`url(#g-${s.key})`} activeDot={{ r: 5 }} animationDuration={900} />)}
          </AreaChart>
        )}
      </ResponsiveContainer>
    </div>
  )
}

export function Donut({ data, height = 200, center }: { data: { name: string; value: number }[]; height?: number; center?: string }) {
  return (
    <div className="flex flex-wrap items-center gap-4">
      <div style={{ height, width: height }} className="relative shrink-0">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart><Pie data={data} dataKey="value" innerRadius="62%" outerRadius="92%" paddingAngle={2} stroke="none" animationDuration={800}>{data.map((_, i) => <Cell key={i} fill={PALETTE[i % PALETTE.length]} />)}</Pie><Tooltip content={<Tip />} /></PieChart>
        </ResponsiveContainer>
        {center && <div className="pointer-events-none absolute inset-0 grid place-items-center text-center text-lg font-bold text-heading">{center}</div>}
      </div>
      <ul className="space-y-1.5 text-[13px]">{data.map((d, i) => <li key={d.name} className="flex items-center gap-2 text-text"><span className="size-2.5 rounded-full" style={{ background: PALETTE[i % PALETTE.length] }} />{d.name}<b className="ml-2 text-heading">{d.value}</b></li>)}</ul>
    </div>
  )
}

export function Spark({ data, color = 'var(--primary)' }: { data: number[]; color?: string }) {
  const d = data.map((v, i) => ({ i, v }))
  return (
    <div className="h-10 w-full" aria-hidden>
      <ResponsiveContainer width="100%" height="100%"><AreaChart data={d} margin={{ top: 2, bottom: 2, left: 0, right: 0 }}><Area type="monotone" dataKey="v" stroke={color} strokeWidth={2} fill={color} fillOpacity={0.12} isAnimationActive animationDuration={900} /></AreaChart></ResponsiveContainer>
    </div>
  )
}

export function useCountUp(target: number, ms = 900) {
  const [v, setV] = useState(0)
  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { setV(target); return }
    let raf = 0; const t0 = performance.now()
    const tick = (t: number) => { const p = Math.min(1, (t - t0) / ms); setV(target * (1 - Math.pow(1 - p, 3))); if (p < 1) raf = requestAnimationFrame(tick) }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [target, ms])
  return v
}

export interface KpiProps { label: string; value: number; format?: (n: number) => string; trend?: number; prev?: string; spark?: number[]; status?: string; tone?: Tone; invert?: boolean; hint?: string }
export function Kpi({ label, value, format = (n) => Math.round(n).toLocaleString('en-IN'), trend, prev, spark, status, invert, hint }: KpiProps) {
  const v = useCountUp(value)
  const good = trend === undefined ? true : invert ? trend <= 0 : trend >= 0
  const Arrow = (trend ?? 0) >= 0 ? ArrowUpRight : ArrowDownRight
  return (
    <Card hover className="p-5 anim-fade">
      <div className="flex items-start justify-between gap-2"><p className="text-[13px] font-medium text-text-2">{label}</p>{status && <span className={cn('rounded-full px-2 py-0.5 text-[11px] font-medium', status === 'Healthy' ? 'bg-success-bg text-success' : status === 'Attention' ? 'bg-warning-bg text-warning' : status === 'Critical' ? 'bg-danger-bg text-danger' : 'bg-hover text-text')}>{status}</span>}</div>
      <p className="mt-2 text-[28px] font-bold leading-none tracking-tight text-heading tabular-nums">{format(v)}</p>
      <div className="mt-2 flex flex-wrap items-center gap-x-2 text-xs">
        {trend !== undefined && <span className={cn('inline-flex items-center gap-0.5 font-semibold', good ? 'text-success' : 'text-danger')}><Arrow size={14} />{Math.abs(trend).toFixed(1)}%</span>}
        {(prev || hint) && <span className="text-text-2">{prev ? `vs ${prev}` : hint}</span>}
      </div>
      {spark && <div className="mt-3"><Spark data={spark} color={good ? 'var(--primary)' : 'var(--danger)'} /></div>}
    </Card>
  )
}
