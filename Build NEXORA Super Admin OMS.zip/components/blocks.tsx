'use client'
import { useEffect, useState, type ReactNode } from 'react'
import Link from 'next/link'
import { ArrowRight, type LucideIcon } from 'lucide-react'
import { Badge, Button, Card, CardHeader, cn, ErrorState, Field, Modal, PageSkeleton, Progress, StatusBadge, toast, type Tone } from '@/components/ui/core'
import { Kpi, type KpiProps } from '@/components/charts/charts'

export function useLoading(ms = 450) {
  const [l, setL] = useState(true)
  useEffect(() => { const t = setTimeout(() => setL(false), ms); return () => clearTimeout(t) }, [ms])
  return l
}

export function Page({ title, desc, actions, children }: { title: string; desc: string; actions?: ReactNode; children: ReactNode }) {
  const loading = useLoading()
  const [err, setErr] = useState(false)
  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0"><h1 className="text-[28px] font-bold leading-tight tracking-tight text-heading">{title}</h1><p className="mt-1 max-w-2xl text-sm text-text-2">{desc}</p></div>
        {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
      </header>
      {err ? <ErrorState onRetry={() => setErr(false)} /> : loading ? <PageSkeleton /> : <div className="space-y-6 anim-fade">{children}</div>}
    </div>
  )
}
export const KpiRow = ({ items, cols = 4 }: { items: KpiProps[]; cols?: 3 | 4 | 5 | 6 }) => (
  <div className={cn('grid gap-4 sm:grid-cols-2', cols === 3 && 'xl:grid-cols-3', cols === 4 && 'xl:grid-cols-4', cols === 5 && 'xl:grid-cols-5', cols === 6 && 'lg:grid-cols-3 2xl:grid-cols-6')}>{items.map((k) => <Kpi key={k.label} {...k} />)}</div>
)
export function Panel({ title, sub, action, children, className, pad = true }: { title: string; sub?: string; action?: ReactNode; children: ReactNode; className?: string; pad?: boolean }) {
  return <Card className={cn('pb-5', className)}><CardHeader title={title} sub={sub} action={action} /><div className={cn('mt-4', pad && 'px-5')}>{children}</div></Card>
}
export const Grid = ({ children, cols = 2 }: { children: ReactNode; cols?: 2 | 3 }) => <div className={cn('grid gap-6', cols === 2 ? 'xl:grid-cols-2' : 'xl:grid-cols-3')}>{children}</div>
export const Split = ({ main, side }: { main: ReactNode; side: ReactNode }) => <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_380px]"><div className="min-w-0 space-y-6">{main}</div><div className="min-w-0 space-y-6">{side}</div></div>

export function BarList({ items }: { items: { label: string; value: number; display?: string; max?: number; tone?: 'primary' | 'success' | 'warning' | 'danger'; sub?: string }[] }) {
  const max = Math.max(...items.map((i) => i.max ?? i.value), 1)
  return (
    <ul className="space-y-3.5">
      {items.map((i) => (
        <li key={i.label}>
          <div className="mb-1.5 flex items-baseline justify-between gap-2 text-[13px]"><span className="truncate font-medium text-heading">{i.label}{i.sub && <span className="ml-2 font-normal text-text-2">{i.sub}</span>}</span><span className="tabular-nums text-text-2">{i.display ?? i.value}</span></div>
          <Progress value={(i.value / max) * 100} tone={i.tone} />
        </li>
      ))}
    </ul>
  )
}

export function Stages({ stages, onSelect }: { stages: { label: string; count: number | string; pct?: number; sub?: string; tone?: Tone; href?: string; active?: boolean }[]; onSelect?: (label: string) => void }) {
  return (
    <ol className="grid gap-2 sm:grid-cols-2 lg:grid-flow-col lg:auto-cols-fr">
      {stages.map((s, i) => {
        const inner = (
          <>
            <div className="flex items-center justify-between text-xs text-text-2"><span className="font-medium">{s.label}</span>{i < stages.length - 1 && <ArrowRight size={14} className="hidden text-muted lg:block" />}</div>
            <p className="mt-1.5 text-2xl font-bold tabular-nums text-heading">{s.count}</p>
            <div className="mt-1 flex items-center justify-between text-xs text-text-2">{s.pct !== undefined && <span>{s.pct}%</span>}{s.sub && <span>{s.sub}</span>}</div>
          </>
        )
        const cls = cn('block w-full rounded-xl border p-4 text-left transition-all duration-150 hover:-translate-y-0.5 hover:border-primary', s.active ? 'border-primary bg-primary-light' : 'border-line bg-surface-2')
        return <li key={s.label}>{s.href ? <Link href={s.href} className={cls}>{inner}</Link> : <button onClick={() => onSelect?.(s.label)} className={cls}>{inner}</button>}</li>
      })}
    </ol>
  )
}

export function Timeline({ events }: { events: { title: string; sub?: string; time: string; tone?: Tone; icon?: LucideIcon; done?: boolean }[] }) {
  return (
    <ol className="relative space-y-5 border-l border-line pl-6">
      {events.map((e, i) => {
        const I = e.icon
        return (
          <li key={i} className="relative">
            <span className={cn('absolute -left-[34px] grid size-5 place-items-center rounded-full border-2 border-surface', e.done === false ? 'bg-line-strong' : 'bg-primary text-white')}>{I && <I size={10} />}</span>
            <div className="flex flex-wrap items-baseline justify-between gap-2"><p className="text-sm font-medium text-heading">{e.title}</p><span className="text-xs text-muted">{e.time}</span></div>
            {e.sub && <p className="text-[13px] text-text-2">{e.sub}</p>}
          </li>
        )
      })}
    </ol>
  )
}

export function Kanban({ columns, onMove }: { columns: { title: string; tone?: Tone; items: { id: string; title: string; sub: string; tag?: string }[] }[]; onMove?: (id: string, from: number) => void }) {
  return (
    <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
      {columns.map((c, ci) => (
        <div key={c.title} className="rounded-xl bg-surface-2 p-3">
          <div className="mb-3 flex items-center justify-between px-1"><span className="text-[13px] font-semibold text-heading">{c.title}</span><Badge tone={c.tone}>{c.items.length}</Badge></div>
          <div className="space-y-2">
            {c.items.length === 0 && <p className="rounded-lg border border-dashed border-line px-3 py-6 text-center text-xs text-muted">No items</p>}
            {c.items.map((it) => (
              <div key={it.id} className="rounded-lg border border-line bg-surface p-3 text-[13px] shadow-xs transition-colors hover:border-line-strong">
                <div className="flex items-center justify-between"><b className="text-heading">{it.title}</b>{it.tag && <Badge>{it.tag}</Badge>}</div>
                <p className="mt-0.5 text-text-2">{it.sub}</p>
                {onMove && ci < columns.length - 1 && <button onClick={() => onMove(it.id, ci)} className="mt-2 text-xs font-medium text-primary hover:underline">Move to {columns[ci + 1].title} →</button>}
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}

export function Feed({ items }: { items: { title: string; sub: string; time: string; badge?: string }[] }) {
  return (
    <ul className="divide-y divide-line">
      {items.map((it, i) => (
        <li key={i} className="flex items-start gap-3 py-3 first:pt-0 last:pb-0">
          <span className="mt-1.5 size-2 shrink-0 rounded-full bg-primary" />
          <div className="min-w-0 flex-1"><p className="text-sm font-medium text-heading">{it.title}</p><p className="text-[13px] text-text-2">{it.sub}</p></div>
          <div className="shrink-0 text-right text-xs text-muted">{it.time}{it.badge && <div className="mt-1"><StatusBadge s={it.badge} /></div>}</div>
        </li>
      ))}
    </ul>
  )
}

export function Chain({ nodes }: { nodes: { label: string; value: string; sub: string; icon: LucideIcon; tone?: 'ok' | 'warn' | 'bad' }[] }) {
  return (
    <div className="flex flex-col items-stretch gap-3 lg:flex-row lg:items-center">
      {nodes.map((n, i) => {
        const I = n.icon
        return (
          <div key={n.label} className="flex flex-1 flex-col items-center gap-3 lg:flex-row">
            <div className={cn('w-full flex-1 rounded-xl border p-4 text-center', n.tone === 'bad' ? 'border-danger/40 bg-danger-bg/50' : n.tone === 'warn' ? 'border-warning/40 bg-warning-bg/50' : 'border-line bg-surface-2')}>
              <span className="mx-auto mb-2 grid size-10 place-items-center rounded-xl bg-primary-light text-primary"><I size={18} /></span>
              <p className="text-[13px] font-semibold text-heading">{n.label}</p><p className="text-xl font-bold tabular-nums text-heading">{n.value}</p><p className="text-xs text-text-2">{n.sub}</p>
            </div>
            {i < nodes.length - 1 && <ArrowRight size={18} className="shrink-0 rotate-90 text-muted lg:rotate-0" />}
          </div>
        )
      })}
    </div>
  )
}

export interface FieldDef { key: string; label: string; type?: 'text' | 'number' | 'select' | 'textarea'; options?: string[]; required?: boolean; placeholder?: string }
export function RecordModal({ open, onClose, title, fields, initial, onSubmit, submitLabel = 'Save' }: { open: boolean; onClose: () => void; title: string; fields: FieldDef[]; initial?: Record<string, string>; onSubmit: (v: Record<string, string>) => void; submitLabel?: string }) {
  const [v, setV] = useState<Record<string, string>>({})
  const [errs, setErrs] = useState<Record<string, string>>({})
  const [busy, setBusy] = useState(false)
  useEffect(() => { if (open) { setV(initial ?? {}); setErrs({}) } }, [open, initial])
  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    const er: Record<string, string> = {}
    fields.forEach((f) => { if (f.required !== false && !(v[f.key] ?? '').trim()) er[f.key] = `${f.label} is required`; if (f.type === 'number' && v[f.key] && isNaN(Number(v[f.key]))) er[f.key] = 'Enter a valid number' })
    setErrs(er)
    if (Object.keys(er).length) return
    setBusy(true)
    setTimeout(() => { onSubmit(v); setBusy(false); onClose() }, 350)
  }
  return (
    <Modal open={open} onClose={onClose} title={title} footer={<><Button onClick={onClose}>Cancel</Button><Button variant="primary" loading={busy} type="submit" form="record-form">{submitLabel}</Button></>}>
      <form id="record-form" onSubmit={submit} className="space-y-4" noValidate>
        {fields.map((f) => (
          <Field key={f.key} label={f.label} error={errs[f.key]} required={f.required !== false}>
            {(id) => f.type === 'select' ? (
              <select id={id} value={v[f.key] ?? ''} onChange={(e) => setV({ ...v, [f.key]: e.target.value })} className="h-10 w-full rounded-lg border border-line-strong bg-surface px-3 text-sm text-heading focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"><option value="">Select…</option>{f.options?.map((o) => <option key={o}>{o}</option>)}</select>
            ) : f.type === 'textarea' ? (
              <textarea id={id} rows={3} value={v[f.key] ?? ''} onChange={(e) => setV({ ...v, [f.key]: e.target.value })} className="w-full rounded-lg border border-line-strong bg-surface px-3 py-2 text-sm text-heading focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30" />
            ) : (
              <input id={id} type={f.type === 'number' ? 'text' : 'text'} inputMode={f.type === 'number' ? 'numeric' : undefined} placeholder={f.placeholder} value={v[f.key] ?? ''} onChange={(e) => setV({ ...v, [f.key]: e.target.value })} className="h-10 w-full rounded-lg border border-line-strong bg-surface px-3 text-sm text-heading placeholder:text-muted focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30" />
            )}
          </Field>
        ))}
      </form>
    </Modal>
  )
}
export { toast }
