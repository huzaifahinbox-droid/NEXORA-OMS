'use client'
import { useState, type ReactNode } from 'react'
import { MessageSquare, Package, RotateCcw, UserPlus } from 'lucide-react'
import { Button, ConfirmDialog, DataTable, StatusBadge, Tabs, toast, Badge, Card } from '@/components/ui/core'
import { BarList, Grid, KpiRow, Page, Panel, RecordModal, Timeline } from '@/components/blocks'
import { Chart, Donut } from '@/components/charts/charts'
import { db, compact, money, useDB } from '@/lib/db'
import { monthly, spark } from '@/lib/metrics'
import type { Customer } from '@/types'

const SEG_INFO: Record<string, string> = { VIP: 'Top 1% by lifetime value, ordering monthly or more.', 'High Value': 'Above-average basket size with strong margins.', Returning: 'Two or more orders in the last 90 days.', New: 'First order within the last 30 days.', 'At Risk': 'No purchase in 60+ days after being active.' }
const SEGS = ['VIP', 'High Value', 'Returning', 'New', 'At Risk'] as const

function CustomerModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  return <RecordModal open={open} onClose={onClose} title="Add customer" fields={[{ key: 'name', label: 'Full name' }, { key: 'email', label: 'Email' }, { key: 'city', label: 'City' }, { key: 'segment', label: 'Segment', type: 'select', options: [...SEGS] }]} onSubmit={(v) => { db.add('customers', { id: `CUS-${3100 + Math.floor(Math.random() * 800)}`, name: v.name, email: v.email, city: v.city, segment: v.segment as Customer['segment'], orders: 0, revenue: 0, lastOrder: '2026-10-08', status: 'Active' }); toast(`${v.name} added`) }} />
}

const Overview = () => {
  const d = useDB()
  const rev = d.customers.reduce((a, c) => a + c.revenue, 0)
  return (
    <Page title="Customer Overview" desc="Growth, activity and value across your customer base." actions={<Button variant="primary" icon={UserPlus} onClick={() => toast('Open Customer Directory to add customers', 'info')}>Add customer</Button>}>
      <KpiRow items={[{ label: 'Total customers', value: d.customers.length, trend: 5.2, prev: 'last month', spark: spark(1) }, { label: 'Active customers', value: d.customers.filter((c) => c.status === 'Active').length, trend: 3.1, prev: 'last month', spark: spark(2) }, { label: 'Lifetime revenue', value: rev, format: compact, trend: 8.4, prev: 'last month', spark: spark(3) }, { label: 'Avg orders / customer', value: d.customers.reduce((a, c) => a + c.orders, 0) / d.customers.length, format: (n) => n.toFixed(1), trend: 1.8, prev: 'last month', spark: spark(4) }]} />
      <Grid>
        <Panel title="New customers" sub="Last 6 months"><Chart type="bar" data={monthly(310, 6, 2)} series={[{ key: 'value', label: 'New customers' }]} legend={false} height={240} /></Panel>
        <Panel title="Segment mix"><Donut data={SEGS.map((s) => ({ name: s, value: d.customers.filter((c) => c.segment === s).length }))} center={`${d.customers.length}`} /></Panel>
      </Grid>
      <Panel title="Top customers" sub="By lifetime revenue"><BarList items={[...d.customers].sort((a, b) => b.revenue - a.revenue).slice(0, 6).map((c) => ({ label: c.name, sub: c.segment, value: c.revenue, display: money(c.revenue) }))} /></Panel>
    </Page>
  )
}

const Directory = () => {
  const d = useDB()
  const [add, setAdd] = useState(false)
  const [del, setDel] = useState<Customer | null>(null)
  const [seg, setSeg] = useState('')
  return (
    <Page title="Customer Directory" desc="Search, filter and manage every customer record." actions={<Button variant="primary" icon={UserPlus} onClick={() => setAdd(true)}>Add customer</Button>}>
      <DataTable rows={d.customers.filter((c) => !seg || c.segment === seg)} searchOf={(c) => `${c.name} ${c.email} ${c.id} ${c.city}`}
        filters={<select aria-label="Filter by segment" value={seg} onChange={(e) => setSeg(e.target.value)} className="h-10 rounded-lg border border-line-strong bg-surface px-3 text-sm text-heading"><option value="">All segments</option>{SEGS.map((s) => <option key={s}>{s}</option>)}</select>}
        empty={{ title: 'No customers yet', body: 'Add your first customer to start tracking orders and value.', cta: 'Add customer', onCta: () => setAdd(true) }}
        cols={[{ key: 'name', label: 'Customer', render: (c) => <div><b className="text-heading">{c.name}</b><div className="text-xs text-muted">{c.id} · {c.city}</div></div> }, { key: 'email', label: 'Email' }, { key: 'orders', label: 'Orders', align: 'right' }, { key: 'revenue', label: 'Revenue', align: 'right', render: (c) => money(c.revenue) }, { key: 'lastOrder', label: 'Last order' }, { key: 'segment', label: 'Segment', render: (c) => <Badge tone={c.segment === 'At Risk' ? 'danger' : c.segment === 'VIP' ? 'primary' : 'neutral'}>{c.segment}</Badge> }, { key: 'status', label: 'Status', render: (c) => <StatusBadge s={c.status} /> }]}
        actions={(c) => <Button size="sm" variant="ghost" onClick={() => setDel(c)}>Delete</Button>} />
      <CustomerModal open={add} onClose={() => setAdd(false)} />
      <ConfirmDialog open={!!del} danger title={`Delete ${del?.name}?`} body="This permanently removes the customer record. Their historical orders are retained." confirmLabel="Delete" onClose={() => setDel(null)} onConfirm={() => { if (del) { db.remove('customers', del.id); toast('Customer deleted') } }} />
    </Page>
  )
}

const Segments = () => {
  const d = useDB()
  const [sel, setSel] = useState<string>('VIP')
  return (
    <Page title="Customer Segments" desc="Behavioral groups that power targeting, retention and support priority.">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        {SEGS.map((s) => {
          const m = d.customers.filter((c) => c.segment === s)
          return (
            <button key={s} onClick={() => setSel(s)} aria-pressed={sel === s} className={`rounded-xl border p-5 text-left transition-all hover:-translate-y-0.5 ${sel === s ? 'border-primary bg-primary-light' : 'border-line bg-surface'}`}>
              <p className="text-sm font-semibold text-heading">{s}</p><p className="mt-2 text-3xl font-bold tabular-nums text-heading">{m.length}</p>
              <p className="mt-1 text-xs text-text-2">{compact(m.reduce((a, c) => a + c.revenue, 0))} revenue</p><p className="mt-3 text-xs text-text-2">{SEG_INFO[s]}</p>
            </button>
          )
        })}
      </div>
      <Panel title={`${sel} customers`} pad={false}><div className="-mt-4"><DataTable rows={d.customers.filter((c) => c.segment === sel)} pageSize={6} searchOf={(c) => `${c.name} ${c.email}`} cols={[{ key: 'name', label: 'Customer' }, { key: 'city', label: 'City' }, { key: 'orders', label: 'Orders', align: 'right' }, { key: 'revenue', label: 'Revenue', align: 'right', render: (c) => money(c.revenue) }, { key: 'lastOrder', label: 'Last order' }]} /></div></Panel>
    </Page>
  )
}

const Activity = () => {
  const d = useDB()
  const [tab, setTab] = useState<'All' | 'Orders' | 'Returns' | 'Support'>('All')
  const cn = (id: string) => d.customers.find((c) => c.id === id)?.name ?? id
  const ev = [
    ...d.orders.slice(0, 12).map((o) => ({ k: o.status === 'Returned' ? 'Returns' : 'Orders', title: `${cn(o.customerId)} — ${o.id} ${o.status.toLowerCase()}`, sub: `${money(o.total)} via ${o.channel}`, time: o.date, icon: o.status === 'Returned' ? RotateCcw : Package })),
    ...d.tickets.slice(0, 6).map((t) => ({ k: 'Support', title: `${t.customer} — ${t.id} ${t.status.toLowerCase()}`, sub: t.issue, time: 'Support', icon: MessageSquare })),
  ].filter((e) => tab === 'All' || e.k === tab).slice(0, 14)
  return (
    <Page title="Customer Activity" desc="A unified timeline of orders, returns and support interactions." actions={<Tabs value={tab} onChange={setTab} options={['All', 'Orders', 'Returns', 'Support'] as const} />}>
      <Card className="p-6">{ev.length ? <Timeline events={ev.map((e) => ({ title: e.title, sub: e.sub, time: e.time, icon: e.icon }))} /> : <p className="py-8 text-center text-sm text-text-2">No activity in this category.</p>}</Card>
    </Page>
  )
}
export const screens: Record<string, () => ReactNode> = { overview: Overview, 'customer-directory': Directory, 'customer-segments': Segments, 'customer-activity': Activity }
