'use client'
import { useState, type ReactNode } from 'react'
import { Truck } from 'lucide-react'
import { Badge, Button, Card, ConfirmDialog, Progress } from '@/components/ui/core'
import { BarList, Grid, KpiRow, Page, Panel, Stages } from '@/components/blocks'
import { Chart, Donut } from '@/components/charts/charts'
import { ShipmentsTable } from '@/components/tables'
import { toast } from '@/components/ui/core'
import { db } from '@/lib/db'
import { TrackingView, useShip } from './shipments'
import { spark } from '@/lib/metrics'
import type { Shipment } from '@/types'

const BASE = '/logistics-management'
const ACTIVE: Shipment['status'][] = ['Active', 'Scheduled', 'In Transit', 'Out for Delivery']
const pct = (n: number) => `${Math.round(n)}%`
const group = (rows: Shipment[], key: (s: Shipment) => string) => Object.entries(rows.reduce<Record<string, number>>((a, s) => { const k = key(s); a[k] = (a[k] ?? 0) + 1; return a }, {})).sort((a, b) => b[1] - a[1])

const Overview = () => {
  const { d, count, byCarrier } = useShip()
  const active = d.shipments.filter((s) => ACTIVE.includes(s.status)).length
  const delivered = count('Delivered')
  return (
    <Page title="Logistics Overview" desc="Network-wide view of carriers, lanes and delivery outcomes.">
      <KpiRow cols={6} items={[{ label: 'Active', value: active, trend: 3.4, prev: 'last week', spark: spark(1) }, { label: 'In transit', value: count('In Transit') }, { label: 'Delivered', value: delivered, trend: 5.2, prev: 'last week', spark: spark(2) }, { label: 'Delayed', value: count('Delayed'), status: 'Attention' }, { label: 'Failed', value: count('Failed'), status: 'Critical' }, { label: 'Carriers', value: byCarrier.filter((c) => c.total).length, hint: 'in use' }]} />
      <Panel title="Pipeline" sub="Jump to a queue"><Stages stages={[{ label: 'Active', count: active, href: `${BASE}/active-shipments` }, { label: 'In Transit', count: count('In Transit'), href: `${BASE}/in-transit` }, { label: 'Delivered', count: delivered, href: `${BASE}/delivered` }, { label: 'Delayed', count: count('Delayed'), href: `${BASE}/delayed` }, { label: 'Failed', count: count('Failed'), href: `${BASE}/failed-deliveries` }]} /></Panel>
      <Grid>
        <Panel title="Carrier outcomes"><Chart type="bar" stacked height={250} data={byCarrier.map((c) => ({ name: c.name, Delivered: c.delivered, Delayed: c.delayed, Failed: c.failed, Moving: c.total - c.delivered - c.delayed - c.failed }))} series={[{ key: 'Delivered', label: 'Delivered', color: 'var(--success)' }, { key: 'Moving', label: 'Moving' }, { key: 'Delayed', label: 'Delayed', color: 'var(--warning)' }, { key: 'Failed', label: 'Failed', color: 'var(--danger)' }]} /></Panel>
        <Panel title="Top destinations"><BarList items={group(d.shipments, (s) => s.destination).slice(0, 6).map(([k, v]) => ({ label: k, value: v, display: `${v} shipments` }))} /></Panel>
      </Grid>
    </Page>
  )
}

const Active = () => {
  const { d } = useShip()
  const rows = d.shipments.filter((s) => ACTIVE.includes(s.status))
  return (
    <Page title="Active Shipments" desc="Everything currently moving through the network.">
      <KpiRow cols={4} items={[{ label: 'Active shipments', value: rows.length }, { label: 'Out for delivery', value: rows.filter((s) => s.status === 'Out for Delivery').length }, { label: 'At risk of SLA', value: rows.filter((s) => s.sla === 'At risk').length, status: 'Attention' }, { label: 'Due today', value: rows.filter((s) => s.eta <= '2026-10-08').length }]} />
      <ShipmentsTable statuses={ACTIVE} actions />
    </Page>
  )
}

const Transit = () => {
  const { d } = useShip()
  const rows = d.shipments.filter((s) => s.status === 'In Transit')
  return (
    <Page title="In Transit" desc="Parcels between pickup and last mile, grouped by lane and carrier.">
      <Grid>
        <Panel title="By destination"><BarList items={group(rows, (s) => s.destination).slice(0, 6).map(([k, v]) => ({ label: k, value: v, display: `${v}` }))} /></Panel>
        <Panel title="By carrier"><BarList items={group(rows, (s) => s.carrier).map(([k, v]) => ({ label: k, value: v, display: `${v}`, tone: 'success' as const }))} /></Panel>
      </Grid>
      <ShipmentsTable statuses={['In Transit']} actions />
    </Page>
  )
}

const Delivered = () => {
  const { d, byCarrier } = useShip()
  const rows = d.shipments.filter((s) => s.status === 'Delivered')
  const total = d.shipments.length
  return (
    <Page title="Delivered" desc="Completed deliveries and carrier success rate.">
      <KpiRow cols={3} items={[{ label: 'Delivered', value: rows.length, trend: 4.8, prev: 'last week' }, { label: 'Delivery rate', value: (rows.length / Math.max(1, total)) * 100, format: pct, hint: 'of all shipments' }, { label: 'Orders closed', value: d.orders.filter((o) => o.status === 'Delivered').length }]} />
      <Panel title="Delivered by carrier"><Chart type="bar" height={220} data={byCarrier.map((c) => ({ name: c.name, Delivered: c.delivered }))} series={[{ key: 'Delivered', label: 'Delivered', color: 'var(--success)' }]} /></Panel>
      <ShipmentsTable statuses={['Delivered']} />
    </Page>
  )
}

const Delayed = () => {
  const { d } = useShip()
  const rows = d.shipments.filter((s) => s.status === 'Delayed')
  return (
    <Page title="Delayed Shipments" desc="Parcels past their promised ETA. Reroute, escalate or inform the customer.">
      <KpiRow cols={3} items={[{ label: 'Delayed', value: rows.length, status: rows.length ? 'Attention' : 'Healthy' }, { label: 'SLA breached', value: rows.filter((s) => s.sla === 'Breached').length, status: 'Critical' }, { label: 'Carriers affected', value: new Set(rows.map((s) => s.carrier)).size }]} />
      <Panel title="Root causes"><BarList items={group(rows, (s) => s.issue ?? 'Unknown').map(([k, v]) => ({ label: k, value: v, display: `${v}`, tone: 'warning' as const }))} /></Panel>
      <ShipmentsTable statuses={['Delayed']} actions showIssue />
    </Page>
  )
}

const Failed = () => {
  const { d } = useShip()
  const rows = d.shipments.filter((s) => s.status === 'Failed')
  return (
    <Page title="Failed Deliveries" desc="Delivery attempts that did not succeed, with the reason from the carrier.">
      <Grid>
        <Panel title="Failure reasons"><Donut data={group(rows, (s) => s.issue ?? 'Unknown').map(([name, value]) => ({ name, value }))} center={`${rows.length}`} /></Panel>
        <Panel title="Failures by carrier"><BarList items={group(rows, (s) => s.carrier).map(([k, v]) => ({ label: k, value: v, display: `${v}`, tone: 'danger' as const }))} /></Panel>
      </Grid>
      <ShipmentsTable statuses={['Failed']} actions showIssue />
    </Page>
  )
}

const Carriers = () => {
  const { d, byCarrier } = useShip()
  const [conf, setConf] = useState<string | null>(null)
  const score = (c: (typeof byCarrier)[number]) => (c.total ? ((c.total - c.delayed - c.failed) / c.total) * 100 : 0)
  const best = (except: string) => [...byCarrier].filter((c) => c.name !== except && c.total).sort((a, b) => score(b) - score(a))[0]?.name
  const rebalance = (name: string) => {
    const to = best(name); const rows = d.shipments.filter((s) => s.carrier === name && s.status === 'Delayed')
    if (!to || !rows.length) { toast('Nothing to rebalance', 'info'); return }
    rows.forEach((s) => db.patch('shipments', s.id, { carrier: to, status: 'In Transit', issue: undefined, sla: 'At risk', lastScan: `Rerouted via ${to}` }))
    db.log(`Rebalanced ${rows.length} delayed shipments from ${name}`, 'Logistics', name, to)
    db.notify('Logistics', `${rows.length} shipments moved to ${to}`, `Delayed parcels were reassigned from ${name}.`, `${BASE}/carrier-management`)
    toast(`${rows.length} shipments reassigned to ${to}`)
  }
  return (
    <Page title="Carrier Management" desc="Scorecards for every carrier. Rebalance delayed volume to the best performer.">
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {[...byCarrier].sort((a, b) => score(b) - score(a)).map((c) => (
          <Card key={c.name} className="space-y-4 p-5" hover>
            <div className="flex items-center justify-between"><div className="flex items-center gap-2"><span className="grid size-9 place-items-center rounded-lg bg-primary-light text-primary"><Truck size={18} /></span><b className="text-heading">{c.name}</b></div><Badge tone={score(c) >= 85 ? 'success' : score(c) >= 70 ? 'warning' : 'danger'}>{pct(score(c))} service</Badge></div>
            <div className="grid grid-cols-4 gap-2 text-center text-xs text-text-2">{[['Shipments', c.total], ['Delivered', c.delivered], ['Delayed', c.delayed], ['Failed', c.failed]].map(([k, v]) => <div key={k}><p className="text-lg font-bold tabular-nums text-heading">{v}</p>{k}</div>)}</div>
            <div><div className="mb-1 flex justify-between text-xs text-text-2"><span>SLA compliance</span><span>{pct(c.total ? ((c.total - c.breached) / c.total) * 100 : 0)}</span></div><Progress value={c.total ? ((c.total - c.breached) / c.total) * 100 : 0} tone={c.breached > 2 ? 'warning' : 'success'} /></div>
            <Button size="sm" disabled={!c.delayed} onClick={() => setConf(c.name)}>Rebalance delayed to {best(c.name) ?? 'best carrier'}</Button>
          </Card>
        ))}
      </div>
      <Panel title="Service level comparison"><Chart type="bar" height={240} fmt={pct} data={byCarrier.map((c) => ({ name: c.name, 'Service level': Math.round(score(c)) }))} series={[{ key: 'Service level', label: 'Service level' }]} /></Panel>
      <ConfirmDialog open={!!conf} title={`Rebalance ${conf}?`} body={`All delayed shipments on ${conf} will be reassigned to ${conf ? best(conf) : ''}. This is recorded in the audit log.`} confirmLabel="Reassign" onClose={() => setConf(null)} onConfirm={() => conf && rebalance(conf)} />
    </Page>
  )
}

export const screens: Record<string, () => ReactNode> = { overview: Overview, 'active-shipments': Active, 'in-transit': Transit, delivered: Delivered, delayed: Delayed, 'failed-deliveries': Failed, 'carrier-management': Carriers, tracking: () => <TrackingView carrierView /> }
