'use client'
import { useState, type ReactNode } from 'react'
import { Check, ClipboardList, Plus, X } from 'lucide-react'
import { Badge, Button, Card, ConfirmDialog, DataTable, EmptyState, StatusBadge, toast } from '@/components/ui/core'
import { BarList, Feed, Grid, KpiRow, Page, Panel, RecordModal } from '@/components/blocks'
import { Chart, Donut } from '@/components/charts/charts'
import { ReqTable } from './procurement'
import { db, compact, money, useDB } from '@/lib/db'
import { spark } from '@/lib/metrics'
import type { Buyer } from '@/types'

const DEPTS = ['Merchandising', 'Procurement', 'Operations', 'Finance']
const CATS = ['Footwear, Apparel', 'Electronics', 'Home, Accessories', 'Apparel']

function useB() {
  const d = useDB()
  const pn = (sku: string) => d.products.find((p) => p.sku === sku)?.name ?? sku
  const vn = (id: string) => d.vendors.find((v) => v.id === id)?.name ?? id
  const rows = d.buyers.map((b) => {
    const mine = d.requests.filter((r) => r.buyer === b.name)
    const live = mine.filter((r) => r.status === 'Pending').length
    return { ...b, live, requests: mine.length, reqValue: mine.reduce((a, r) => a + r.value, 0) }
  })
  return { d, pn, vn, rows }
}

const Overview = () => {
  const { d, rows, vn } = useB()
  const pend = d.requests.filter((r) => r.status === 'Pending')
  return (
    <Page title="Buyers Overview" desc="Who is buying, what is waiting and how much is being spent.">
      <KpiRow cols={4} items={[{ label: 'Buyers', value: d.buyers.length, hint: `${new Set(d.buyers.map((b) => b.department)).size} departments` }, { label: 'Awaiting approval', value: pend.length, status: pend.length ? 'Attention' : 'Healthy', hint: compact(pend.reduce((a, r) => a + r.value, 0)) }, { label: 'Total spend', value: d.buyers.reduce((a, b) => a + b.spend, 0), format: compact, trend: 5.6, prev: 'last quarter', spark: spark(1) }, { label: 'Approval rate', value: (100 * d.requests.filter((r) => ['Approved', 'Converted'].includes(r.status)).length) / Math.max(1, d.requests.filter((r) => r.status !== 'Pending').length), format: (n) => `${Math.round(n)}%`, trend: 2.1, prev: 'last quarter' }]} />
      <Grid>
        <Panel title="Spend by buyer"><Chart type="bar" legend={false} height={240} fmt={compact} data={rows.map((b) => ({ name: b.name.split(' ')[0], value: b.spend }))} series={[{ key: 'value', label: 'Spend' }]} /></Panel>
        <Panel title="Requests by status"><Donut data={['Pending', 'Approved', 'Converted', 'Rejected'].map((s) => ({ name: s, value: d.requests.filter((r) => r.status === s).length }))} center={`${d.requests.length}`} /></Panel>
      </Grid>
      <Panel title="Latest requests"><Feed items={d.requests.slice(0, 6).map((r) => ({ title: `${r.id} · ${r.buyer}`, sub: `${r.qty} units from ${vn(r.vendorId)}`, time: money(r.value), badge: r.status }))} /></Panel>
    </Page>
  )
}

const Directory = () => {
  const { d, rows } = useB()
  const [edit, setEdit] = useState<Buyer | 'new' | null>(null)
  const [del, setDel] = useState<Buyer | null>(null)
  const cur = edit && edit !== 'new' ? edit : undefined
  return (
    <Page title="Buyer Directory" desc="People authorised to raise purchase requests." actions={<Button variant="primary" icon={Plus} onClick={() => setEdit('new')}>Add buyer</Button>}>
      <DataTable rows={rows} searchOf={(b) => `${b.id} ${b.name} ${b.department} ${b.categories}`} empty={{ title: 'No buyers yet', body: 'Add your first buyer.', cta: 'Add buyer', onCta: () => setEdit('new') }}
        cols={[{ key: 'name', label: 'Buyer', render: (b) => <div><b className="text-heading">{b.name}</b><div className="text-xs text-muted">{b.id}</div></div> }, { key: 'department', label: 'Department' }, { key: 'categories', label: 'Categories' }, { key: 'live', label: 'Pending', align: 'right' }, { key: 'approved', label: 'Approved', align: 'right' }, { key: 'spend', label: 'Spend', align: 'right', render: (b) => money(b.spend) }]}
        actions={(b) => <><Button size="sm" onClick={() => setEdit(d.buyers.find((x) => x.id === b.id)!)}>Edit</Button><Button size="sm" variant="ghost" onClick={() => setDel(d.buyers.find((x) => x.id === b.id)!)}>Remove</Button></>} />
      <RecordModal open={!!edit} onClose={() => setEdit(null)} title={cur ? `Edit ${cur.name}` : 'Add buyer'} submitLabel={cur ? 'Save changes' : 'Add buyer'}
        initial={cur ? { name: cur.name, department: cur.department, categories: cur.categories } : undefined}
        fields={[{ key: 'name', label: 'Full name' }, { key: 'department', label: 'Department', type: 'select', options: DEPTS }, { key: 'categories', label: 'Categories', type: 'select', options: CATS }]}
        onSubmit={(v) => {
          if (cur) { db.patch('buyers', cur.id, { name: v.name, department: v.department, categories: v.categories }); db.log(`Edited buyer ${v.name}`, 'Buyers', cur.name, v.name); toast(`${v.name} updated`) }
          else { const id = `BUY-${201 + d.buyers.length + Math.floor(Math.random() * 90)}`; db.add('buyers', { id, name: v.name, department: v.department, categories: v.categories, pending: 0, approved: 0, spend: 0 }, false); db.log(`Added buyer ${v.name}`, 'Buyers', '—', id); toast(`${v.name} added`) }
        }} />
      <ConfirmDialog open={!!del} danger title={`Remove ${del?.name}?`} body="They will no longer be able to raise purchase requests. Past requests stay in the history." confirmLabel="Remove buyer" onClose={() => setDel(null)} onConfirm={() => { if (del) { db.remove('buyers', del.id); db.log(`Removed buyer ${del.name}`, 'Buyers', del.id, '—'); toast(`${del.name} removed`, 'info') } }} />
    </Page>
  )
}

const Requests = () => <Page title="Buyer Purchase Requests" desc="Every request raised by buyers, from draft to purchase order."><ReqTable /></Page>

const Approvals = () => {
  const { d, pn, vn } = useB()
  const q = d.requests.filter((r) => r.status === 'Pending')
  const decide = (id: string, to: 'Approved' | 'Rejected') => { db.patch('requests', id, { status: to }); db.log(`${to === 'Approved' ? 'Approved' : 'Rejected'} ${id}`, 'Buyers', 'Pending', to); toast(`${id} ${to.toLowerCase()}`, to === 'Approved' ? 'success' : 'info') }
  return (
    <Page title="Approval Queue" desc="Requests from buyers waiting on your decision." actions={q.length > 1 ? <Button variant="primary" icon={Check} onClick={() => q.forEach((r) => decide(r.id, 'Approved'))}>Approve all ({q.length})</Button> : undefined}>
      {q.length === 0 ? <Card><EmptyState icon={ClipboardList} title="Queue is clear" body="New buyer requests will appear here for approval." /></Card> : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{q.map((r) => (
          <Card key={r.id} className="p-5" hover>
            <div className="flex items-center justify-between"><b className="text-heading">{r.id}</b><Badge tone="warning">Pending</Badge></div>
            <p className="mt-3 text-sm font-medium text-heading">{pn(r.sku)}</p><p className="text-[13px] text-text-2">{r.qty} units · {vn(r.vendorId)}</p>
            <p className="mt-2 text-xl font-bold text-heading">{money(r.value)}</p><p className="text-xs text-text-2">{r.buyer} · {r.date}</p>
            <div className="mt-4 flex gap-2"><Button variant="primary" size="sm" icon={Check} onClick={() => decide(r.id, 'Approved')}>Approve</Button><Button size="sm" icon={X} onClick={() => decide(r.id, 'Rejected')}>Reject</Button></div>
          </Card>))}</div>)}
    </Page>
  )
}

const History = () => {
  const { d, pn, vn } = useB()
  const rows = d.requests.filter((r) => r.status !== 'Pending')
  return (
    <Page title="Purchase History" desc="Decided requests and the purchase orders that followed.">
      <KpiRow cols={4} items={[{ label: 'Decided requests', value: rows.length }, { label: 'Converted to PO', value: rows.filter((r) => r.status === 'Converted').length, status: 'Healthy' }, { label: 'Rejected', value: rows.filter((r) => r.status === 'Rejected').length, hint: 'declined' }, { label: 'Purchased value', value: rows.filter((r) => r.status === 'Converted').reduce((a, r) => a + r.value, 0), format: compact }]} />
      <DataTable rows={rows} searchOf={(r) => `${r.id} ${r.buyer} ${pn(r.sku)} ${vn(r.vendorId)}`} empty={{ title: 'No history yet', body: 'Approved and rejected requests appear here.' }}
        cols={[{ key: 'id', label: 'Request', render: (r) => <b className="text-heading">{r.id}</b> }, { key: 'date', label: 'Date' }, { key: 'buyer', label: 'Buyer' }, { key: 'sku', label: 'Product', render: (r) => pn(r.sku) }, { key: 'v', label: 'Vendor', render: (r) => vn(r.vendorId) }, { key: 'value', label: 'Value', align: 'right', render: (r) => money(r.value) }, { key: 'status', label: 'Outcome', render: (r) => <StatusBadge s={r.status} /> }]} />
    </Page>
  )
}

const Spend = () => {
  const { d, rows, vn } = useB()
  const byV = d.vendors.map((v) => ({ v, amt: d.requests.filter((r) => r.vendorId === v.id && ['Approved', 'Converted'].includes(r.status)).reduce((a, r) => a + r.value, 0) })).sort((a, b) => b.amt - a.amt)
  const byDept = DEPTS.map((x) => ({ name: x, value: d.buyers.filter((b) => b.department === x).reduce((a, b) => a + b.spend, 0) })).filter((x) => x.value)
  const total = d.buyers.reduce((a, b) => a + b.spend, 0)
  return (
    <Page title="Spend Analysis" desc="Where procurement budget goes, by buyer, department and vendor.">
      <KpiRow cols={3} items={[{ label: 'Total buyer spend', value: total, format: compact, trend: 5.6, prev: 'last quarter' }, { label: 'Committed (approved)', value: d.requests.filter((r) => r.status === 'Approved').reduce((a, r) => a + r.value, 0), format: compact, hint: 'not yet ordered' }, { label: 'Top buyer share', value: (100 * Math.max(0, ...d.buyers.map((b) => b.spend))) / Math.max(1, total), format: (n) => `${Math.round(n)}%` }]} />
      <Grid>
        <Panel title="By department"><Donut data={byDept} center={compact(total)} /></Panel>
        <Panel title="Approved request value by vendor"><BarList items={byV.map(({ v, amt }) => ({ label: vn(v.id), value: amt, display: money(amt) }))} /></Panel>
      </Grid>
      <Panel title="Buyer spend vs pending requests"><Chart type="bar" height={260} fmt={compact} data={rows.map((b) => ({ name: b.name.split(' ')[0], Spend: b.spend, Pending: d.requests.filter((r) => r.buyer === b.name && r.status === 'Pending').reduce((a, r) => a + r.value, 0) }))} series={[{ key: 'Spend', label: 'Spend' }, { key: 'Pending', label: 'Pending value', color: 'var(--purple)' }]} /></Panel>
    </Page>
  )
}

export const screens: Record<string, () => ReactNode> = { overview: Overview, 'buyer-directory': Directory, 'purchase-requests': Requests, 'approval-queue': Approvals, 'purchase-history': History, 'spend-analysis': Spend }
