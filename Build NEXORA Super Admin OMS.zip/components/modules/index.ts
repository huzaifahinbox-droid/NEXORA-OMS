import type { ReactNode } from 'react'
import { screens as customers } from './customers'
import { screens as orders } from './orders'
import { screens as procurement } from './procurement'
import { screens as inventory } from './inventory'
import { screens as forecast } from './forecast'
import { screens as shipments } from './shipments'
import { screens as warehouse } from './warehouse'
import { screens as logistics } from './logistics'
import { screens as logisticsActions } from './logistics-actions'
import { screens as delivery } from './delivery'
import { screens as supply } from './supply'
import { screens as vendors } from './vendors'
import { screens as buyers } from './buyers'
import { screens as support } from './support'
import { screens as billing } from './billing'
import { screens as users } from './users'

export const REGISTRY: Record<string, Record<string, () => ReactNode>> = {
  'customer-management': customers,
  'order-management': orders,
  'order-procurement': procurement,
  'inventory-management': inventory,
  'inventory-forecasting': forecast,
  'shipment-management': shipments,
  'warehouse-management': warehouse,
  'logistics-management': logistics,
  'logistics-actions': logisticsActions,
  'delivery-not-happening': delivery,
  'supply-chain-management': supply,
  vendors,
  buyers,
  'customer-support': support,
  'account-billing': billing,
  'user-management': users,
}
