'use client'
import { useEffect, useState, type ReactNode } from 'react'
import { Plus, UserPlus } from 'lucide-react'
import { Badge, Button, Card, ConfirmDialog, DataTable, EmptyState, StatusBadge, Tabs, Toggle, toast } from '@/components/ui/core'
import { BarList, Feed, Grid, KpiRow, Page, Panel, RecordModal } from '@/components/blocks'
import { Chart, Donut } from '@/components/charts/charts'
import { createStore } from '@/lib/store'
import { db, useDB } from '@/lib/db'
import { spark } from '@/lib/metrics'
import type { Dept, User } from '@/types'

const ROLES = ['Super Admin', 'Operations Manager', 'Warehouse Manager', 'Procurement Lead', 'Logistics Manager', 'Finance Manager', 'Support Agent', 'Analyst']
const MODS = ['Customers', 'Orders', 'Procurement', 'Inventory', 'Shipments', 'Warehouses', 'Logistics', 'Vendors', 'Support', 'Billing', 'Users']
const ACTS = ['View', 'Create', 'Edit', 'Delete'] as const
type Matrix = Record<string, Record<string, boolean[]>>
const defMatrix = (): { m: Matrix } => ({ m: Object.fromEntries(ROLES.map((r) => [r, Object.fromEntries(MODS.map((mod) => {
  if (r === 'Super Admin') return [mod, [true, true, true, true]]
  const own = ({ 'Operations Manager': ['Orders', 'Shipments', 'Logistics', 'Customers'], 'Warehouse Manager': ['Inventory', 'Warehouses'], 'Procurement Lead': ['Procurement', 'Vendors', 'Inventory'], 'Logistics Manager': ['Shipments', 'Logistics'], 'Finance Manager': ['Billing', 'Vendors'], 'Support Agent': ['Support', 'Customers'] } as Record<string, string[]>)[r] ?? []
  return [mod, own.includes(mod) ? [true, true, true, r !== 'Support Agent'] : [r === 'Analyst' || mod === 'Orders', false, false, false]]
}))])) })
const permStore = createStore('nexora-perms-v1', defMatrix)
const deptOpts = (d: { depts: Dept[] }) => d.depts.map((x) => x.name)

const Overview = () => {
  const d = useDB()
  const act = d.users.filter((u) => u.status === 'Active').length
  return (
    <Page title="User Management" desc="Team access, roles and recent administrative activity.">
      <KpiRow cols={4} items={[{ label: 'Total users', value: d.users.length, trend: 3.4, prev: 'last month', spark: spark(1) }, { label: 'Active', value: act, status: 'Healthy' }, { label: 'Pending invites', value: d.users.filter((u) => u.status === 'Invited').length, status: 'Attention' }, { label: 'Suspended', value: d.users.filter((u) => u.status === 'Suspended').length, hint: 'blocked from sign-in' }]} />
      <Grid>
        <Panel title="Users by role"><BarList items={ROLES.map((r) => ({ label: r, value: d.users.filter((u) => u.role === r).length })).filter((x) => x.value)} /></Panel>
        <Panel title="Users by department"><Donut data={d.depts.map((x) => ({ name: x.name, value: d.users.filter((u) => u.department === x.name).length })).filter((x) => x.value)} center={`${d.users.length}`} /></Panel>
      </Grid>
      <Panel title="Recent activity"><Feed items={d.audit.slice(0, 5).map((a) => ({ title: a.action, sub: `${a.user} · ${a.module}`, time: a.time }))} /></Panel>
    </Page>
  )
}

const Directory = () => {
  const d = useDB()
  const [edit, setEdit] = useState<User | 'new' | null>(null)
  const [del, setDel] = useState<User | null>(null)
  const [sus, setSus] = useState<User | null>(null)
  const cur = edit && edit !== 'new' ? edit : undefined
  return (
    <Page title="User Directory" desc="Invite teammates and manage who has access." actions={<Button variant="primary" icon={UserPlus} onClick={() => setEdit('new')}>Invite user</Button>}>
      <DataTable rows={d.users} searchOf={(u) => `${u.name} ${u.email} ${u.role} ${u.department}`} empty={{ title: 'No users', body: 'Invite your first teammate.', cta: 'Invite user', onCta: () => setEdit('new') }}
        cols={[{ key: 'name', label: 'User', render: (u) => <div><b className="text-heading">{u.name}</b><div className="text-xs text-muted">{u.email}</div></div> }, { key: 'role', label: 'Role' }, { key: 'department', label: 'Department' }, { key: 'lastActive', label: 'Last active' }, { key: 'status', label: 'Status', render: (u) => <StatusBadge s={u.status} /> }]}
        actions={(u) => <><Button size="sm" onClick={() => setEdit(u)}>Edit</Button>{u.role !== 'Super Admin' && <>{u.status === 'Suspended' ? <Button size="sm" onClick={() => { db.patch('users', u.id, { status: 'Active' }); db.log(`Reactivated ${u.name}`, 'Users', 'Suspended', 'Active'); toast(`${u.name} reactivated`) }}>Reactivate</Button> : u.status === 'Active' && <Button size="sm" variant="ghost" onClick={() => setSus(u)}>Suspend</Button>}<Button size="sm" variant="ghost" onClick={() => setDel(u)}>Remove</Button></>}</>} />
      <RecordModal open={!!edit} onClose={() => setEdit(null)} title={cur ? `Edit ${cur.name}` : 'Invite user'} submitLabel={cur ? 'Save changes' : 'Send invitation'}
        initial={cur ? { name: cur.name, email: cur.email, role: cur.role, department: cur.department } : undefined}
        fields={[{ key: 'name', label: 'Full name' }, { key: 'email', label: 'Work email' }, { key: 'role', label: 'Role', type: 'select', options: ROLES }, { key: 'department', label: 'Department', type: 'select', options: deptOpts(d) }]}
        onSubmit={(v) => {
          if (!/^\S+@\S+\.\S+$/.test(v.email)) { toast('Enter a valid email address', 'info'); return }
          if (cur) { db.patch('users', cur.id, { name: v.name, email: v.email, role: v.role, department: v.department }); db.log(`Edited user ${v.name}`, 'Users', cur.role, v.role); toast(`${v.name} updated`) }
          else { db.add('users', { id: `USR-${d.users.length + 1 + Math.floor(Math.random() * 90)}`, name: v.name, email: v.email, role: v.role, department: v.department, lastActive: '—', status: 'Invited' }, false); db.log(`Invited ${v.email}`, 'Users', '—', v.role); toast(`Invitation sent to ${v.email}`) }
        }} />
      <ConfirmDialog open={!!sus} title={`Suspend ${sus?.name}?`} body="They will be signed out and cannot sign in until reactivated." confirmLabel="Suspend" onClose={() => setSus(null)} onConfirm={() => { if (sus) { db.patch('users', sus.id, { status: 'Suspended' }); db.log(`Suspended ${sus.name}`, 'Users', 'Active', 'Suspended'); toast(`${sus.name} suspended`, 'info') } }} />
      <ConfirmDialog open={!!del} danger title={`Remove ${del?.name}?`} body="Their access is revoked permanently. Their past activity stays in the audit log." confirmLabel="Remove user" onClose={() => setDel(null)} onConfirm={() => { if (del) { db.remove('users', del.id); db.log(`Removed user ${del.name}`, 'Users', del.status, '—'); toast(`${del.name} removed`, 'info') } }} />
    </Page>
  )
}

const Roles = () => {
  const d = useDB()
  const { m } = permStore.use()
  const [role, setRole] = useState(ROLES[1])
  useEffect(() => { permStore.hydrate() }, [])
  const toggle = (r: string, mod: string, i: number) => {
    if (r === 'Super Admin') { toast('Super Admin permissions cannot be changed', 'info'); return }
    const row = [...(m[r]?.[mod] ?? [false, false, false, false])]
    row[i] = !row[i]
    if (i > 0 && row[i]) row[0] = true
    if (i === 0 && !row[0]) row.fill(false)
    permStore.set({ m: { ...m, [r]: { ...m[r], [mod]: row } } })
    db.log(`${row[i] ? 'Granted' : 'Revoked'} ${ACTS[i]} on ${mod} for ${r}`, 'Users', row[i] ? 'Off' : 'On', row[i] ? 'On' : 'Off')
  }
  const cnt = (r: string) => MODS.reduce((a, mod) => a + (m[r]?.[mod] ?? []).filter(Boolean).length, 0)
  return (
    <Page title="Roles & Permissions" desc="Control what each role can view, create, edit and delete in every module." actions={<Button onClick={() => { permStore.reset(); toast('Permissions reset to defaults', 'info') }}>Reset defaults</Button>}>
      <Tabs value={role} onChange={setRole} options={ROLES} />
      <Card className="overflow-x-auto scroll-thin">
        <table className="w-full min-w-[560px] text-[13px]">
          <thead className="bg-surface-2 text-left text-xs font-semibold uppercase tracking-wide text-text-2"><tr><th className="px-4 py-3">Module</th>{ACTS.map((a) => <th key={a} className="px-4 py-3 text-center">{a}</th>)}</tr></thead>
          <tbody className="divide-y divide-line">{MODS.map((mod) => <tr key={mod} className="hover:bg-hover"><td className="px-4 py-3 font-medium text-heading">{mod}</td>{ACTS.map((a, i) => <td key={a} className="px-4 py-3"><div className="flex justify-center"><Toggle label={`${role} ${a} ${mod}`} checked={m[role]?.[mod]?.[i] ?? false} onChange={() => toggle(role, mod, i)} /></div></td>)}</tr>)}</tbody>
        </table>
      </Card>
      <Panel title="Role summary" sub="Permissions granted and users assigned"><BarList items={ROLES.map((r) => ({ label: r, value: cnt(r), max: MODS.length * 4, display: `${cnt(r)} of ${MODS.length * 4} · ${d.users.filter((u) => u.role === r).length} users` }))} /></Panel>
    </Page>
  )
}

const Invites = () => {
  const d = useDB()
  const [add, setAdd] = useState(false)
  const [rev, setRev] = useState<User | null>(null)
  const rows = d.users.filter((u) => u.status === 'Invited')
  return (
    <Page title="Pending Invitations" desc="Invitations that have not been accepted yet." actions={<Button variant="primary" icon={Plus} onClick={() => setAdd(true)}>New invitation</Button>}>
      {rows.length === 0 ? <Card><EmptyState icon={UserPlus} title="No pending invitations" body="Invite a teammate to see them here until they join." cta="Invite user" onCta={() => setAdd(true)} /></Card> : (
        <DataTable rows={rows} searchOf={(u) => `${u.name} ${u.email} ${u.role}`}
          cols={[{ key: 'name', label: 'Invitee', render: (u) => <div><b className="text-heading">{u.name}</b><div className="text-xs text-muted">{u.email}</div></div> }, { key: 'role', label: 'Role' }, { key: 'department', label: 'Department' }, { key: 'status', label: 'Status', render: (u) => <Badge tone="warning" dot>Awaiting acceptance</Badge> }]}
          actions={(u) => <><Button size="sm" onClick={() => { db.log(`Resent invitation to ${u.email}`, 'Users', 'Invited', 'Invited'); toast(`Invitation resent to ${u.email}`) }}>Resend</Button><Button size="sm" variant="ghost" onClick={() => setRev(u)}>Revoke</Button><Button size="sm" variant="primary" onClick={() => { db.patch('users', u.id, { status: 'Active', lastActive: 'just now' }); db.log(`${u.name} accepted invitation`, 'Users', 'Invited', 'Active'); toast(`${u.name} is now active`) }}>Mark accepted</Button></>} />)}
      <RecordModal open={add} onClose={() => setAdd(false)} title="Invite user" submitLabel="Send invitation" fields={[{ key: 'name', label: 'Full name' }, { key: 'email', label: 'Work email' }, { key: 'role', label: 'Role', type: 'select', options: ROLES }, { key: 'department', label: 'Department', type: 'select', options: deptOpts(d) }]}
        onSubmit={(v) => { if (!/^\S+@\S+\.\S+$/.test(v.email)) { toast('Enter a valid email address', 'info'); return } db.add('users', { id: `USR-${d.users.length + 1 + Math.floor(Math.random() * 90)}`, name: v.name, email: v.email, role: v.role, department: v.department, lastActive: '—', status: 'Invited' }, false); db.log(`Invited ${v.email}`, 'Users', '—', v.role); toast(`Invitation sent to ${v.email}`) }} />
      <ConfirmDialog open={!!rev} danger title={`Revoke invitation for ${rev?.name}?`} body="The invite link stops working immediately." confirmLabel="Revoke" onClose={() => setRev(null)} onConfirm={() => { if (rev) { db.remove('users', rev.id); db.log(`Revoked invitation ${rev.email}`, 'Users', 'Invited', '—'); toast('Invitation revoked', 'info') } }} />
    </Page>
  )
}

const Departments = () => {
  const d = useDB()
  const [edit, setEdit] = useState<Dept | 'new' | null>(null)
  const [del, setDel] = useState<Dept | null>(null)
  const cur = edit && edit !== 'new' ? edit : undefined
  return (
    <Page title="Departments" desc="Organise your team into departments with a named head." actions={<Button variant="primary" icon={Plus} onClick={() => setEdit('new')}>Add department</Button>}>
      <Panel title="Headcount"><Chart type="bar" legend={false} height={220} data={d.depts.map((x) => ({ name: x.name, value: x.members }))} series={[{ key: 'value', label: 'Members' }]} /></Panel>
      <DataTable rows={d.depts} searchOf={(x) => `${x.name} ${x.head}`} empty={{ title: 'No departments', body: 'Create your first department.', cta: 'Add department', onCta: () => setEdit('new') }}
        cols={[{ key: 'name', label: 'Department', render: (x) => <b className="text-heading">{x.name}</b> }, { key: 'head', label: 'Head' }, { key: 'members', label: 'Members', align: 'right' }, { key: 'accounts', label: 'Platform users', align: 'right', render: (x) => d.users.filter((u) => u.department === x.name).length }]}
        actions={(x) => <><Button size="sm" onClick={() => setEdit(x)}>Edit</Button><Button size="sm" variant="ghost" onClick={() => setDel(x)}>Delete</Button></>} />
      <RecordModal open={!!edit} onClose={() => setEdit(null)} title={cur ? `Edit ${cur.name}` : 'Add department'} initial={cur ? { name: cur.name, head: cur.head, members: String(cur.members) } : undefined}
        fields={[{ key: 'name', label: 'Department name' }, { key: 'head', label: 'Head', type: 'select', options: d.users.map((u) => u.name) }, { key: 'members', label: 'Members', type: 'number' }]}
        onSubmit={(v) => {
          const members = parseInt(v.members, 10) || 0
          if (cur) { db.patch('depts', cur.id, { name: v.name, head: v.head, members }); db.log(`Edited department ${v.name}`, 'Users', cur.name, v.name); toast(`${v.name} updated`) }
          else { db.add('depts', { id: `DEP-${d.depts.length + 1 + Math.floor(Math.random() * 90)}`, name: v.name, head: v.head, members }, false); db.log(`Created department ${v.name}`, 'Users', '—', v.name); toast(`${v.name} created`) }
        }} />
      <ConfirmDialog open={!!del} danger title={`Delete ${del?.name}?`} body={`${d.users.filter((u) => u.department === del?.name).length} platform users are in this department. They keep their access but lose the department label.`} confirmLabel="Delete department" onClose={() => setDel(null)} onConfirm={() => { if (del) { db.remove('depts', del.id); db.log(`Deleted department ${del.name}`, 'Users', del.name, '—'); toast(`${del.name} deleted`, 'info') } }} />
    </Page>
  )
}

const Activity = () => {
  const d = useDB()
  const [mod, setMod] = useState('All')
  const mods = ['All', ...new Set(d.audit.map((a) => a.module))]
  const byUser = [...new Set(d.audit.map((a) => a.user))].map((u) => ({ label: u, value: d.audit.filter((a) => a.user === u).length })).sort((a, b) => b.value - a.value).slice(0, 6)
  return (
    <Page title="User Activity" desc="Who did what across the workspace, from the audit trail.">
      <KpiRow cols={3} items={[{ label: 'Events logged', value: d.audit.length }, { label: 'Active contributors', value: new Set(d.audit.map((a) => a.user)).size }, { label: 'Modules touched', value: new Set(d.audit.map((a) => a.module)).size }]} />
      <Panel title="Most active users"><BarList items={byUser} /></Panel>
      <DataTable rows={d.audit.filter((a) => mod === 'All' || a.module === mod)} searchOf={(a) => `${a.user} ${a.action} ${a.module}`} filters={<select aria-label="Filter by module" value={mod} onChange={(e) => setMod(e.target.value)} className="h-10 rounded-lg border border-line-strong bg-surface px-3 text-sm text-heading">{mods.map((x) => <option key={x}>{x}</option>)}</select>}
        cols={[{ key: 'time', label: 'Time' }, { key: 'user', label: 'User', render: (a) => <b className="text-heading">{a.user}</b> }, { key: 'action', label: 'Action' }, { key: 'module', label: 'Module', render: (a) => <Badge tone="primary">{a.module}</Badge> }, { key: 'change', label: 'Change', render: (a) => <span className="text-text-2">{a.before} → {a.after}</span> }, { key: 'device', label: 'Device' }]} />
    </Page>
  )
}

export const screens: Record<string, () => ReactNode> = { overview: Overview, 'user-directory': Directory, 'roles-permissions': Roles, 'pending-invitations': Invites, departments: Departments, activity: Activity }
