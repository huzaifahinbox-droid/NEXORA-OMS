'use client'
import { useState, type ReactNode } from 'react'
import { Download, Plus } from 'lucide-react'
import { Badge, Button, DataTable, Modal, StatusBadge, Tabs, toast } from '@/components/ui/core'
import { BarList, Feed, Grid, KpiRow, Page, Panel, RecordModal } from '@/components/blocks'
import { Chart, Donut } from '@/components/charts/charts'
import { db, compact, money, useDB } from '@/lib/db'
import { PLANS, useAuth } from '@/lib/session'
import { monthly, spark } from '@/lib/metrics'
import type { Invoice, Txn } from '@/types'

const sum = (a: Txn[]) => a.reduce((s, t) => s + t.amount, 0)
const settled = (d: { txns: Txn[] }) => d.txns.filter((t) => t.status === 'Settled')
const METHODS = ['UPI', 'Card', 'Net Banking', 'COD', 'Wallet']
const tCols = (extra?: boolean) => [{ key: 'id', label: 'Transaction', render: (t: Txn) => <b className="text-heading">{t.id}</b> }, { key: 'type', label: 'Type' }, { key: 'orderId', label: extra ? 'Reference' : 'Order' }, { key: 'method', label: 'Method' }, { key: 'amount', label: 'Amount', align: 'right' as const, render: (t: Txn) => <span className={t.amount < 0 ? 'text-danger' : 'text-heading'}>{t.amount < 0 ? '-' : ''}{money(t.amount)}</span> }, { key: 'date', label: 'Date' }, { key: 'status', label: 'Status', render: (t: Txn) => <StatusBadge s={t.status} /> }]
const retry = (t: Txn) => { db.patch('txns', t.id, { status: 'Settled' }); db.log(`Retried ${t.id}`, 'Billing', t.status, 'Settled'); toast(`${t.id} settled`) }

const Overview = () => {
  const d = useDB()
  const s = settled(d)
  const inc = sum(s.filter((t) => t.type === 'Payment'))
  const due = d.invoices.filter((i) => i.status !== 'Paid')
  return (
    <Page title="Billing Overview" desc="Cash position, invoices and transaction health.">
      <KpiRow cols={4} items={[{ label: 'Collected revenue', value: inc, format: compact, trend: 7.3, prev: 'last month', spark: spark(1) }, { label: 'Outstanding invoices', value: due.reduce((a, i) => a + i.amount + i.tax, 0), format: compact, status: due.length ? 'Attention' : 'Healthy', hint: `${due.length} invoices` }, { label: 'Refunds issued', value: Math.abs(sum(d.txns.filter((t) => t.type === 'Refund' && t.status === 'Settled'))), format: compact, trend: 2.0, invert: true, prev: 'last month' }, { label: 'Failed transactions', value: d.txns.filter((t) => t.status === 'Failed').length, status: 'Critical', hint: 'retry available' }]} />
      <Grid>
        <Panel title="Revenue trend" sub="Last 6 months"><Chart height={240} fmt={compact} data={monthly(inc / 5, 6, 3)} series={[{ key: 'value', label: 'Revenue' }]} legend={false} /></Panel>
        <Panel title="Recent transactions"><Feed items={d.txns.slice(0, 6).map((t) => ({ title: `${t.id} · ${t.type}`, sub: `${t.method} · ${t.orderId}`, time: `${t.amount < 0 ? '-' : ''}${money(t.amount)}`, badge: t.status }))} /></Panel>
      </Grid>
    </Page>
  )
}

const Financial = () => {
  const d = useDB()
  const s = settled(d)
  const by = (type: Txn['type']) => Math.abs(sum(s.filter((t) => t.type === type)))
  const net = by('Payment') - by('Refund') - by('Fee') - by('Payout')
  const pend = d.txns.filter((t) => t.status === 'Pending')
  return (
    <Page title="Financial Overview" desc="Income, outflows and net position from settled transactions.">
      <KpiRow cols={5} items={[{ label: 'Payments in', value: by('Payment'), format: compact, trend: 6.1, prev: 'last month' }, { label: 'Refunds', value: by('Refund'), format: compact, invert: true, trend: 1.2, prev: 'last month' }, { label: 'Fees', value: by('Fee'), format: compact }, { label: 'Payouts', value: by('Payout'), format: compact }, { label: 'Net position', value: Math.max(0, net), format: compact, status: net >= 0 ? 'Healthy' : 'Critical', hint: `${compact(Math.abs(sum(pend)))} pending` }]} />
      <Grid>
        <Panel title="Money in vs out"><Chart type="bar" height={260} fmt={compact} data={['Payment', 'Refund', 'Fee', 'Payout'].map((t) => ({ name: t, value: by(t as Txn['type']) }))} series={[{ key: 'value', label: 'Amount' }]} legend={false} /></Panel>
        <Panel title="Receivables vs payables"><BarList items={[{ label: 'Customer payments settled', value: by('Payment'), display: money(by('Payment')) }, { label: 'Pending settlement', value: Math.abs(sum(pend)), display: money(Math.abs(sum(pend))), tone: 'warning', max: by('Payment') }, { label: 'Vendor invoices due', value: d.invoices.filter((i) => i.status !== 'Paid').reduce((a, i) => a + i.amount + i.tax, 0), display: money(d.invoices.filter((i) => i.status !== 'Paid').reduce((a, i) => a + i.amount + i.tax, 0)), tone: 'danger', max: by('Payment') }]} /></Panel>
      </Grid>
    </Page>
  )
}

const Transactions = () => {
  const d = useDB()
  const [f, setF] = useState('All')
  const rows = d.txns.filter((t) => f === 'All' || t.type === f)
  return (
    <Page title="Transactions" desc="All payments, refunds, fees and payouts.">
      <DataTable rows={rows} searchOf={(t) => `${t.id} ${t.orderId} ${t.method} ${t.status}`} filters={<Tabs value={f} onChange={setF} options={['All', 'Payment', 'Refund', 'Fee', 'Payout']} />} cols={tCols()}
        actions={(t) => t.status !== 'Settled' ? <Button size="sm" onClick={() => retry(t)}>{t.status === 'Failed' ? 'Retry' : 'Settle'}</Button> : null} />
    </Page>
  )
}

const Invoices = () => {
  const d = useDB()
  const [f, setF] = useState('All')
  const [view, setView] = useState<string | null>(null)
  const inv = d.invoices.find((i) => i.id === view)
  const pay = (i: Invoice) => { db.patch('invoices', i.id, { status: 'Paid' }); db.log(`Marked ${i.id} paid`, 'Billing', i.status, 'Paid'); toast(`${i.id} marked paid`) }
  return (
    <Page title="Invoices" desc="Vendor invoices payable. View, mark paid or download.">
      <DataTable rows={d.invoices.filter((i) => f === 'All' || i.status === f)} searchOf={(i) => `${i.id} ${i.party}`} onRow={(i) => setView(i.id)} filters={<Tabs value={f} onChange={setF} options={['All', 'Due', 'Overdue', 'Paid']} />}
        cols={[{ key: 'id', label: 'Invoice', render: (i) => <b className="text-heading">{i.id}</b> }, { key: 'party', label: 'Party' }, { key: 'amount', label: 'Amount', align: 'right', render: (i) => money(i.amount) }, { key: 'tax', label: 'GST', align: 'right', render: (i) => money(i.tax) }, { key: 'due', label: 'Due' }, { key: 'status', label: 'Status', render: (i) => <StatusBadge s={i.status} /> }]}
        actions={(i) => <><Button size="sm" onClick={() => setView(i.id)}>View</Button><Button size="sm" variant="ghost" icon={Download} onClick={() => toast(`${i.id}.pdf downloaded`, 'info')}>PDF</Button>{i.status !== 'Paid' && <Button size="sm" variant="primary" onClick={() => pay(i)}>Mark paid</Button>}</>} />
      <Modal open={!!inv} onClose={() => setView(null)} title={`Invoice ${inv?.id}`} footer={inv && <><Button icon={Download} onClick={() => toast(`${inv.id}.pdf downloaded`, 'info')}>Download</Button>{inv.status !== 'Paid' && <Button variant="primary" onClick={() => { pay(inv); setView(null) }}>Mark paid</Button>}</>}>
        {inv && <dl className="space-y-2 text-sm">{[['Billed to / from', inv.party], ['Issued', inv.date], ['Due', inv.due], ['Subtotal', money(inv.amount)], ['GST (18%)', money(inv.tax)]].map(([k, v]) => <div key={k} className="flex justify-between"><dt className="text-text-2">{k}</dt><dd className="font-medium text-heading">{v}</dd></div>)}<div className="flex justify-between border-t border-line pt-2 text-base"><dt className="font-semibold text-heading">Total</dt><dd className="font-bold text-heading">{money(inv.amount + inv.tax)}</dd></div><div className="flex justify-between"><dt className="text-text-2">Status</dt><dd><StatusBadge s={inv.status} /></dd></div></dl>}
      </Modal>
    </Page>
  )
}

const Payments = () => {
  const d = useDB()
  const rows = d.txns.filter((t) => t.type === 'Payment' || t.type === 'Payout')
  const pays = d.txns.filter((t) => t.type === 'Payment')
  return (
    <Page title="Payments" desc="Customer payments received and payouts sent.">
      <KpiRow cols={4} items={[{ label: 'Received', value: sum(pays.filter((t) => t.status === 'Settled')), format: compact }, { label: 'Awaiting settlement', value: sum(pays.filter((t) => t.status === 'Pending')), format: compact, status: 'Attention' }, { label: 'Failed', value: pays.filter((t) => t.status === 'Failed').length, status: 'Critical' }, { label: 'Payouts', value: Math.abs(sum(rows.filter((t) => t.type === 'Payout' && t.status === 'Settled'))), format: compact }]} />
      <Grid>
        <Panel title="Payment methods"><Donut data={METHODS.map((m) => ({ name: m, value: pays.filter((t) => t.method === m).length })).filter((x) => x.value)} center={`${pays.length}`} /></Panel>
        <Panel title="Value by method"><BarList items={METHODS.map((m) => ({ label: m, value: sum(pays.filter((t) => t.method === m)), display: money(sum(pays.filter((t) => t.method === m))) }))} /></Panel>
      </Grid>
      <DataTable rows={rows} searchOf={(t) => `${t.id} ${t.method} ${t.orderId}`} cols={tCols()} actions={(t) => t.status !== 'Settled' ? <Button size="sm" onClick={() => retry(t)}>{t.status === 'Failed' ? 'Retry' : 'Settle'}</Button> : null} />
    </Page>
  )
}

const Refunds = () => {
  const d = useDB()
  const [add, setAdd] = useState(false)
  const rows = d.txns.filter((t) => t.type === 'Refund')
  return (
    <Page title="Refunds" desc="Refunds issued to customers." actions={<Button variant="primary" icon={Plus} onClick={() => setAdd(true)}>Issue refund</Button>}>
      <KpiRow cols={3} items={[{ label: 'Total refunded', value: Math.abs(sum(rows.filter((t) => t.status === 'Settled'))), format: compact }, { label: 'Pending', value: rows.filter((t) => t.status === 'Pending').length, status: 'Attention' }, { label: 'Refund rate', value: (100 * rows.length) / Math.max(1, d.txns.filter((t) => t.type === 'Payment').length + rows.length), format: (n) => `${n.toFixed(1)}%`, invert: true, trend: -0.8, prev: 'last month' }]} />
      <DataTable rows={rows} searchOf={(t) => `${t.id} ${t.orderId}`} cols={tCols()} empty={{ title: 'No refunds yet', body: 'Issued refunds appear here.', cta: 'Issue refund', onCta: () => setAdd(true) }} actions={(t) => t.status !== 'Settled' ? <Button size="sm" onClick={() => retry(t)}>{t.status === 'Failed' ? 'Retry' : 'Process'}</Button> : null} />
      <RecordModal open={add} onClose={() => setAdd(false)} title="Issue refund" submitLabel="Issue refund" fields={[{ key: 'orderId', label: 'Order', type: 'select', options: d.orders.slice(0, 30).map((o) => o.id) }, { key: 'amount', label: 'Amount (₹)', type: 'number' }, { key: 'method', label: 'Refund to', type: 'select', options: METHODS }]}
        onSubmit={(v) => { const id = `TXN-${88100 + d.txns.length}`; db.add('txns', { id, type: 'Refund', orderId: v.orderId, amount: -Math.abs(parseInt(v.amount, 10) || 0), method: v.method, date: '2026-10-08', status: 'Pending' }); db.log(`Issued refund ${id}`, 'Billing', '—', 'Pending'); toast(`Refund ${id} initiated`) }} />
    </Page>
  )
}

const Taxes = () => {
  const d = useDB()
  const [filed, setFiled] = useState<string[]>([])
  const out = Math.round(d.orders.filter((o) => !['Cancelled'].includes(o.status)).reduce((a, o) => a + o.total, 0) * 0.18 / 1.18)
  const itc = d.invoices.reduce((a, i) => a + i.tax, 0)
  const periods = [['Sep 2026', 1], ['Aug 2026', 0.92], ['Jul 2026', 0.85]].map(([p, m], i) => ({ id: p as string, period: p as string, out: Math.round(out * (m as number)), itc: Math.round(itc * (m as number)), due: ['2026-10-20', '2026-09-20', '2026-08-20'][i] }))
  return (
    <Page title="Taxes" desc="GST collected on sales, input credit on purchases and filing status.">
      <KpiRow cols={4} items={[{ label: 'Output GST', value: out, format: compact, hint: 'on orders' }, { label: 'Input tax credit', value: itc, format: compact, hint: 'on vendor invoices' }, { label: 'Net payable', value: Math.max(0, out - itc), format: compact, status: 'Attention' }, { label: 'Returns pending', value: periods.filter((p) => !filed.includes(p.id) && p.id === 'Sep 2026').length, hint: 'GSTR-3B' }]} />
      <Panel title="Tax liability by month"><Chart type="bar" height={240} fmt={compact} data={[...periods].reverse().map((p) => ({ name: p.period, Output: p.out, Input: p.itc }))} series={[{ key: 'Output', label: 'Output GST' }, { key: 'Input', label: 'Input credit', color: 'var(--purple)' }]} /></Panel>
      <DataTable rows={periods} cols={[{ key: 'period', label: 'Period', render: (p) => <b className="text-heading">{p.period}</b> }, { key: 'out', label: 'Output GST', align: 'right', render: (p) => money(p.out) }, { key: 'itc', label: 'Input credit', align: 'right', render: (p) => money(p.itc) }, { key: 'net', label: 'Net payable', align: 'right', render: (p) => money(Math.max(0, p.out - p.itc)) }, { key: 'due', label: 'Due' }, { key: 'st', label: 'Status', render: (p) => <Badge tone={p.id !== 'Sep 2026' || filed.includes(p.id) ? 'success' : 'warning'} dot>{p.id !== 'Sep 2026' || filed.includes(p.id) ? 'Filed' : 'Pending'}</Badge> }]}
        actions={(p) => p.id === 'Sep 2026' && !filed.includes(p.id) ? <Button size="sm" variant="primary" onClick={() => { setFiled([...filed, p.id]); db.log(`Filed GSTR-3B ${p.period}`, 'Billing', 'Pending', 'Filed'); toast(`GSTR-3B for ${p.period} filed`) }}>File return</Button> : <Button size="sm" variant="ghost" icon={Download} onClick={() => toast(`Return ${p.period} downloaded`, 'info')}>Download</Button>} />
    </Page>
  )
}

const History = () => {
  const { billing } = useAuth()
  const plan = PLANS.find((p) => p.id === billing.plan) ?? PLANS[1]
  const price = billing.cycle === 'Yearly' ? plan.yearly : plan.monthly
  const rows = ['Oct 2026', 'Sep 2026', 'Aug 2026', 'Jul 2026', 'Jun 2026', 'May 2026'].map((m, i) => ({ id: `SUB-${2610 - i}`, month: m, plan: plan.name, cycle: billing.cycle, amount: price * (billing.cycle === 'Yearly' ? 12 : 1), status: i === 0 ? 'Upcoming' : 'Paid' }))
  return (
    <Page title="Billing History" desc="Your NEXORA subscription charges and receipts.">
      <KpiRow cols={3} items={[{ label: 'Current plan', value: price, format: (n) => `${plan.name} · $${Math.round(n)}/mo`, hint: billing.cycle }, { label: 'Paid to date', value: rows.filter((r) => r.status === 'Paid').reduce((a, r) => a + r.amount, 0), format: (n) => `$${Math.round(n).toLocaleString('en-IN')}` }, { label: 'Next charge', value: rows[0].amount, format: (n) => `$${Math.round(n)}`, hint: 'Nov 1, 2026' }]} />
      <DataTable rows={rows} cols={[{ key: 'id', label: 'Receipt', render: (r) => <b className="text-heading">{r.id}</b> }, { key: 'month', label: 'Period' }, { key: 'plan', label: 'Plan' }, { key: 'cycle', label: 'Cycle' }, { key: 'amount', label: 'Amount', align: 'right', render: (r) => `$${r.amount}` }, { key: 'status', label: 'Status', render: (r) => <StatusBadge s={r.status} /> }]}
        actions={(r) => r.status === 'Paid' ? <Button size="sm" variant="ghost" icon={Download} onClick={() => toast(`${r.id}.pdf downloaded`, 'info')}>Receipt</Button> : null} />
    </Page>
  )
}

export const screens: Record<string, () => ReactNode> = { overview: Overview, 'financial-overview': Financial, transactions: Transactions, invoices: Invoices, payments: Payments, refunds: Refunds, taxes: Taxes, 'billing-history': History }
