'use client'
import { useState, type ReactNode } from 'react'
import Link from 'next/link'
import { Plus } from 'lucide-react'
import { Button, Card, StatusBadge, toast } from '@/components/ui/core'
import { BarList, Grid, Kanban, KpiRow, Page, Panel, RecordModal, Stages } from '@/components/blocks'
import { OrdersTable, useNames } from '@/components/tables'
import { Chart, Donut } from '@/components/charts/charts'
import { db, compact, useDB } from '@/lib/db'
import { series, spark } from '@/lib/metrics'
import { PIPELINE, type Order, type OrderStatus } from '@/types'

const avgTime = ['2m', '14m', '22m', '38m', '26m', '5h', '2.1d']
const href = ['/order-management/new-orders', '/order-management/new-orders', '/order-management/processing-orders', '/order-management/processing-orders', '/order-management/processing-orders', '/order-management/all-orders', '/order-management/all-orders']

function NewOrder({ open, onClose }: { open: boolean; onClose: () => void }) {
  const d = useDB()
  return <RecordModal open={open} onClose={onClose} title="Create order" fields={[{ key: 'customer', label: 'Customer', type: 'select', options: d.customers.map((c) => c.name) }, { key: 'sku', label: 'Product', type: 'select', options: d.products.map((p) => `${p.sku} · ${p.name}`) }, { key: 'qty', label: 'Quantity', type: 'number' }, { key: 'channel', label: 'Channel', type: 'select', options: ['Shopify', 'Amazon', 'Flipkart', 'Manual'] }]}
    onSubmit={(v) => { const sku = v.sku.split(' · ')[0]; const p = d.products.find((x) => x.sku === sku)!; const q = Math.max(1, parseInt(v.qty, 10) || 1); const id = `ORD-${10500 + d.orders.length}`; db.add('orders', { id, customerId: d.customers.find((c) => c.name === v.customer)!.id, sku, qty: q, total: p.price * q, channel: v.channel, status: 'New', date: '2026-10-08', warehouse: d.inventory.find((r) => r.sku === sku)!.warehouse }); db.log(`Created order ${id}`, 'Orders', '—', 'New'); toast(`Order ${id} created`) }} />
}

const Overview = () => {
  const d = useDB()
  const c = (s: OrderStatus) => d.orders.filter((o) => o.status === s).length
  const active = d.orders.length
  return (
    <Page title="Order Overview" desc="Pipeline health, recent activity and exceptions at a glance.">
      <KpiRow items={[{ label: 'Orders in system', value: active, trend: 6.4, prev: 'last week', spark: spark(1) }, { label: 'In fulfillment', value: c('Allocated') + c('Picking') + c('Packed'), trend: 2.2, prev: 'last week', spark: spark(2) }, { label: 'On hold', value: c('On Hold'), trend: -12, invert: true, prev: 'last week', spark: spark(3, false) }, { label: 'Order value', value: d.orders.reduce((a, o) => a + o.total, 0), format: compact, trend: 7.9, prev: 'last week', spark: spark(4) }]} />
      <Panel title="Order pipeline" sub="Click a stage to open the matching queue"><Stages stages={PIPELINE.map((s, i) => ({ label: s, count: c(s), pct: Math.round((c(s) / Math.max(1, active)) * 100), sub: avgTime[i], href: href[i] }))} /></Panel>
      <Grid>
        <Panel title="Orders per day"><Chart data={series('orders', 14)} series={[{ key: 'value', label: 'Orders' }]} legend={false} height={240} /></Panel>
        <Panel title="Exceptions" sub="Orders needing intervention">
          <ul className="divide-y divide-line">{d.orders.filter((o) => o.status === 'On Hold').slice(0, 5).map((o) => <li key={o.id} className="flex items-center justify-between py-2.5 text-sm"><span><b className="text-heading">{o.id}</b> <span className="text-text-2">· {o.reason}</span></span><StatusBadge s="On Hold" /></li>)}</ul>
          <Link href="/order-management/on-hold" className="mt-3 inline-block text-[13px] font-medium text-primary hover:underline">Review all on hold →</Link>
        </Panel>
      </Grid>
      <Panel title="Recent orders" pad={false}><div className="-mt-4"><OrdersTable pageSize={5} /></div></Panel>
    </Page>
  )
}

const AllOrders = () => { const [n, setN] = useState(false); return <Page title="All Orders" desc="Every order across all channels. Click a row for details, or advance it through fulfillment." actions={<Button variant="primary" icon={Plus} onClick={() => setN(true)}>Create order</Button>}><OrdersTable showFilter /><NewOrder open={n} onClose={() => setN(false)} /></Page> }
const NewOrders = () => { const d = useDB(); const n = d.orders.filter((o) => o.status === 'New'); return <Page title="New Orders" desc="Incoming orders awaiting confirmation." actions={<Button variant="primary" disabled={!n.length} onClick={() => { n.forEach((o) => db.setOrderStatus(o.id, 'Confirmed')); toast(`${n.length} orders confirmed`) }}>Confirm all ({n.length})</Button>}><OrdersTable statuses={['New', 'Confirmed']} title="No new orders" /></Page> }
const Processing = () => {
  const d = useDB()
  const c = (s: OrderStatus) => d.orders.filter((o) => o.status === s).length
  return <Page title="Processing Orders" desc="Active fulfillment — allocation, picking and packing."><Stages stages={(['Allocated', 'Picking', 'Packed'] as OrderStatus[]).map((s) => ({ label: s, count: c(s), sub: s === 'Packed' ? 'Ready to ship' : 'In progress' }))} /><OrdersTable statuses={['Allocated', 'Picking', 'Packed']} /></Page>
}
const OnHold = () => {
  const d = useDB()
  const reasons = Object.entries(d.orders.filter((o) => o.status === 'On Hold').reduce<Record<string, number>>((a, o) => ({ ...a, [o.reason ?? 'Other']: (a[o.reason ?? 'Other'] ?? 0) + 1 }), {}))
  return <Page title="Orders On Hold" desc="Orders that need a decision before they can proceed."><Grid><Panel title="Why orders are held">{reasons.length ? <BarList items={reasons.map(([label, value]) => ({ label, value, tone: 'warning' as const }))} /> : <p className="text-sm text-text-2">Nothing on hold.</p>}</Panel><Card className="flex flex-col justify-center p-6"><p className="text-sm text-text-2">Average hold time</p><p className="text-4xl font-bold text-heading">6.4h</p><p className="mt-2 text-sm text-text-2">Release orders once verification is complete to protect SLA.</p></Card></Grid><OrdersTable statuses={['On Hold']} reason title="No orders on hold" /></Page>
}
const Cancelled = () => {
  const d = useDB()
  const rs = Object.entries(d.orders.filter((o) => o.status === 'Cancelled').reduce<Record<string, number>>((a, o) => ({ ...a, [o.reason ?? 'Other']: (a[o.reason ?? 'Other'] ?? 0) + 1 }), {}))
  return <Page title="Cancelled Orders" desc="Cancellation reasons and recoverable revenue."><Grid><Panel title="Cancellation reasons"><Donut data={rs.map(([name, value]) => ({ name, value }))} center={`${rs.reduce((a, [, v]) => a + v, 0)}`} /></Panel><Panel title="Revenue impact"><p className="text-4xl font-bold text-heading">{compact(d.orders.filter((o) => o.status === 'Cancelled').reduce((a, o) => a + o.total, 0))}</p><p className="mt-1 text-sm text-text-2">Cancelled order value this period. Out-of-stock cancellations are preventable with proactive reorders.</p></Panel></Grid><OrdersTable statuses={['Cancelled']} reason title="No cancelled orders" /></Page>
}

type RStage = 'Requested' | 'Approved' | 'Received' | 'Refunded' | 'Rejected'
const RS: RStage[] = ['Requested', 'Approved', 'Received', 'Refunded', 'Rejected']
const Returns = () => {
  const d = useDB()
  const { cust } = useNames()
  const base: Order[] = d.orders.filter((o) => o.status === 'Returned' || o.status === 'Delivered').slice(0, 10)
  const [stage, setStage] = useState<Record<string, RStage>>(() => Object.fromEntries(base.map((o, i) => [o.id, (['Requested', 'Approved', 'Received', 'Refunded', 'Requested', 'Rejected', 'Approved', 'Requested', 'Received', 'Refunded'] as RStage[])[i]])))
  const order: RStage[] = ['Requested', 'Approved', 'Received', 'Refunded']
  return (
    <Page title="Returns" desc="Track return requests from request through refund.">
      <Kanban onMove={(id, from) => { const next = order[from + 1] ?? 'Refunded'; setStage((s) => ({ ...s, [id]: next })); toast(`${id} moved to ${next}`) }}
        columns={RS.map((s) => ({ title: s, tone: s === 'Rejected' ? 'danger' : s === 'Refunded' ? 'success' : 'info', items: base.filter((o) => stage[o.id] === s).map((o) => ({ id: o.id, title: o.id, sub: `${cust(o.customerId)} · ${o.sku}`, tag: s === 'Rejected' || s === 'Refunded' ? undefined : o.channel })) }))} />
    </Page>
  )
}
export const screens: Record<string, () => ReactNode> = { overview: Overview, 'all-orders': AllOrders, 'new-orders': NewOrders, 'processing-orders': Processing, 'on-hold': OnHold, 'cancelled-orders': Cancelled, returns: Returns }
