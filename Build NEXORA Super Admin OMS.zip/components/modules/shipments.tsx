'use client'
import { useState, type ReactNode } from 'react'
import { CheckCircle2, MapPin, Package, Truck, XCircle } from 'lucide-react'
import { Badge, Card, DataTable, EmptyState, SearchBox, StatusBadge, Tabs, toast } from '@/components/ui/core'
import { BarList, Feed, Grid, Kanban, KpiRow, Page, Panel, Split, Timeline } from '@/components/blocks'
import { Chart, Donut } from '@/components/charts/charts'
import { ShipmentActions, ShipmentsTable } from '@/components/tables'
import { db, dbStore, useDB } from '@/lib/db'
import { spark } from '@/lib/metrics'
import { CARRIERS } from '@/data/seed'
import type { Shipment } from '@/types'

export const TODAY = '2026-10-08'
export const SHIP_STATUSES: Shipment['status'][] = ['Scheduled', 'In Transit', 'Out for Delivery', 'Delivered', 'Delayed', 'Failed']
export const isOpen = (s: Shipment) => s.status !== 'Delivered'
export const daysLate = (s: Shipment) => (s.status === 'Delivered' ? 0 : Math.max(0, Math.round((Date.parse(TODAY) - Date.parse(s.eta)) / 86400000)))

export function markDelivered(s: Shipment) {
  db.patch('shipments', s.id, { status: 'Delivered', issue: undefined, sla: 'On track', lastScan: 'Delivered to customer' })
  const o = dbStore.get().orders.find((x) => x.id === s.orderId)
  if (o && o.status === 'Shipped') db.setOrderStatus(o.id, 'Delivered')
  db.log(`Marked ${s.id} delivered`, 'Logistics', s.status, 'Delivered')
  toast(`${s.id} marked delivered`)
}

export function trackEvents(s: Shipment, orderDate?: string) {
  const idx = { Active: 1, Scheduled: 1, 'In Transit': 2, Delayed: 2, 'Out for Delivery': 3, Failed: 3, Delivered: 4 }[s.status]
  const ev = [
    { title: 'Order placed', sub: 'Order confirmed and allocated', time: orderDate ?? '—', icon: Package },
    { title: 'Picked up from warehouse', sub: `Handed to ${s.carrier}`, time: 'Completed', icon: Truck },
    { title: s.status === 'Delayed' ? `Delayed: ${s.issue ?? 'Carrier exception'}` : 'In transit', sub: `Last scan: ${s.lastScan}`, time: idx >= 2 ? 'Completed' : 'Pending', icon: MapPin },
    { title: 'Out for delivery', sub: `Destination ${s.destination}`, time: idx >= 3 ? 'Completed' : 'Pending', icon: Truck },
    s.status === 'Failed' ? { title: `Delivery failed: ${s.issue ?? 'Attempt unsuccessful'}`, sub: 'Awaiting reattempt', time: 'Needs action', icon: XCircle } : { title: 'Delivered', sub: s.status === 'Delivered' ? 'Received by customer' : `ETA ${s.eta}`, time: idx >= 4 ? 'Completed' : 'Pending', icon: CheckCircle2 },
  ]
  return ev.map((e, i) => ({ ...e, done: i <= idx || (s.status === 'Failed' && i === 4) }))
}

export function useShip() {
  const d = useDB()
  const cust = (orderId: string) => { const o = d.orders.find((x) => x.id === orderId); return d.customers.find((c) => c.id === o?.customerId)?.name ?? '—' }
  const count = (st: Shipment['status']) => d.shipments.filter((s) => s.status === st).length
  const byCarrier = CARRIERS.map((c) => { const r = d.shipments.filter((s) => s.carrier === c); return { name: c, r, total: r.length, delivered: r.filter((s) => s.status === 'Delivered').length, delayed: r.filter((s) => s.status === 'Delayed').length, failed: r.filter((s) => s.status === 'Failed').length, breached: r.filter((s) => s.sla === 'Breached').length } })
  return { d, cust, count, byCarrier }
}

export function TrackingView({ carrierView }: { carrierView?: boolean }) {
  const { d, cust } = useShip()
  const [q, setQ] = useState('')
  const [sel, setSel] = useState<string | null>(null)
  const term = q.trim().toLowerCase()
  const matches = term ? d.shipments.filter((s) => `${s.id} ${s.awb} ${s.orderId}`.toLowerCase().includes(term)) : []
  const cur = d.shipments.find((s) => s.id === sel) ?? (matches.length === 1 ? matches[0] : null)
  const order = cur && d.orders.find((o) => o.id === cur.orderId)
  const pick = (list: Shipment[]) => <div className="flex flex-wrap gap-2">{list.map((s) => <button key={s.id} onClick={() => setSel(s.id)} className="rounded-lg border border-line bg-surface px-3 py-2 text-left text-[13px] hover:border-primary"><b className="text-heading">{s.id}</b> <span className="text-text-2">· {s.awb} · {s.carrier}</span></button>)}</div>
  return (
    <Page title={carrierView ? 'Carrier Tracking' : 'Shipment Tracking'} desc={carrierView ? 'Trace any parcel through its carrier network by AWB, shipment or order ID.' : 'Search by AWB, shipment ID or order ID to see the full journey.'}>
      <Card className="space-y-4 p-5">
        <SearchBox value={q} onChange={(v) => { setQ(v); setSel(null) }} placeholder="Search AWB123456, SHP-58291 or ORD-10482…" className="w-full max-w-xl" />
        {!cur && !term && <div><p className="mb-2 text-xs font-medium text-text-2">Recent shipments</p>{pick(d.shipments.slice(0, 6))}</div>}
        {!cur && term && matches.length > 1 && <div><p className="mb-2 text-xs font-medium text-text-2">{matches.length} matches. Select one</p>{pick(matches.slice(0, 12))}</div>}
      </Card>
      {term && matches.length === 0 && <Card><EmptyState title="No shipment found" body={`Nothing matches “${q}”. Check the AWB or order number and try again.`} /></Card>}
      {cur && (
        <Split
          main={<Panel title={`${cur.id} · ${cur.awb}`} sub={`${cur.carrier} to ${cur.destination}`} action={<StatusBadge s={cur.status} />}><Timeline events={trackEvents(cur, order?.date)} /></Panel>}
          side={<Panel title="Shipment details" action={<ShipmentActions s={cur} />}>
            <dl className="space-y-2 text-sm">{[['Order', cur.orderId], ['Customer', cust(cur.orderId)], ['Carrier', cur.carrier], ['Destination', cur.destination], ['ETA', cur.eta], ['Last scan', cur.lastScan], ['Issue', cur.issue ?? 'None']].map(([k, v]) => <div key={k} className="flex justify-between gap-4"><dt className="text-text-2">{k}</dt><dd className="text-right font-medium text-heading">{v}</dd></div>)}<div className="flex justify-between"><dt className="text-text-2">SLA</dt><dd><Badge tone={cur.sla === 'Breached' ? 'danger' : cur.sla === 'At risk' ? 'warning' : 'success'}>{cur.sla}</Badge></dd></div></dl>
          </Panel>}
        />
      )}
    </Page>
  )
}

const Overview = () => {
  const { d, count, byCarrier } = useShip()
  const open = d.shipments.filter(isOpen)
  const otd = Math.round((d.shipments.filter((s) => s.status === 'Delivered').length / Math.max(1, d.shipments.filter((s) => ['Delivered', 'Failed', 'Delayed'].includes(s.status)).length)) * 100)
  return (
    <Page title="Shipment Overview" desc="Every parcel in flight, how it is performing and where it needs attention.">
      <KpiRow cols={6} items={[{ label: 'Total shipments', value: d.shipments.length, trend: 6.2, prev: 'last week', spark: spark(1) }, { label: 'In transit', value: count('In Transit'), hint: 'on the road' }, { label: 'Out for delivery', value: count('Out for Delivery'), hint: 'arriving today' }, { label: 'Delivered', value: count('Delivered'), trend: 4.1, prev: 'last week', spark: spark(3) }, { label: 'Delayed', value: count('Delayed'), status: 'Attention', hint: 'need follow-up' }, { label: 'Failed', value: count('Failed'), status: 'Critical', hint: `${otd}% delivery success` }]} />
      <Grid>
        <Panel title="Status mix"><Donut data={SHIP_STATUSES.map((s) => ({ name: s, value: count(s) })).filter((x) => x.value)} center={`${d.shipments.length}`} /></Panel>
        <Panel title="Shipments by carrier" sub="Open vs delivered"><Chart type="bar" stacked height={220} data={byCarrier.map((c) => ({ name: c.name, Open: c.total - c.delivered, Delivered: c.delivered }))} series={[{ key: 'Open', label: 'Open' }, { key: 'Delivered', label: 'Delivered', color: 'var(--success)' }]} /></Panel>
      </Grid>
      <Grid>
        <Panel title="Exceptions feed" sub="Delayed or failed, newest first"><Feed items={open.filter((s) => s.status === 'Delayed' || s.status === 'Failed').slice(0, 6).map((s) => ({ title: `${s.id} · ${s.destination}`, sub: `${s.carrier} · ${s.issue ?? s.lastScan}`, time: s.eta, badge: s.status }))} /></Panel>
        <Panel title="SLA health by carrier"><BarList items={byCarrier.map((c) => ({ label: c.name, value: c.total - c.breached, max: Math.max(1, c.total), display: `${Math.round(((c.total - c.breached) / Math.max(1, c.total)) * 100)}% within SLA`, tone: c.breached / Math.max(1, c.total) > 0.3 ? 'danger' : c.breached ? 'warning' : 'success' }))} /></Panel>
      </Grid>
    </Page>
  )
}

const Directory = () => {
  const [t, setT] = useState<'All' | Shipment['status']>('All')
  return (
    <Page title="Shipment Directory" desc="Master list of all shipments. Open the Actions menu to reattempt, reroute or escalate." actions={<Tabs value={t} onChange={setT} options={['All', ...SHIP_STATUSES]} />}>
      <ShipmentsTable key={t} statuses={t === 'All' ? undefined : [t]} actions showIssue />
    </Page>
  )
}

const Delivery = () => {
  const { d, count, byCarrier } = useShip()
  const cols: Shipment['status'][] = ['Scheduled', 'In Transit', 'Out for Delivery', 'Delivered']
  const move = (id: string, from: number) => {
    const s = d.shipments.find((x) => x.id === id); if (!s) return
    const to = cols[from + 1]
    if (to === 'Delivered') return markDelivered(s)
    db.patch('shipments', id, { status: to, lastScan: to === 'Out for Delivery' ? 'Out for delivery' : 'Departed hub' })
    db.log(`Moved ${id} to ${to}`, 'Logistics', s.status, to); toast(`${id} is now ${to}`)
  }
  const first = Math.round((count('Delivered') / Math.max(1, count('Delivered') + count('Failed'))) * 100)
  return (
    <Page title="Delivery Management" desc="Run the last mile. Advance parcels from scheduled to delivered.">
      <KpiRow cols={4} items={[{ label: 'Scheduled', value: count('Scheduled') }, { label: 'Out for delivery', value: count('Out for Delivery'), hint: 'in last mile' }, { label: 'First-attempt success', value: first, format: (n) => `${Math.round(n)}%`, trend: 1.8, prev: 'last week' }, { label: 'Needs reattempt', value: count('Failed'), status: count('Failed') ? 'Attention' : 'Healthy' }]} />
      <Kanban columns={cols.map((c) => ({ title: c, tone: c === 'Delivered' ? 'success' : c === 'Out for Delivery' ? 'info' : 'neutral', items: d.shipments.filter((s) => s.status === c).slice(0, c === 'Delivered' ? 6 : 12).map((s) => ({ id: s.id, title: s.id, sub: `${s.destination} · ${s.carrier}`, tag: s.eta.slice(5) })) }))} onMove={move} />
      <Panel title="Delivery outcome by carrier" sub="Delivered vs failed vs delayed"><Chart type="bar" height={240} data={byCarrier.map((c) => ({ name: c.name, Delivered: c.delivered, Failed: c.failed, Delayed: c.delayed }))} series={[{ key: 'Delivered', label: 'Delivered', color: 'var(--success)' }, { key: 'Failed', label: 'Failed', color: 'var(--danger)' }, { key: 'Delayed', label: 'Delayed', color: 'var(--warning)' }]} /></Panel>
      <Panel title="Out for delivery now" pad={false}><div className="-mt-4"><DataTable rows={d.shipments.filter((s) => s.status === 'Out for Delivery')} pageSize={5} cols={[{ key: 'id', label: 'Shipment' }, { key: 'destination', label: 'Destination' }, { key: 'carrier', label: 'Carrier' }, { key: 'eta', label: 'ETA' }, { key: 'status', label: 'Status', render: (s) => <StatusBadge s={s.status} /> }]} empty={{ title: 'Nothing out for delivery', body: 'Move scheduled shipments forward to start the last mile.' }} actions={(s) => <ShipmentActions s={s} compact />} /></div></Panel>
    </Page>
  )
}

export const screens: Record<string, () => ReactNode> = { overview: Overview, 'shipment-directory': Directory, tracking: () => <TrackingView />, 'delivery-management': Delivery }
