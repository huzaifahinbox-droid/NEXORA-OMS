'use client'
import { useState, type ReactNode } from 'react'
import { Plus } from 'lucide-react'
import { Button, DataTable, StatusBadge, toast } from '@/components/ui/core'
import { BarList, Feed, Grid, KpiRow, Page, Panel, RecordModal, Stages } from '@/components/blocks'
import { Chart, Donut } from '@/components/charts/charts'
import { db, dbStore, useDB } from '@/lib/db'
import { spark } from '@/lib/metrics'
import type { Action } from '@/types'

const BASE = '/logistics-actions'
const OWNERS = ['Tarun Bhatt', 'Rahul Menon', 'Maya Joseph', 'Aditi Rao']
const NEXT: Record<string, Action['status']> = { Open: 'In Progress', 'In Progress': 'Done' }

function progress(a: Action, to: Action['status']) {
  db.patch('actions', a.id, { status: to })
  db.log(`${a.kind} ${a.id} to ${to}`, 'Logistics Actions', a.status, to)
  const sh = dbStore.get().shipments.find((s) => s.id === a.shipmentId)
  if (to === 'Done' && sh) {
    if (a.kind === 'Reattempt delivery' && ['Failed', 'Delayed'].includes(sh.status)) db.patch('shipments', sh.id, { status: 'Scheduled', issue: undefined, sla: 'At risk' })
    if (a.kind === 'Update address' && sh.issue) db.patch('shipments', sh.id, { issue: undefined })
    db.notify('Logistics', `${a.kind} completed`, `${a.id} for ${a.shipmentId} was marked done.`, `${BASE}/overview`)
  }
  toast(to === 'Done' ? `${a.id} marked done` : `${a.id} started`)
}

function Board({ title, desc, kinds, noun }: { title: string; desc: string; kinds: string[]; noun: string }) {
  const d = useDB()
  const [f, setF] = useState<string | null>(null)
  const [add, setAdd] = useState(false)
  const all = d.actions.filter((a) => kinds.includes(a.kind))
  const rows = all.filter((a) => !f || a.status === f)
  const n = (s: string) => all.filter((a) => a.status === s).length
  const shipOpts = d.shipments.filter((s) => s.status !== 'Delivered').map((s) => s.id)
  return (
    <Page title={title} desc={desc} actions={<Button variant="primary" icon={Plus} onClick={() => setAdd(true)}>New {noun}</Button>}>
      <Stages onSelect={(l) => setF(f === l ? null : l)} stages={['Open', 'In Progress', 'Done'].map((s) => ({ label: s, count: n(s), active: f === s, sub: s === 'Open' ? `${all.filter((a) => a.status === 'Open' && ['Critical', 'High'].includes(a.priority)).length} urgent` : undefined }))} />
      <DataTable rows={rows} searchOf={(a) => `${a.id} ${a.kind} ${a.shipmentId} ${a.owner}`} empty={{ title: `No ${noun}s here`, body: 'Create one to start tracking the work.', cta: `New ${noun}`, onCta: () => setAdd(true) }}
        cols={[{ key: 'kind', label: 'Action', sort: (a) => a.kind, render: (a) => <div><b className="text-heading">{a.kind}</b><p className="text-xs text-muted">{a.id}</p></div> }, { key: 'shipmentId', label: 'Shipment' }, { key: 'owner', label: 'Owner' }, { key: 'priority', label: 'Priority', render: (a) => <StatusBadge s={a.priority} /> }, { key: 'sla', label: 'SLA', render: (a) => `${a.sla} left` }, { key: 'status', label: 'Status', render: (a) => <StatusBadge s={a.status} /> }]}
        actions={(a) => a.status === 'Done' ? null : <><Button size="sm" onClick={() => progress(a, NEXT[a.status])}>{a.status === 'Open' ? 'Start' : 'Mark done'}</Button>{a.status === 'Open' && <Button size="sm" variant="ghost" onClick={() => progress(a, 'Done')}>Done</Button>}</>} />
      <RecordModal open={add} onClose={() => setAdd(false)} title={`New ${noun}`} initial={{ kind: kinds[0], owner: OWNERS[0], priority: 'Medium', sla: '8' }}
        fields={[{ key: 'kind', label: 'Action', type: 'select', options: kinds }, { key: 'shipmentId', label: 'Shipment', type: 'select', options: shipOpts }, { key: 'owner', label: 'Owner', type: 'select', options: OWNERS }, { key: 'priority', label: 'Priority', type: 'select', options: ['Low', 'Medium', 'High', 'Critical'] }, { key: 'sla', label: 'SLA (hours)', type: 'number' }]}
        onSubmit={(v) => { const a: Action = { id: `ACT-${Date.now() % 1000000}`, kind: v.kind, shipmentId: v.shipmentId, owner: v.owner, priority: v.priority as Action['priority'], sla: `${parseInt(v.sla, 10) || 8}h`, status: 'Open' }; db.add('actions', a); db.log(`Created ${v.kind} ${a.id}`, 'Logistics Actions', '—', 'Open'); toast(`${a.id} created for ${v.shipmentId}`) }} />
    </Page>
  )
}

const Overview = () => {
  const d = useDB()
  const by = (s: Action['status']) => d.actions.filter((a) => a.status === s).length
  const kinds = [...new Set(d.actions.map((a) => a.kind))]
  const urgent = d.actions.filter((a) => a.status !== 'Done' && ['Critical', 'High'].includes(a.priority))
  return (
    <Page title="Logistics Actions" desc="Every manual intervention on shipments, tracked from request to resolution.">
      <KpiRow cols={5} items={[{ label: 'Open', value: by('Open'), status: by('Open') > 4 ? 'Attention' : 'Healthy', spark: spark(1, false) }, { label: 'In progress', value: by('In Progress') }, { label: 'Done', value: by('Done'), trend: 8, prev: 'last week', spark: spark(2) }, { label: 'Urgent', value: urgent.length, status: urgent.length ? 'Critical' : 'Healthy' }, { label: 'Completion rate', value: (by('Done') / Math.max(1, d.actions.length)) * 100, format: (n) => `${Math.round(n)}%` }]} />
      <Panel title="Work queues"><Stages stages={[['Pickup Requests', 'pickup-requests', ['Schedule pickup']], ['Carrier Actions', 'carrier-actions', ['Change carrier', 'Carrier audit']], ['Reattempts', 'delivery-reattempts', ['Reattempt delivery']], ['Escalations', 'escalations', ['Escalate to carrier', 'Contact customer']], ['Address Changes', 'address-changes', ['Update address']]].map(([label, slug, k]) => ({ label: label as string, count: d.actions.filter((a) => (k as string[]).includes(a.kind) && a.status !== 'Done').length, sub: 'open', href: `${BASE}/${slug}` }))} /></Panel>
      <Grid>
        <Panel title="Actions by type"><Chart type="bar" height={240} data={kinds.map((k) => ({ name: k.split(' ')[0], Open: d.actions.filter((a) => a.kind === k && a.status !== 'Done').length, Done: d.actions.filter((a) => a.kind === k && a.status === 'Done').length }))} series={[{ key: 'Open', label: 'Open' }, { key: 'Done', label: 'Done', color: 'var(--success)' }]} stacked /></Panel>
        <Panel title="Priority mix (active)"><Donut data={['Critical', 'High', 'Medium', 'Low'].map((p) => ({ name: p, value: d.actions.filter((a) => a.priority === p && a.status !== 'Done').length })).filter((x) => x.value)} center={`${d.actions.filter((a) => a.status !== 'Done').length}`} /></Panel>
      </Grid>
      <Grid>
        <Panel title="Needs attention first"><Feed items={urgent.slice(0, 6).map((a) => ({ title: `${a.kind} · ${a.shipmentId}`, sub: `${a.owner} · SLA ${a.sla}`, time: a.priority, badge: a.status }))} /></Panel>
        <Panel title="Workload by owner"><BarList items={OWNERS.map((o) => { const c = d.actions.filter((a) => a.owner === o && a.status !== 'Done').length; return { label: o, value: c, display: `${c} active`, tone: c > 3 ? 'warning' : 'primary' } })} /></Panel>
      </Grid>
    </Page>
  )
}

export const screens: Record<string, () => ReactNode> = {
  overview: Overview,
  'pickup-requests': () => <Board title="Pickup Requests" desc="Schedule carrier pickups for ready-to-ship parcels." kinds={['Schedule pickup']} noun="pickup request" />,
  'carrier-actions': () => <Board title="Carrier Actions" desc="Carrier changes and audits to protect delivery performance." kinds={['Change carrier', 'Carrier audit']} noun="carrier action" />,
  'delivery-reattempts': () => <Board title="Delivery Reattempts" desc="Reschedule deliveries that failed or were missed." kinds={['Reattempt delivery']} noun="reattempt" />,
  escalations: () => <Board title="Escalations" desc="Issues escalated to carriers or raised with customers for resolution." kinds={['Escalate to carrier', 'Contact customer']} noun="escalation" />,
  'address-changes': () => <Board title="Address Changes" desc="Corrections to delivery addresses on in-flight shipments." kinds={['Update address']} noun="address change" />,
}
