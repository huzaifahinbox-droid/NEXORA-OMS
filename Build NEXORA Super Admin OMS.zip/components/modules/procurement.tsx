'use client'
import { useState, type ReactNode } from 'react'
import { Check, ClipboardList, Plus, X } from 'lucide-react'
import { Badge, Button, Card, DataTable, EmptyState, StatusBadge, toast } from '@/components/ui/core'
import { Feed, Grid, KpiRow, Page, Panel, RecordModal } from '@/components/blocks'
import { db, compact, inventoryStatus, money, useDB } from '@/lib/db'
import { spark } from '@/lib/metrics'
import type { PurchaseOrder, PurchaseRequest } from '@/types'

export function useProc() {
  const d = useDB()
  const vn = (id: string) => d.vendors.find((v) => v.id === id)?.name ?? id
  const pn = (sku: string) => d.products.find((p) => p.sku === sku)?.name ?? sku
  return { d, vn, pn }
}
export function RequestModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { d, pn } = useProc()
  return <RecordModal open={open} onClose={onClose} title="Create purchase request" fields={[{ key: 'sku', label: 'Product', type: 'select', options: d.products.map((p) => `${p.sku} · ${p.name}`) }, { key: 'qty', label: 'Quantity', type: 'number' }]} onSubmit={(v) => { const sku = v.sku.split(' · ')[0]; const p = d.products.find((x) => x.sku === sku)!; const qty = parseInt(v.qty, 10) || 0; db.add('requests', { id: `PR-${7100 + d.requests.length}`, sku, qty, buyer: 'Aditi Rao', vendorId: p.vendorId, value: Math.round(p.price * 0.45 * qty), status: 'Pending', date: '2026-10-08' }); db.log(`Created purchase request for ${pn(sku)}`, 'Procurement', '—', 'Pending'); toast('Purchase request created') }} />
}
export function ReqTable({ statuses, queue }: { statuses?: PurchaseRequest['status'][]; queue?: boolean }) {
  const { d, vn, pn } = useProc()
  const [add, setAdd] = useState(false)
  const rows = d.requests.filter((r) => !statuses || statuses.includes(r.status))
  return (
    <>
      <DataTable rows={rows} searchOf={(r) => `${r.id} ${r.sku} ${r.buyer} ${vn(r.vendorId)}`} empty={{ title: 'No purchase requests yet.', body: 'Create your first procurement request.', cta: 'Create Request', onCta: () => setAdd(true) }}
        toolbar={<Button variant="primary" size="sm" icon={Plus} onClick={() => setAdd(true)}>New request</Button>}
        cols={[{ key: 'id', label: 'Request', render: (r) => <b className="text-heading">{r.id}</b> }, { key: 'sku', label: 'Product', render: (r) => `${pn(r.sku)} (${r.sku})` }, { key: 'qty', label: 'Qty', align: 'right' }, { key: 'buyer', label: 'Buyer' }, { key: 'vendorId', label: 'Supplier', render: (r) => vn(r.vendorId) }, { key: 'value', label: 'Value', align: 'right', render: (r) => money(r.value) }, { key: 'status', label: 'Status', render: (r) => <StatusBadge s={r.status} /> }]}
        actions={(r) => r.status === 'Pending' ? <><Button size="sm" onClick={() => { db.patch('requests', r.id, { status: 'Approved' }); toast(`${r.id} approved`) }}>Approve</Button><Button size="sm" variant="ghost" onClick={() => { db.patch('requests', r.id, { status: 'Rejected' }); toast(`${r.id} rejected`, 'info') }}>Reject</Button></> : r.status === 'Approved' ? <Button size="sm" onClick={() => { db.patch('requests', r.id, { status: 'Converted' }); db.add('pos', { id: `PO-${9100 + d.pos.length}`, vendorId: r.vendorId, sku: r.sku, qty: r.qty, value: r.value, status: 'Sent', eta: '2026-10-22', date: '2026-10-08' }); toast(`PO created from ${r.id}`) }}>Convert to PO</Button> : null} />
      <RequestModal open={add} onClose={() => setAdd(false)} />
    </>
  )
}
export function POTable({ vendorId }: { vendorId?: string }) {
  const { d, vn, pn } = useProc()
  const rows = d.pos.filter((p) => !vendorId || p.vendorId === vendorId)
  return <DataTable rows={rows} searchOf={(p) => `${p.id} ${p.sku} ${vn(p.vendorId)} ${p.status}`} empty={{ title: 'No purchase orders yet.', body: 'Convert an approved request to create one.' }}
    cols={[{ key: 'id', label: 'PO', render: (p) => <b className="text-heading">{p.id}</b> }, { key: 'vendorId', label: 'Vendor', render: (p) => vn(p.vendorId) }, { key: 'sku', label: 'Product', render: (p) => pn(p.sku) }, { key: 'qty', label: 'Qty', align: 'right' }, { key: 'value', label: 'Value', align: 'right', render: (p) => money(p.value) }, { key: 'eta', label: 'ETA' }, { key: 'status', label: 'Status', render: (p) => <StatusBadge s={p.status} /> }]}
    actions={(p: PurchaseOrder) => p.status !== 'Received' ? <Button size="sm" onClick={() => { db.patch('pos', p.id, { status: 'Received' }); const row = d.inventory.find((r) => r.sku === p.sku); if (row) db.patch('inventory', row.id, { available: row.available + p.qty, incoming: Math.max(0, row.incoming - p.qty) }); db.log(`Received ${p.id}`, 'Procurement', p.status, 'Received'); toast(`${p.id} received — stock updated`) }}>Mark received</Button> : null} />
}

const Overview = () => {
  const { d, vn, pn } = useProc()
  const need = d.inventory.filter((r) => inventoryStatus(r) !== 'In Stock').length
  return (
    <Page title="Procurement Overview" desc="What needs buying, what is on the way, and where suppliers are slipping.">
      <KpiRow cols={5} items={[{ label: 'Pending procurement', value: need, trend: 14, invert: true, prev: 'last week', spark: spark(1, false) }, { label: 'Purchase requests', value: d.requests.filter((r) => r.status === 'Pending').length, hint: 'awaiting approval' }, { label: 'Open POs', value: d.pos.filter((p) => p.status !== 'Received').length, hint: compact(d.pos.filter((p) => p.status !== 'Received').reduce((a, p) => a + p.value, 0)) }, { label: 'Supplier delays', value: d.pos.filter((p) => p.status === 'Delayed').length, status: 'Attention', hint: 'POs past ETA' }, { label: 'Arrivals this week', value: d.pos.filter((p) => ['Sent', 'In Transit'].includes(p.status)).length, hint: 'expected' }]} />
      <Grid>
        <Panel title="Expected arrivals"><Feed items={d.pos.filter((p) => p.status !== 'Received').slice(0, 6).map((p) => ({ title: `${p.id} · ${pn(p.sku)}`, sub: `${vn(p.vendorId)} · ${p.qty} units`, time: p.eta, badge: p.status }))} /></Panel>
        <Panel title="Needs a purchase decision"><Feed items={d.requests.filter((r) => r.status === 'Pending').slice(0, 6).map((r) => ({ title: `${r.id} · ${pn(r.sku)}`, sub: `${r.qty} units · ${r.buyer}`, time: money(r.value) }))} /></Panel>
      </Grid>
    </Page>
  )
}

const Queue = () => {
  const { d, vn, pn } = useProc()
  const rows = d.inventory.filter((r) => inventoryStatus(r) !== 'In Stock').map((r) => { const p = d.products.find((x) => x.sku === r.sku)!; const forecast = Math.round(r.reorder * 1.6); const required = Math.max(0, forecast - r.available - r.incoming); return { id: r.id, sku: r.sku, wh: r.warehouse, stock: r.available, forecast, required, rec: Math.max(100, Math.ceil(required / 50) * 50), vendorId: p.vendorId, arrival: r.incoming ? '2026-10-14' : '—', status: inventoryStatus(r) } })
  return (
    <Page title="Procurement Queue" desc="Stock positions that need replenishment, with AI-recommended quantities.">
      <DataTable rows={rows} searchOf={(r) => `${r.sku} ${pn(r.sku)} ${vn(r.vendorId)}`} empty={{ title: 'Procurement queue is clear', body: 'No SKUs currently need replenishment.' }}
        cols={[{ key: 'sku', label: 'Product', render: (r) => <div><b className="text-heading">{pn(r.sku)}</b><div className="text-xs text-muted">{r.sku} · {r.wh}</div></div> }, { key: 'stock', label: 'Stock', align: 'right' }, { key: 'forecast', label: 'Forecast (14d)', align: 'right' }, { key: 'required', label: 'Required', align: 'right' }, { key: 'rec', label: 'Recommended', align: 'right', render: (r) => <b className="text-primary">{r.rec}</b> }, { key: 'vendorId', label: 'Supplier', render: (r) => vn(r.vendorId) }, { key: 'arrival', label: 'Arrival' }, { key: 'status', label: 'Status', render: (r) => <StatusBadge s={r.status} /> }]}
        actions={(r) => <Button size="sm" variant="primary" onClick={() => { db.add('requests', { id: `PR-${7100 + d.requests.length}`, sku: r.sku, qty: r.rec, buyer: 'Aditi Rao', vendorId: r.vendorId, value: Math.round((d.products.find((p) => p.sku === r.sku)?.price ?? 0) * 0.45 * r.rec), status: 'Pending', date: '2026-10-08' }); toast(`Purchase request created for ${r.sku}`) }}>Create request</Button>} />
    </Page>
  )
}

const Requests = () => <Page title="Purchase Requests" desc="Requests raised by buyers and the AI, from draft to purchase order."><ReqTable /></Page>
const Orders = () => <Page title="Purchase Orders" desc="Orders issued to suppliers. Mark them received to update stock."><POTable /></Page>

const Approvals = () => {
  const { d, vn, pn } = useProc()
  const q = d.requests.filter((r) => r.status === 'Pending')
  return (
    <Page title="Approvals" desc="Purchase requests waiting on a decision.">
      {q.length === 0 ? <Card><EmptyState icon={ClipboardList} title="Nothing awaiting approval" body="New purchase requests will appear here for review." /></Card> : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{q.map((r) => (
          <Card key={r.id} className="p-5" hover>
            <div className="flex items-center justify-between"><b className="text-heading">{r.id}</b><Badge tone="warning">Pending</Badge></div>
            <p className="mt-3 text-sm font-medium text-heading">{pn(r.sku)}</p><p className="text-[13px] text-text-2">{r.qty} units · {vn(r.vendorId)}</p>
            <p className="mt-2 text-xl font-bold text-heading">{money(r.value)}</p><p className="text-xs text-text-2">Requested by {r.buyer}</p>
            <div className="mt-4 flex gap-2"><Button variant="primary" size="sm" icon={Check} onClick={() => { db.patch('requests', r.id, { status: 'Approved' }); db.log(`Approved ${r.id}`, 'Procurement', 'Pending', 'Approved'); toast(`${r.id} approved`) }}>Approve</Button><Button size="sm" icon={X} onClick={() => { db.patch('requests', r.id, { status: 'Rejected' }); toast(`${r.id} rejected`, 'info') }}>Reject</Button></div>
          </Card>))}</div>)}
    </Page>
  )
}

const Assign = () => {
  const { d, vn, pn } = useProc()
  const [sku, setSku] = useState(d.products[0].sku)
  const p = d.products.find((x) => x.sku === sku)!
  const reqs = d.requests.filter((r) => r.sku === sku && ['Pending', 'Approved'].includes(r.status))
  const cands = [...d.vendors.filter((v) => v.category === p.category), ...d.vendors.filter((v) => v.category !== p.category)].slice(0, 3)
  return (
    <Page title="Supplier Assignment" desc="Compare qualified suppliers and assign them to open requests.">
      <Card className="flex flex-wrap items-center gap-4 p-5"><label htmlFor="sa" className="text-sm font-medium text-heading">Product</label><select id="sa" value={sku} onChange={(e) => setSku(e.target.value)} className="h-10 rounded-lg border border-line-strong bg-surface px-3 text-sm text-heading">{d.products.map((x) => <option key={x.sku} value={x.sku}>{x.sku} · {x.name}</option>)}</select><span className="text-sm text-text-2">Current supplier: <b className="text-heading">{vn(p.vendorId)}</b> · {reqs.length} open request(s)</span></Card>
      <div className="grid gap-4 md:grid-cols-3">{cands.map((v, i) => (
        <Card key={v.id} className="p-5" hover>
          <div className="flex items-center justify-between"><b className="text-heading">{v.name}</b>{i === 0 && <Badge tone="primary">Best match</Badge>}</div>
          <dl className="mt-4 space-y-2 text-sm">{[['Reliability', `${v.reliability}%`], ['Lead time', `${v.leadTime} days`], ['Risk', v.risk], ['Compliance', v.compliance]].map(([k, val]) => <div key={k} className="flex justify-between"><dt className="text-text-2">{k}</dt><dd className="font-medium text-heading">{val}</dd></div>)}</dl>
          <Button variant={p.vendorId === v.id ? 'secondary' : 'primary'} className="mt-4 w-full" disabled={p.vendorId === v.id} onClick={() => { db.patch('products', p.sku, { vendorId: v.id }); reqs.forEach((r) => db.patch('requests', r.id, { vendorId: v.id })); db.log(`Assigned ${v.name} to ${pn(sku)}`, 'Procurement', vn(p.vendorId), v.name); toast(`${v.name} assigned to ${pn(sku)}`) }}>{p.vendorId === v.id ? 'Assigned' : 'Assign supplier'}</Button>
        </Card>))}</div>
    </Page>
  )
}
export const screens: Record<string, () => ReactNode> = { overview: Overview, 'procurement-queue': Queue, 'purchase-requests': Requests, 'purchase-orders': Orders, approvals: Approvals, 'supplier-assignment': Assign }
