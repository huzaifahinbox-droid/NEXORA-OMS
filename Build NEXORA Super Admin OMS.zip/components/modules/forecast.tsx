'use client'
import { useMemo, useState, type ReactNode } from 'react'
import { Sparkles } from 'lucide-react'
import { Badge, Button, Card, DataTable, toast } from '@/components/ui/core'
import { BarList, Grid, KpiRow, Page, Panel } from '@/components/blocks'
import { Chart } from '@/components/charts/charts'
import { db, inventoryStatus, useDB } from '@/lib/db'
import { spark } from '@/lib/metrics'

const risk = (avail: number, reorder: number) => (avail === 0 ? 'Critical' : avail < reorder * 0.5 ? 'High' : avail <= reorder ? 'Medium' : 'Low')
const demandSeries = (sku: string) => {
  const seed = sku.charCodeAt(sku.length - 1)
  return Array.from({ length: 21 }, (_, i) => { const base = 42 + (seed % 20) + i * 0.8 + Math.sin(i * 0.7 + seed) * 6; const hist = i < 11; const v = Math.round(base); return { name: `D${i - 10 > 0 ? '+' : ''}${i - 10}`, Actual: hist ? v : null as unknown as number, Forecast: i >= 10 ? v : null as unknown as number, Upper: i >= 10 ? Math.round(v * (1.08 + (i - 10) * 0.012)) : null as unknown as number, Lower: i >= 10 ? Math.round(v * (0.92 - (i - 10) * 0.012)) : null as unknown as number } })
}

const Overview = () => {
  const d = useDB()
  const risky = d.inventory.filter((r) => ['High', 'Critical'].includes(risk(r.available, r.reorder)))
  return (
    <Page title="Forecasting Overview" desc="Expected demand, stockout risk and the actions the model recommends.">
      <KpiRow items={[{ label: 'Expected demand (14d)', value: 3180, trend: 12.4, prev: 'prior 14d', spark: spark(1) }, { label: 'Stockout risk', value: risky.length, status: risky.length > 3 ? 'Critical' : 'Attention', hint: 'high or critical SKUs' }, { label: 'Reorder recommendations', value: d.inventory.filter((r) => inventoryStatus(r) !== 'In Stock').length, hint: 'ready to apply' }, { label: 'Forecast accuracy', value: 91.4, format: (n) => `${n.toFixed(1)}%`, trend: 1.2, prev: 'last month' }]} />
      <Grid><Panel title="Aggregate demand" sub="Actual vs forecast, all SKUs"><Chart type="line" data={demandSeries('SKU-ALL')} series={[{ key: 'Actual', label: 'Actual' }, { key: 'Forecast', label: 'Forecast', color: 'var(--purple)' }]} /></Panel>
        <Panel title="Highest risk SKUs"><BarList items={risky.slice(0, 6).map((r) => ({ label: r.sku, sub: r.warehouse, value: r.reorder - r.available, display: risk(r.available, r.reorder), tone: 'danger' as const }))} /></Panel></Grid>
    </Page>
  )
}
const Demand = () => {
  const d = useDB()
  const [sku, setSku] = useState('SKU-2048')
  const data = useMemo(() => demandSeries(sku), [sku])
  return (
    <Page title="Demand Forecast" desc="Historical demand, predicted demand and the model’s confidence range." actions={<select aria-label="SKU" value={sku} onChange={(e) => setSku(e.target.value)} className="h-10 rounded-lg border border-line-strong bg-surface px-3 text-sm text-heading">{d.products.map((p) => <option key={p.sku} value={p.sku}>{p.sku} · {p.name}</option>)}</select>}>
      <Panel title={`${sku} — units per day`} sub="Forecast horizon: 10 days · 90% confidence band"><Chart type="area" height={340} data={data} series={[{ key: 'Upper', label: 'Upper bound', color: 'var(--cyan)' }, { key: 'Forecast', label: 'Predicted', color: 'var(--purple)' }, { key: 'Lower', label: 'Lower bound', color: 'var(--cyan)' }, { key: 'Actual', label: 'Historical' }]} /></Panel>
      <Grid><Card className="p-5"><p className="text-sm text-text-2">Predicted 10-day demand</p><p className="text-3xl font-bold text-heading">{data.filter((x) => x.Forecast).reduce((a, x) => a + x.Forecast, 0)} units</p></Card><Card className="p-5"><p className="text-sm text-text-2">Model confidence</p><p className="text-3xl font-bold text-heading">88%</p></Card></Grid>
    </Page>
  )
}
const Reorder = () => {
  const d = useDB()
  const recs = d.inventory.filter((r) => inventoryStatus(r) !== 'In Stock')
  const [applied, setApplied] = useState<string[]>([])
  return (
    <Page title="Reorder Recommendations" desc="AI-generated purchase suggestions based on forecast, lead time and safety stock." actions={<Button variant="primary" icon={Sparkles} onClick={() => { recs.filter((r) => !applied.includes(r.id)).forEach((r) => apply(r.id)); toast('All recommendations applied') }}>Apply all</Button>}>
      <div className="grid gap-4 lg:grid-cols-2">{recs.map((r) => { const p = d.products.find((x) => x.sku === r.sku)!; const qty = Math.max(100, r.reorder * 3 - r.available); return (
        <Card key={r.id} className="p-5" hover>
          <div className="flex items-center justify-between"><p className="font-semibold text-heading">{p.name}</p><Badge tone="primary">{88 - (r.id.length % 7)}% confidence</Badge></div>
          <p className="mt-1 text-[13px] text-text-2">{r.sku} · {r.warehouse} · {r.available} on hand</p>
          <p className="mt-3 text-sm text-text">Order <b className="text-heading">{qty} units</b> from {d.vendors.find((v) => v.id === p.vendorId)?.name}. Demand outpaces supply by {Math.max(1, r.reorder - r.available)} units within lead time.</p>
          <Button className="mt-4" variant={applied.includes(r.id) ? 'secondary' : 'primary'} size="sm" disabled={applied.includes(r.id)} onClick={() => apply(r.id)}>{applied.includes(r.id) ? 'Applied ✓' : 'Apply — create request'}</Button>
        </Card>) })}</div>
    </Page>
  )
  function apply(id: string) {
    const r = d.inventory.find((x) => x.id === id)!; const p = d.products.find((x) => x.sku === r.sku)!
    db.add('requests', { id: `PR-${7100 + d.requests.length + applied.length}`, sku: r.sku, qty: Math.max(100, r.reorder * 3 - r.available), buyer: 'NEXORA AI', vendorId: p.vendorId, value: Math.round(p.price * 0.45 * 200), status: 'Pending', date: '2026-10-08' })
    setApplied((a) => [...a, id]); toast(`Request created for ${r.sku}`)
  }
}
const StockRisk = () => {
  const d = useDB()
  const L = ['Low', 'Medium', 'High', 'Critical'] as const
  return (
    <Page title="Stock Risk" desc="Every stock position ranked by predicted stockout risk.">
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">{L.map((l) => { const rows = d.inventory.filter((r) => risk(r.available, r.reorder) === l); return (
        <Card key={l} className="p-4"><div className="mb-3 flex items-center justify-between"><Badge tone={l === 'Low' ? 'success' : l === 'Medium' ? 'warning' : 'danger'}>{l}</Badge><span className="text-2xl font-bold text-heading">{rows.length}</span></div>
          <ul className="space-y-2 text-[13px]">{rows.slice(0, 5).map((r) => <li key={r.id} className="flex justify-between rounded-lg bg-surface-2 px-3 py-2"><span className="font-medium text-heading">{r.sku}</span><span className="text-text-2">{r.warehouse} · {r.available}</span></li>)}{rows.length === 0 && <li className="text-text-2">None</li>}</ul></Card>) })}</div>
    </Page>
  )
}
const Accuracy = () => {
  const cats = ['Footwear', 'Apparel', 'Electronics', 'Accessories', 'Home']
  const data = ['Jun', 'Jul', 'Aug', 'Sep', 'Oct'].map((n, i) => ({ name: n, Predicted: 2900 + i * 130, Actual: 2840 + i * 150 + (i % 2 ? 40 : -30) }))
  return (
    <Page title="Forecast Accuracy" desc="How well predictions have matched reality.">
      <KpiRow cols={3} items={[{ label: 'Overall accuracy', value: 91.4, format: (n) => `${n.toFixed(1)}%`, trend: 1.2, prev: 'last month' }, { label: 'MAPE', value: 8.6, format: (n) => `${n.toFixed(1)}%`, trend: -1.2, invert: true, prev: 'last month' }, { label: 'Bias', value: 1.4, format: (n) => `+${n.toFixed(1)}%`, hint: 'slight over-forecast' }]} />
      <Grid><Panel title="Predicted vs actual" sub="Units per month"><Chart type="bar" data={data} series={[{ key: 'Predicted', label: 'Predicted', color: 'var(--purple)' }, { key: 'Actual', label: 'Actual' }]} /></Panel><Panel title="Accuracy by category"><BarList items={cats.map((c, i) => ({ label: c, value: 96 - i * 2.7, max: 100, display: `${(96 - i * 2.7).toFixed(1)}%`, tone: i > 3 ? 'warning' as const : 'success' as const }))} /></Panel></Grid>
    </Page>
  )
}
export const screens: Record<string, () => ReactNode> = { overview: Overview, 'demand-forecast': Demand, 'reorder-recommendations': Reorder, 'stock-risk': StockRisk, 'forecast-accuracy': Accuracy }
void DataTable
