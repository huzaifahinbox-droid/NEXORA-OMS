'use client'
import { useState, type ReactNode } from 'react'
import { AlertOctagon, ArrowLeftRight, Plus } from 'lucide-react'
import { Badge, Button, Card, DataTable, EmptyState, Field, Input, Select, StatusBadge, Tabs, toast } from '@/components/ui/core'
import { BarList, Grid, KpiRow, Page, Panel, RecordModal } from '@/components/blocks'
import { Chart } from '@/components/charts/charts'
import { InventoryTable } from '@/components/tables'
import { db, compact, inventoryStatus, useDB } from '@/lib/db'
import { spark } from '@/lib/metrics'
import { WAREHOUSE_IDS } from '@/data/seed'

function useInv() {
  const d = useDB()
  const price = (sku: string) => d.products.find((p) => p.sku === sku)?.price ?? 0
  const name = (sku: string) => d.products.find((p) => p.sku === sku)?.name ?? sku
  const value = d.inventory.reduce((a, r) => a + (r.available + r.reserved) * price(r.sku) * 0.5, 0)
  return { d, price, name, value }
}

const Overview = () => {
  const { d, value, name } = useInv()
  const st = (s: string) => d.inventory.filter((r) => inventoryStatus(r) === s).length
  return (
    <Page title="Inventory Overview" desc="Stock health across every warehouse and SKU.">
      <KpiRow cols={6} items={[{ label: 'Total SKUs', value: d.products.length, hint: 'active' }, { label: 'Available units', value: d.inventory.reduce((a, r) => a + r.available, 0), trend: 2.4, prev: 'last week', spark: spark(1) }, { label: 'Reserved units', value: d.inventory.reduce((a, r) => a + r.reserved, 0), trend: 5.1, prev: 'last week', spark: spark(2) }, { label: 'Low stock', value: st('Low Stock'), status: 'Attention', hint: 'positions' }, { label: 'Out of stock', value: st('Out of Stock'), status: 'Critical', hint: 'positions' }, { label: 'Inventory value', value: value, format: compact, trend: 3.3, prev: 'last month' }]} />
      <Grid>
        <Panel title="Stock by warehouse" sub="Available vs reserved units"><Chart type="bar" stacked data={WAREHOUSE_IDS.map((w) => ({ name: w, Available: d.inventory.filter((r) => r.warehouse === w).reduce((a, r) => a + r.available, 0), Reserved: d.inventory.filter((r) => r.warehouse === w).reduce((a, r) => a + r.reserved, 0) }))} series={[{ key: 'Available', label: 'Available' }, { key: 'Reserved', label: 'Reserved', color: 'var(--purple)' }]} height={260} /></Panel>
        <Panel title="Closest to stockout" sub="Lowest days of cover"><BarList items={[...d.inventory].sort((a, b) => a.available - b.available).slice(0, 6).map((r) => ({ label: `${name(r.sku)} · ${r.warehouse.slice(3, 6)}`, sub: '', value: r.available, max: Math.max(r.reorder, 1), display: `${r.available} / ${r.reorder}`, tone: r.available === 0 ? 'danger' : r.available <= r.reorder ? 'warning' : 'success' }))} /></Panel>
      </Grid>
    </Page>
  )
}

const StockOverview = () => {
  const { d, name } = useInv()
  const [wh, setWh] = useState<string>('All')
  const rows = d.inventory.filter((r) => wh === 'All' || r.warehouse === wh)
  return (
    <Page title="Stock Overview" desc="Warehouse-level inventory positions." actions={<Tabs value={wh} onChange={setWh} options={['All', ...WAREHOUSE_IDS]} />}>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{d.warehouses.filter((w) => wh === 'All' || w.id === wh).map((w) => { const r = d.inventory.filter((x) => x.warehouse === w.id); return <Card key={w.id} className="p-5" hover><p className="text-xs font-semibold text-text-2">{w.id}</p><p className="font-semibold text-heading">{w.name}</p><p className="mt-3 text-2xl font-bold tabular-nums text-heading">{r.reduce((a, x) => a + x.available, 0).toLocaleString('en-IN')}</p><p className="text-xs text-text-2">available · {r.length} SKUs · {r.filter((x) => inventoryStatus(x) !== 'In Stock').length} at risk</p></Card> })}</div>
      <Panel title="Positions" pad={false}><div className="-mt-4"><DataTable rows={rows} searchOf={(r) => `${r.sku} ${name(r.sku)}`} cols={[{ key: 'sku', label: 'SKU' }, { key: 'n', label: 'Product', render: (r) => name(r.sku) }, { key: 'warehouse', label: 'Warehouse' }, { key: 'available', label: 'Available', align: 'right' }, { key: 'reserved', label: 'Reserved', align: 'right' }, { key: 'incoming', label: 'Incoming', align: 'right' }, { key: 's', label: 'Status', render: (r) => <StatusBadge s={inventoryStatus(r)} /> }]} /></div></Panel>
    </Page>
  )
}

const Catalog = () => {
  const { d } = useInv()
  const [add, setAdd] = useState(false)
  return (
    <Page title="SKU Catalog" desc="Every SKU with its stock position per warehouse." actions={<Button variant="primary" icon={Plus} onClick={() => setAdd(true)}>Add SKU</Button>}>
      <InventoryTable adjust />
      <RecordModal open={add} onClose={() => setAdd(false)} title="Add SKU" fields={[{ key: 'name', label: 'Product name' }, { key: 'category', label: 'Category', type: 'select', options: ['Apparel', 'Footwear', 'Electronics', 'Accessories', 'Home'] }, { key: 'price', label: 'Price (₹)', type: 'number' }, { key: 'warehouse', label: 'Warehouse', type: 'select', options: WAREHOUSE_IDS }, { key: 'qty', label: 'Opening stock', type: 'number' }]}
        onSubmit={(v) => { const sku = `SKU-${6000 + d.products.length}`; db.add('products', { id: sku, sku, name: v.name, category: v.category, price: parseInt(v.price, 10) || 0, vendorId: 'VEN-102' }, false); db.add('inventory', { id: `INV-${sku.slice(4)}-${v.warehouse.slice(3, 6)}`, sku, warehouse: v.warehouse, available: parseInt(v.qty, 10) || 0, reserved: 0, incoming: 0, reorder: 50 }); toast(`${sku} added to catalog`) }} />
    </Page>
  )
}

const Transactions = () => {
  const { d, name } = useInv()
  const [t, setT] = useState('All')
  return (
    <Page title="Stock Transactions" desc="Immutable ledger of every stock movement." actions={<Tabs value={t} onChange={setT} options={['All', 'Inbound', 'Outbound', 'Transfer', 'Adjustment', 'Return']} />}>
      <DataTable rows={d.stockTxns.filter((x) => t === 'All' || x.type === t)} searchOf={(x) => `${x.id} ${x.sku} ${x.ref} ${x.warehouse}`} cols={[{ key: 'id', label: 'Txn' }, { key: 'sku', label: 'SKU', render: (x) => `${x.sku} · ${name(x.sku)}` }, { key: 'type', label: 'Type', render: (x) => <Badge tone={x.qty < 0 ? 'warning' : 'success'}>{x.type}</Badge> }, { key: 'qty', label: 'Qty', align: 'right', render: (x) => <b className={x.qty < 0 ? 'text-danger' : 'text-success'}>{x.qty > 0 ? '+' : ''}{x.qty}</b> }, { key: 'warehouse', label: 'Warehouse' }, { key: 'ref', label: 'Reference' }, { key: 'time', label: 'Time' }]} />
    </Page>
  )
}

const LowStock = () => {
  const { d, name } = useInv()
  const rows = d.inventory.filter((r) => inventoryStatus(r) === 'Low Stock').sort((a, b) => a.available / a.reorder - b.available / b.reorder)
  return (
    <Page title="Low Stock" desc="Prioritized by days of cover remaining.">
      <Card>{rows.length === 0 ? <EmptyState title="No low stock risks" body="All positions are above their reorder point." /> : <ul className="divide-y divide-line">{rows.map((r, i) => { const cover = Math.max(1, Math.round(r.available / Math.max(1, r.reserved / 3))); return (
        <li key={r.id} className="flex flex-wrap items-center gap-4 p-5">
          <span className="grid size-8 place-items-center rounded-full bg-warning-bg text-sm font-bold text-warning">{i + 1}</span>
          <div className="min-w-48 flex-1"><p className="font-semibold text-heading">{name(r.sku)} <span className="font-normal text-text-2">· {r.sku}</span></p><p className="text-[13px] text-text-2">{r.warehouse} · {r.available} available, reorder at {r.reorder}</p></div>
          <div className="w-48"><p className="mb-1 text-xs text-text-2">~{cover} days of cover</p><div className="h-2 rounded-full bg-hover"><div className="h-2 rounded-full bg-warning" style={{ width: `${Math.min(100, (r.available / r.reorder) * 100)}%` }} /></div></div>
          <Button size="sm" variant="primary" onClick={() => { db.add('requests', { id: `PR-${7100 + d.requests.length}`, sku: r.sku, qty: r.reorder * 3, buyer: 'Aditi Rao', vendorId: d.products.find((p) => p.sku === r.sku)!.vendorId, value: Math.round(r.reorder * 3 * (d.products.find((p) => p.sku === r.sku)?.price ?? 0) * 0.45), status: 'Pending', date: '2026-10-08' }); toast(`Reorder request raised for ${r.sku}`) }}>Reorder</Button>
        </li>) })}</ul>}</Card>
    </Page>
  )
}

const OutOfStock = () => {
  const { d, name } = useInv()
  const rows = d.inventory.filter((r) => inventoryStatus(r) === 'Out of Stock')
  return (
    <Page title="Out of Stock" desc="Critical stockouts that are blocking sales right now.">
      {rows.length === 0 ? <Card><EmptyState icon={AlertOctagon} title="No stockouts" body="Every SKU has stock available." /></Card> : <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{rows.map((r) => (
        <Card key={r.id} className="border-danger/40 p-5"><div className="flex items-center justify-between"><Badge tone="danger">Out of stock</Badge><span className="text-xs text-text-2">{r.warehouse}</span></div><p className="mt-3 font-semibold text-heading">{name(r.sku)}</p><p className="text-[13px] text-text-2">{r.sku} · {r.incoming ? `${r.incoming} units inbound` : 'No inbound stock'}</p>
          <div className="mt-4 flex gap-2"><Button size="sm" variant="primary" onClick={() => { const from = d.inventory.find((x) => x.sku === r.sku && x.id !== r.id && x.available > 40); db.add('transfers', { id: `TRF-${400 + d.transfers.length}`, from: from?.warehouse ?? 'WH-BLR-02', to: r.warehouse, sku: r.sku, qty: 60, status: 'Requested' }); toast('Transfer requested') }}>Request transfer</Button><Button size="sm" onClick={() => { db.add('requests', { id: `PR-${7100 + d.requests.length}`, sku: r.sku, qty: 300, buyer: 'Aditi Rao', vendorId: d.products.find((p) => p.sku === r.sku)!.vendorId, value: 300 * 1500, status: 'Pending', date: '2026-10-08' }); toast('Urgent purchase request raised') }}>Raise PO</Button></div></Card>))}</div>}
    </Page>
  )
}

const Transfers = () => {
  const { d, name } = useInv()
  const [add, setAdd] = useState(false)
  const next: Record<string, 'In Transit' | 'Completed'> = { Requested: 'In Transit', 'In Transit': 'Completed' }
  return (
    <Page title="Stock Transfers" desc="Move inventory between warehouses." actions={<Button variant="primary" icon={ArrowLeftRight} onClick={() => setAdd(true)}>New transfer</Button>}>
      <DataTable rows={d.transfers} searchOf={(t) => `${t.id} ${t.sku} ${t.from} ${t.to}`} empty={{ title: 'No transfers yet', body: 'Create a transfer to rebalance stock.', cta: 'New transfer', onCta: () => setAdd(true) }} cols={[{ key: 'id', label: 'Transfer' }, { key: 'from', label: 'Source' }, { key: 'to', label: 'Destination' }, { key: 'sku', label: 'SKU', render: (t) => `${t.sku} · ${name(t.sku)}` }, { key: 'qty', label: 'Qty', align: 'right' }, { key: 'status', label: 'Status', render: (t) => <StatusBadge s={t.status} /> }]}
        actions={(t) => t.status !== 'Completed' ? <Button size="sm" onClick={() => { const n = next[t.status]; db.patch('transfers', t.id, { status: n }); if (n === 'Completed') { const src = d.inventory.find((r) => r.sku === t.sku && r.warehouse === t.from); const dst = d.inventory.find((r) => r.sku === t.sku && r.warehouse === t.to); if (src) db.patch('inventory', src.id, { available: Math.max(0, src.available - t.qty) }); if (dst) db.patch('inventory', dst.id, { available: dst.available + t.qty }) } toast(`${t.id} → ${n}`) }}>{t.status === 'Requested' ? 'Dispatch' : 'Complete'}</Button> : null} />
      <RecordModal open={add} onClose={() => setAdd(false)} title="New stock transfer" fields={[{ key: 'sku', label: 'SKU', type: 'select', options: d.products.map((p) => p.sku) }, { key: 'from', label: 'Source warehouse', type: 'select', options: WAREHOUSE_IDS }, { key: 'to', label: 'Destination warehouse', type: 'select', options: WAREHOUSE_IDS }, { key: 'qty', label: 'Quantity', type: 'number' }]} onSubmit={(v) => { if (v.from === v.to) { toast('Source and destination must differ', 'danger'); return } db.add('transfers', { id: `TRF-${400 + d.transfers.length}`, from: v.from, to: v.to, sku: v.sku, qty: parseInt(v.qty, 10) || 0, status: 'Requested' }); toast('Transfer created') }} />
    </Page>
  )
}

const Adjustments = () => {
  const { d } = useInv()
  const [f, setF] = useState({ sku: '', warehouse: '', qty: '', reason: '' })
  const [err, setErr] = useState<Record<string, string>>({})
  const [busy, setBusy] = useState(false)
  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    const er: Record<string, string> = {}
    if (!f.sku) er.sku = 'Select a SKU'; if (!f.warehouse) er.warehouse = 'Select a warehouse'; if (!f.qty || isNaN(Number(f.qty)) || Number(f.qty) === 0) er.qty = 'Enter a non-zero quantity'; if (!f.reason) er.reason = 'Select a reason'
    setErr(er); if (Object.keys(er).length) return
    setBusy(true); setTimeout(() => { db.add('adjustments', { id: `ADJ-${501 + d.adjustments.length}`, sku: f.sku, warehouse: f.warehouse, qty: Number(f.qty), reason: f.reason, approval: 'Pending', by: 'Aditi Rao', time: 'just now' }); setF({ sku: '', warehouse: '', qty: '', reason: '' }); setBusy(false); toast('Adjustment submitted for approval') }, 400)
  }
  return (
    <Page title="Stock Adjustments" desc="Correct stock with a reason and approval. Every change is written to the audit trail.">
      <div className="grid gap-6 xl:grid-cols-[380px_minmax(0,1fr)]">
        <Card className="p-5"><h3 className="mb-4 font-semibold text-heading">New adjustment</h3>
          <form onSubmit={submit} className="space-y-4" noValidate>
            <Select label="SKU" value={f.sku} error={err.sku} onChange={(e) => setF({ ...f, sku: e.target.value })} options={d.products.map((p) => p.sku)} />
            <Select label="Warehouse" value={f.warehouse} error={err.warehouse} onChange={(e) => setF({ ...f, warehouse: e.target.value })} options={WAREHOUSE_IDS} />
            <Input label="Quantity (+/-)" value={f.qty} error={err.qty} onChange={(e) => setF({ ...f, qty: e.target.value })} />
            <Select label="Reason" value={f.reason} error={err.reason} onChange={(e) => setF({ ...f, reason: e.target.value })} options={['Cycle count correction', 'Damaged in storage', 'Lost item', 'Found stock']} />
            <Button type="submit" variant="primary" loading={busy} className="w-full">Submit for approval</Button>
          </form></Card>
        <DataTable rows={d.adjustments} cols={[{ key: 'id', label: 'Adjustment' }, { key: 'sku', label: 'SKU' }, { key: 'warehouse', label: 'Warehouse' }, { key: 'qty', label: 'Qty', align: 'right', render: (a) => <b className={a.qty < 0 ? 'text-danger' : 'text-success'}>{a.qty > 0 ? '+' : ''}{a.qty}</b> }, { key: 'reason', label: 'Reason' }, { key: 'by', label: 'By' }, { key: 'approval', label: 'Approval', render: (a) => <StatusBadge s={a.approval} /> }]}
          actions={(a) => a.approval === 'Pending' ? <><Button size="sm" onClick={() => { db.patch('adjustments', a.id, { approval: 'Approved' }); const r = d.inventory.find((x) => x.sku === a.sku && x.warehouse === a.warehouse); if (r) db.patch('inventory', r.id, { available: Math.max(0, r.available + a.qty) }); db.log(`Approved ${a.id}`, 'Inventory', 'Pending', 'Approved'); toast('Adjustment approved and applied') }}>Approve</Button><Button size="sm" variant="ghost" onClick={() => { db.patch('adjustments', a.id, { approval: 'Rejected' }); toast('Adjustment rejected', 'info') }}>Reject</Button></> : null} />
      </div>
    </Page>
  )
}
export const screens: Record<string, () => ReactNode> = { overview: Overview, 'stock-overview': StockOverview, 'sku-catalog': Catalog, 'stock-transactions': Transactions, 'low-stock': LowStock, 'out-of-stock': OutOfStock, 'stock-transfers': Transfers, 'stock-adjustments': Adjustments }
