'use client'
import { useState, type ReactNode } from 'react'
import { Badge, Button, ConfirmDialog, DataTable, Dropdown, Modal, Select, StatusBadge, toast } from '@/components/ui/core'
import { BarList, Grid, KpiRow, Page, Panel, RecordModal, Stages } from '@/components/blocks'
import { Chart } from '@/components/charts/charts'
import { db, useDB } from '@/lib/db'
import { daysLate, isOpen, useShip } from './shipments'
import { CARRIERS } from '@/data/seed'
import type { Shipment } from '@/types'

const BASE = '/delivery-not-happening'
const MSGS = ['Delivery rescheduled. Please keep your phone reachable', 'We need your correct address or landmark', 'Your parcel is delayed. We are sorry for the wait']
const EXC = /carrier|hub|weather/i

const views: Record<string, { title: string; desc: string; test: (s: Shipment) => boolean; by: (s: Shipment) => string; byTitle: string }> = {
  delayed: { title: 'Delayed Deliveries', desc: 'Parcels that missed their ETA and are still moving.', test: (s) => s.status === 'Delayed', by: (s) => s.issue ?? 'Unknown', byTitle: 'Delay causes' },
  failed: { title: 'Failed Deliveries', desc: 'Attempts that failed and need a reattempt or customer contact.', test: (s) => s.status === 'Failed', by: (s) => s.issue ?? 'Unknown', byTitle: 'Failure reasons' },
  nomove: { title: 'No Movement', desc: 'Open shipments with no carrier scan for 48 hours or more.', test: (s) => isOpen(s) && /no scan/i.test(s.lastScan), by: (s) => s.carrier, byTitle: 'Stalled by carrier' },
  address: { title: 'Address Issues', desc: 'Shipments blocked by an incomplete or incorrect address.', test: (s) => isOpen(s) && /address/i.test(s.issue ?? ''), by: (s) => s.destination, byTitle: 'Affected cities' },
  exceptions: { title: 'Carrier Exceptions', desc: 'Delays caused by carrier network problems, hub congestion or weather.', test: (s) => isOpen(s) && EXC.test(s.issue ?? ''), by: (s) => s.issue ?? 'Unknown', byTitle: 'Exception types' },
  sla: { title: 'SLA Breaches', desc: 'Open shipments that have already breached their delivery promise.', test: (s) => isOpen(s) && s.sla === 'Breached', by: (s) => s.carrier, byTitle: 'Breaches by carrier' },
}
const slugs: Record<string, string> = { 'delayed-deliveries': 'delayed', 'failed-deliveries': 'failed', 'no-movement': 'nomove', 'address-issues': 'address', 'carrier-exceptions': 'exceptions', 'sla-breaches': 'sla' }

function FixActions({ s }: { s: Shipment }) {
  const d = useDB()
  const [m, setM] = useState<'carrier' | 'address' | 'contact' | 'reattempt' | 'escalate' | null>(null)
  const [carrier, setCarrier] = useState('')
  const orderCust = () => { const o = d.orders.find((x) => x.id === s.orderId); return d.customers.find((c) => c.id === o?.customerId)?.name ?? 'customer' }
  const run = (kind: string, patch: Partial<Shipment> | null, note: string, priority: 'Medium' | 'High' = 'High') => {
    db.add('actions', { id: `ACT-${Date.now() % 1000000}`, kind, shipmentId: s.id, owner: 'Aditi Rao', priority, sla: '8h', status: 'In Progress' })
    if (patch) db.patch('shipments', s.id, patch)
    db.log(`${kind} for ${s.id}`, 'Delivery', s.status, patch?.status ?? s.status)
    db.notify('Logistics', `${kind}: ${s.id}`, note, `${BASE}/overview`)
    toast(`${kind} done for ${s.id}`)
  }
  return (
    <>
      <Dropdown label="Actions" items={[{ label: 'Reattempt', onClick: () => setM('reattempt') }, { label: 'Change Carrier', onClick: () => { setCarrier(CARRIERS.find((c) => c !== s.carrier) ?? ''); setM('carrier') } }, { label: 'Update Address', onClick: () => setM('address') }, { label: 'Escalate', onClick: () => setM('escalate') }, { label: 'Contact Customer', onClick: () => setM('contact') }]}
        trigger={<span className="inline-flex h-8 items-center rounded-lg border border-line-strong px-3 text-[13px] font-medium text-heading hover:bg-hover" aria-label={`Actions for ${s.id}`}>Actions</span>} />
      <ConfirmDialog open={m === 'reattempt'} title={`Reattempt ${s.id}?`} body={`A new delivery attempt will be scheduled with ${s.carrier} and the issue cleared.`} confirmLabel="Reattempt" onClose={() => setM(null)} onConfirm={() => run('Reattempt delivery', { status: 'Scheduled', issue: undefined, sla: 'At risk', lastScan: 'Reattempt scheduled' }, `Reattempt scheduled with ${s.carrier} for ${s.destination}.`)} />
      <ConfirmDialog open={m === 'escalate'} danger title={`Escalate ${s.id} to ${s.carrier}?`} body="The carrier's account manager is notified and a critical follow-up task is created." confirmLabel="Escalate" onClose={() => setM(null)} onConfirm={() => run('Escalate to carrier', { sla: s.sla === 'On track' ? 'At risk' : s.sla }, `${s.carrier} account manager notified about ${s.id}.`)} />
      <Modal open={m === 'carrier'} onClose={() => setM(null)} title={`Change carrier: ${s.id}`} footer={<><Button onClick={() => setM(null)}>Cancel</Button><Button variant="primary" onClick={() => { run('Change carrier', { carrier, status: 'In Transit', issue: undefined, sla: 'At risk', lastScan: `Rebooked with ${carrier}` }, `${s.id} moved from ${s.carrier} to ${carrier}.`); setM(null) }}>Reassign</Button></>}>
        <Select label="New carrier" value={carrier} onChange={(e) => setCarrier(e.target.value)} options={CARRIERS.filter((c) => c !== s.carrier)} />
      </Modal>
      <RecordModal open={m === 'address'} onClose={() => setM(null)} title={`Update address: ${s.id}`} fields={[{ key: 'addr', label: 'Corrected address', type: 'textarea' }, { key: 'city', label: 'City' }]} initial={{ city: s.destination }} submitLabel="Update"
        onSubmit={(v) => run('Update address', { destination: v.city, issue: undefined, status: s.status === 'Failed' ? 'Scheduled' : s.status, lastScan: 'Address corrected' }, `Address corrected for ${s.id}, destination ${v.city}.`)} />
      <RecordModal open={m === 'contact'} onClose={() => setM(null)} title={`Contact ${orderCust()}`} fields={[{ key: 'msg', label: 'Message', type: 'select', options: MSGS }]} initial={{ msg: MSGS[0] }} submitLabel="Send"
        onSubmit={(v) => run('Contact customer', null, `${orderCust()} messaged: ${v.msg}.`, 'Medium')} />
    </>
  )
}

function Issue({ k }: { k: string }) {
  const { d, cust } = useShip()
  const v = views[k]
  const rows = d.shipments.filter(v.test)
  const open = d.shipments.filter(isOpen).length
  const groups = Object.entries(rows.reduce<Record<string, number>>((a, s) => { const g = v.by(s); a[g] = (a[g] ?? 0) + 1; return a }, {})).sort((a, b) => b[1] - a[1])
  return (
    <Page title={v.title} desc={v.desc}>
      <KpiRow cols={4} items={[{ label: 'Affected shipments', value: rows.length, status: rows.length ? 'Attention' : 'Healthy' }, { label: 'Share of open', value: (rows.length / Math.max(1, open)) * 100, format: (n) => `${Math.round(n)}%` }, { label: 'SLA breached', value: rows.filter((s) => s.sla === 'Breached').length, status: 'Critical' }, { label: 'Avg days late', value: rows.length ? rows.reduce((a, s) => a + daysLate(s), 0) / rows.length : 0, format: (n) => n.toFixed(1) }]} />
      <Panel title={v.byTitle}>{groups.length ? <BarList items={groups.slice(0, 6).map(([l, n]) => ({ label: l, value: n, display: `${n}`, tone: 'warning' as const }))} /> : <p className="text-sm text-text-2">No affected shipments. Everything is on track.</p>}</Panel>
      <DataTable rows={rows} searchOf={(s) => `${s.id} ${s.orderId} ${s.carrier} ${s.destination} ${s.awb} ${s.issue ?? ''}`} empty={{ title: 'All clear', body: 'No shipments match this problem right now.' }}
        cols={[{ key: 'id', label: 'Shipment', render: (s) => <b className="text-heading">{s.id}</b> }, { key: 'c', label: 'Customer', render: (s) => cust(s.orderId) }, { key: 'carrier', label: 'Carrier' }, { key: 'destination', label: 'Destination' }, { key: 'issue', label: 'Issue', render: (s) => s.issue ?? s.lastScan }, { key: 'late', label: 'Days late', align: 'right', sort: daysLate, render: (s) => daysLate(s) || '—' }, { key: 'sla', label: 'SLA', render: (s) => <Badge tone={s.sla === 'Breached' ? 'danger' : 'warning'}>{s.sla}</Badge> }, { key: 'status', label: 'Status', render: (s) => <StatusBadge s={s.status} /> }]}
        actions={(s) => <FixActions s={s} />} />
    </Page>
  )
}

const Overview = () => {
  const { d, byCarrier } = useShip()
  const n = (k: string) => d.shipments.filter(views[k].test).length
  const problem = new Set(d.shipments.filter((s) => Object.values(views).some((v) => v.test(s))).map((s) => s.id)).size
  return (
    <Page title="Delivery Not Happening" desc="Every shipment that is stuck, late or failing, and the fastest way to unblock it.">
      <KpiRow cols={4} items={[{ label: 'Problem shipments', value: problem, status: problem ? 'Attention' : 'Healthy', hint: 'across all categories' }, { label: 'Delayed', value: n('delayed') }, { label: 'Failed', value: n('failed'), status: 'Critical' }, { label: 'SLA breached', value: n('sla'), status: 'Critical' }]} />
      <Panel title="Problem categories" sub="Open a queue to take action"><Stages stages={Object.entries(slugs).map(([slug, k]) => ({ label: views[k].title, count: n(k), href: `${BASE}/${slug}` }))} /></Panel>
      <Grid>
        <Panel title="Problems by carrier"><Chart type="bar" stacked height={250} data={byCarrier.map((c) => ({ name: c.name, Delayed: c.delayed, Failed: c.failed, 'No movement': c.r.filter(views.nomove.test).length }))} series={[{ key: 'Delayed', label: 'Delayed', color: 'var(--warning)' }, { key: 'Failed', label: 'Failed', color: 'var(--danger)' }, { key: 'No movement', label: 'No movement' }]} /></Panel>
        <Panel title="Oldest open problems"><BarList items={d.shipments.filter((s) => Object.values(views).some((v) => v.test(s))).sort((a, b) => daysLate(b) - daysLate(a)).slice(0, 6).map((s) => ({ label: s.id, sub: s.carrier, value: daysLate(s), max: 5, display: `${daysLate(s)}d late`, tone: s.sla === 'Breached' ? 'danger' as const : 'warning' as const }))} /></Panel>
      </Grid>
    </Page>
  )
}

export const screens: Record<string, () => ReactNode> = { overview: Overview, ...Object.fromEntries(Object.entries(slugs).map(([slug, k]) => [slug, () => <Issue k={k} />])) }
