'use client'
import { useState, type ReactNode } from 'react'
import { Bot, Plus, Sparkles } from 'lucide-react'
import { Badge, Button, Card, DataTable, Modal, Select, StatusBadge, Textarea, toast } from '@/components/ui/core'
import { BarList, Feed, Grid, KpiRow, Page, Panel, RecordModal } from '@/components/blocks'
import { Chart, Donut } from '@/components/charts/charts'
import { createStore } from '@/lib/store'
import { db, useDB } from '@/lib/db'
import { spark } from '@/lib/metrics'
import type { Ticket } from '@/types'

type Msg = { from: 'customer' | 'agent'; text: string; time: string }
const threadStore = createStore<{ t: Record<string, Msg[]> }>('nexora-threads-v1', () => ({ t: {} }), false)
const addMsg = (id: string, m: Msg) => threadStore.set((s) => ({ t: { ...s.t, [id]: [...(s.t[id] ?? []), m] } }))

const STATUSES: Ticket['status'][] = ['Open', 'Pending', 'Escalated', 'Resolved']
const PRIORITIES = ['Low', 'Medium', 'High', 'Urgent']
const ISSUES = ['Where is my order?', 'Received wrong size', 'Refund not received', 'Delivery attempted but I was home', 'Damaged packaging', 'Change delivery address']
const AI: Record<string, { reply: string; auto: boolean }> = {
  'Where is my order?': { reply: 'Hi {name}, your order {order} is on its way. You can follow live tracking from the link in your confirmation email, and we will alert you if anything changes.', auto: true },
  'Received wrong size': { reply: 'Sorry about the wrong size, {name}. We have raised a free exchange for {order}. A pickup will be scheduled within 24 hours.', auto: false },
  'Refund not received': { reply: 'Hi {name}, your refund for {order} has been initiated and typically reaches your bank in 3-5 working days. We will notify you once settled.', auto: true },
  'Delivery attempted but I was home': { reply: 'Apologies {name}. We have asked the carrier to reattempt delivery of {order} tomorrow and added a call-before-arrival note.', auto: true },
  'Damaged packaging': { reply: 'We are sorry {name}. Please share a photo of the damage and we will replace or refund {order} right away.', auto: false },
  'Change delivery address': { reply: 'Hi {name}, we have sent an address update request for {order} to the carrier. We will confirm as soon as it is accepted.', auto: false },
}
const fill = (s: string, t: Ticket) => s.replace('{name}', t.customer.split(' ')[0]).replace('{order}', t.orderId)

function setStatus(t: Ticket, to: Ticket['status'], note?: string) {
  if (t.status === to) return
  db.patch('tickets', t.id, { status: to, ...(to === 'Resolved' ? { sla: 'Resolved' } : {}) })
  db.log(note ?? `Changed ticket ${t.id} status`, 'Support', t.status, to)
  toast(`${t.id} is now ${to}`, to === 'Escalated' ? 'info' : 'success')
}

function TicketModal({ id, onClose }: { id: string | null; onClose: () => void }) {
  const d = useDB()
  const th = threadStore.use().t
  const [reply, setReply] = useState('')
  const t = d.tickets.find((x) => x.id === id)
  if (!t) return null
  const msgs: Msg[] = [{ from: 'customer', text: t.issue, time: 'Opened' }, ...(th[t.id] ?? [])]
  const send = () => { if (!reply.trim()) { toast('Write a reply first', 'info'); return } addMsg(t.id, { from: 'agent', text: reply.trim(), time: 'just now' }); if (t.status === 'Open') setStatus(t, 'Pending', `Replied to ${t.id}`); db.log(`Replied to ${t.id}`, 'Support', '—', 'Reply sent'); setReply(''); toast(`Reply sent to ${t.customer}`) }
  return (
    <Modal open onClose={() => { setReply(''); onClose() }} wide title={`${t.id} · ${t.issue}`}
      footer={<><Button onClick={onClose}>Close</Button>{t.status !== 'Escalated' && t.status !== 'Resolved' && <Button onClick={() => setStatus(t, 'Escalated', `Escalated ticket ${t.id}`)}>Escalate</Button>}{t.status !== 'Resolved' && <Button variant="primary" onClick={() => setStatus(t, 'Resolved', `Resolved ticket ${t.id}`)}>Resolve</Button>}</>}>
      <div className="grid gap-6 md:grid-cols-[220px_minmax(0,1fr)]">
        <dl className="space-y-2 text-sm">
          {[['Customer', t.customer], ['Order', t.orderId], ['Agent', t.agent], ['SLA', t.sla]].map(([k, v]) => <div key={k} className="flex justify-between gap-3"><dt className="text-text-2">{k}</dt><dd className="font-medium text-heading">{v}</dd></div>)}
          <div className="flex justify-between"><dt className="text-text-2">Priority</dt><dd><StatusBadge s={t.priority} /></dd></div>
          <div className="pt-2"><Select label="Status" value={t.status} onChange={(e) => setStatus(t, e.target.value as Ticket['status'])} options={STATUSES} /></div>
        </dl>
        <div className="min-w-0 space-y-3">
          <ul className="max-h-60 space-y-2 overflow-y-auto scroll-thin">{msgs.map((m, i) => <li key={i} className={`max-w-[85%] rounded-xl px-3 py-2 text-[13px] ${m.from === 'agent' ? 'ml-auto bg-primary-light text-heading' : 'bg-surface-2 text-text'}`}><p>{m.text}</p><p className="mt-1 text-[11px] text-muted">{m.from === 'agent' ? 'You' : t.customer} · {m.time}</p></li>)}</ul>
          {t.status !== 'Resolved' ? <><Textarea label="Reply" value={reply} onChange={(e) => setReply(e.target.value)} placeholder="Type a reply to the customer…" /><div className="flex flex-wrap gap-2"><Button variant="primary" onClick={send}>Send reply</Button><Button icon={Sparkles} onClick={() => setReply(fill(AI[t.issue]?.reply ?? 'Thanks for reaching out. We are looking into this.', t))}>Use AI suggestion</Button></div></> : <p className="text-sm text-text-2">This ticket is resolved. Change the status to reopen it.</p>}
        </div>
      </div>
    </Modal>
  )
}

function NewTicket({ open, onClose }: { open: boolean; onClose: () => void }) {
  const d = useDB()
  return <RecordModal open={open} onClose={onClose} title="Create ticket" submitLabel="Create ticket"
    fields={[{ key: 'customer', label: 'Customer', type: 'select', options: d.customers.map((c) => c.name) }, { key: 'orderId', label: 'Order', type: 'select', options: d.orders.slice(0, 30).map((o) => o.id) }, { key: 'issue', label: 'Issue', type: 'select', options: ISSUES }, { key: 'priority', label: 'Priority', type: 'select', options: PRIORITIES }]}
    onSubmit={(v) => { const id = `TCK-${4401 + d.tickets.length}`; db.add('tickets', { id, customer: v.customer, orderId: v.orderId, issue: v.issue, priority: v.priority as Ticket['priority'], agent: 'Maya Joseph', sla: '24h left', status: 'Open', breached: false }); db.log(`Created ticket ${id}`, 'Support', '—', 'Open'); toast(`${id} created`) }} />
}

function TicketsView({ statuses, breached, title, body }: { statuses?: Ticket['status'][]; breached?: boolean; title: string; body: string }) {
  const d = useDB()
  const [open, setOpen] = useState<string | null>(null)
  const [add, setAdd] = useState(false)
  const rows = d.tickets.filter((t) => (!statuses || statuses.includes(t.status)) && (!breached || t.breached))
  return (
    <>
      <DataTable rows={rows} searchOf={(t) => `${t.id} ${t.customer} ${t.orderId} ${t.issue} ${t.agent}`} onRow={(t) => setOpen(t.id)} empty={{ title, body }}
        toolbar={<Button variant="primary" size="sm" icon={Plus} onClick={() => setAdd(true)}>New ticket</Button>}
        cols={[{ key: 'id', label: 'Ticket', render: (t) => <b className="text-heading">{t.id}</b> }, { key: 'customer', label: 'Customer' }, { key: 'issue', label: 'Issue' }, { key: 'orderId', label: 'Order' }, { key: 'priority', label: 'Priority', render: (t) => <StatusBadge s={t.priority} /> }, { key: 'agent', label: 'Agent' }, { key: 'sla', label: 'SLA', render: (t) => <Badge tone={t.breached ? 'danger' : 'neutral'}>{t.sla}</Badge> }, { key: 'status', label: 'Status', render: (t) => <StatusBadge s={t.status} /> }]}
        actions={(t) => t.status === 'Resolved' ? <Button size="sm" onClick={() => setStatus(t, 'Open', `Reopened ticket ${t.id}`)}>Reopen</Button> : <><Button size="sm" onClick={() => setOpen(t.id)}>Reply</Button><Button size="sm" variant="primary" onClick={() => setStatus(t, 'Resolved', `Resolved ticket ${t.id}`)}>Resolve</Button></>} />
      <TicketModal id={open} onClose={() => setOpen(null)} />
      <NewTicket open={add} onClose={() => setAdd(false)} />
    </>
  )
}

const Overview = () => {
  const d = useDB()
  const n = (s: string) => d.tickets.filter((t) => t.status === s).length
  const live = d.tickets.filter((t) => t.status !== 'Resolved')
  return (
    <Page title="Support Overview" desc="Ticket load, SLA health and where agents should focus.">
      <KpiRow cols={5} items={[{ label: 'Open', value: n('Open'), trend: 6, invert: true, prev: 'last week', spark: spark(1, false) }, { label: 'Pending', value: n('Pending') }, { label: 'Escalated', value: n('Escalated'), status: n('Escalated') ? 'Attention' : 'Healthy' }, { label: 'Resolved', value: n('Resolved'), trend: 9, prev: 'last week', spark: spark(2) }, { label: 'SLA breaches', value: d.tickets.filter((t) => t.breached).length, status: 'Critical' }]} />
      <Grid>
        <Panel title="Tickets by status"><Donut data={STATUSES.map((s) => ({ name: s, value: n(s) }))} center={`${d.tickets.length}`} /></Panel>
        <Panel title="Top issues"><BarList items={ISSUES.map((i) => ({ label: i, value: d.tickets.filter((t) => t.issue === i).length })).sort((a, b) => b.value - a.value).slice(0, 5)} /></Panel>
      </Grid>
      <Grid>
        <Panel title="Urgent queue"><Feed items={live.filter((t) => t.priority === 'Urgent' || t.priority === 'High').slice(0, 6).map((t) => ({ title: `${t.id} · ${t.issue}`, sub: `${t.customer} · ${t.agent}`, time: t.sla, badge: t.priority }))} /></Panel>
        <Panel title="Workload by agent"><Chart type="bar" legend={false} height={220} data={[...new Set(d.tickets.map((t) => t.agent))].map((a) => ({ name: a.split(' ')[0], value: live.filter((t) => t.agent === a).length }))} series={[{ key: 'value', label: 'Active tickets' }]} /></Panel>
      </Grid>
    </Page>
  )
}

const mk = (title: string, desc: string, props: Parameters<typeof TicketsView>[0]) => () => <Page title={title} desc={desc}><TicketsView {...props} /></Page>
const All = mk('Support Tickets', 'Every customer ticket. Click a row to reply, escalate or resolve.', { title: 'No tickets yet', body: 'Create a ticket to get started.' })
const Open = mk('Open Tickets', 'New tickets waiting for a first response.', { statuses: ['Open'], title: 'No open tickets', body: 'Great work, the inbox is clear.' })
const Pending = mk('Pending Tickets', 'Tickets waiting on the customer or another team.', { statuses: ['Pending'], title: 'No pending tickets', body: 'Nothing is waiting on a response.' })
const Escalated = mk('Escalated Tickets', 'Tickets raised to senior support for urgent handling.', { statuses: ['Escalated'], title: 'No escalations', body: 'Escalated tickets will appear here.' })
const Resolved = mk('Resolved Tickets', 'Closed tickets. Reopen any that need more work.', { statuses: ['Resolved'], title: 'Nothing resolved yet', body: 'Resolved tickets will appear here.' })
const Breaches = () => {
  const d = useDB()
  const b = d.tickets.filter((t) => t.breached)
  return (
    <Page title="SLA Breaches" desc="Tickets that exceeded their response or resolution target.">
      <KpiRow cols={3} items={[{ label: 'Breached tickets', value: b.length, status: 'Critical' }, { label: 'Still unresolved', value: b.filter((t) => t.status !== 'Resolved').length, status: 'Attention' }, { label: 'Breach rate', value: (100 * b.length) / Math.max(1, d.tickets.length), format: (n) => `${n.toFixed(1)}%`, invert: true, trend: -1.2, prev: 'last week' }]} />
      <TicketsView breached title="No SLA breaches" body="All tickets are within target." />
    </Page>
  )
}

const AiSupport = () => {
  const d = useDB()
  const [open, setOpen] = useState<string | null>(null)
  const live = d.tickets.filter((t) => t.status !== 'Resolved')
  const auto = live.filter((t) => AI[t.issue]?.auto && t.priority !== 'Urgent')
  const aiHandled = d.tickets.filter((t) => t.agent === 'AI Agent')
  const apply = (t: Ticket, resolve: boolean) => { addMsg(t.id, { from: 'agent', text: fill(AI[t.issue].reply, t), time: 'AI · just now' }); db.patch('tickets', t.id, { status: resolve ? 'Resolved' : 'Pending', agent: 'AI Agent', ...(resolve ? { sla: 'Resolved' } : {}) }); db.log(`AI ${resolve ? 'resolved' : 'replied to'} ${t.id}`, 'Support', t.status, resolve ? 'Resolved' : 'Pending') }
  return (
    <Page title="AI Support" desc="Suggested replies and auto-resolution for routine tickets." actions={<Button variant="primary" icon={Bot} disabled={!auto.length} onClick={() => { auto.forEach((t) => apply(t, true)); toast(`AI resolved ${auto.length} tickets`) }}>Auto-resolve {auto.length} eligible</Button>}>
      <KpiRow cols={4} items={[{ label: 'Handled by AI', value: aiHandled.length, hint: 'tickets' }, { label: 'Auto-resolvable now', value: auto.length, status: 'Healthy', hint: 'routine, non-urgent' }, { label: 'AI resolution rate', value: (100 * aiHandled.filter((t) => t.status === 'Resolved').length) / Math.max(1, aiHandled.length), format: (n) => `${Math.round(n)}%`, trend: 4.2, prev: 'last week' }, { label: 'Agent hours saved', value: aiHandled.length * 0.4 + 12, format: (n) => `${n.toFixed(1)}h`, trend: 11, prev: 'last week' }]} />
      <Panel title="Auto-resolution summary" sub="Share of live tickets by AI eligibility"><Donut data={[{ name: 'Auto-resolvable', value: auto.length }, { name: 'Needs agent', value: live.length - auto.length }]} center={`${live.length} live`} /></Panel>
      <div className="grid gap-4 lg:grid-cols-2">
        {live.length === 0 && <Card className="p-6 text-sm text-text-2">No live tickets to suggest replies for.</Card>}
        {live.map((t) => { const a = AI[t.issue]; return (
          <Card key={t.id} className="p-5" hover>
            <div className="flex items-center justify-between gap-2"><button className="font-semibold text-heading hover:underline" onClick={() => setOpen(t.id)}>{t.id} · {t.issue}</button><StatusBadge s={t.priority} /></div>
            <p className="text-xs text-text-2">{t.customer} · {t.orderId}</p>
            <p className="mt-3 rounded-lg bg-surface-2 p-3 text-[13px] text-text"><Sparkles size={13} className="mr-1 inline text-primary" />{fill(a.reply, t)}</p>
            <div className="mt-3 flex flex-wrap gap-2"><Button size="sm" variant="primary" onClick={() => { apply(t, false); toast(`AI reply sent on ${t.id}`) }}>Send reply</Button>{a.auto && t.priority !== 'Urgent' && <Button size="sm" onClick={() => { apply(t, true); toast(`${t.id} resolved by AI`) }}>Send and resolve</Button>}<Button size="sm" variant="ghost" onClick={() => setOpen(t.id)}>Edit</Button></div>
          </Card>) })}
      </div>
      <TicketModal id={open} onClose={() => setOpen(null)} />
    </Page>
  )
}

export const screens: Record<string, () => ReactNode> = { overview: Overview, 'support-tickets': All, 'open-tickets': Open, 'pending-tickets': Pending, 'escalated-tickets': Escalated, 'resolved-tickets': Resolved, 'sla-breaches': Breaches, 'ai-support': AiSupport }
