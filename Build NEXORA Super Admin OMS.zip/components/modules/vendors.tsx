'use client'
import { useState, type ReactNode } from 'react'
import { Plus } from 'lucide-react'
import { Badge, Button, ConfirmDialog, DataTable, Modal, Select, StatusBadge, Tabs, toast } from '@/components/ui/core'
import { BarList, Feed, Grid, KpiRow, Page, Panel, RecordModal } from '@/components/blocks'
import { Chart, Donut } from '@/components/charts/charts'
import { POTable } from './procurement'
import { db, compact, money, useDB } from '@/lib/db'
import { spark } from '@/lib/metrics'
import type { Product, Vendor } from '@/types'

const CATS = ['Footwear', 'Apparel', 'Electronics', 'Accessories', 'Home']
const COMPLIANCE = ['ISO 9001 verified', 'BIS certified', 'GST verified', 'Audit due']
const RISKS = ['Low', 'Medium', 'High']

function useV() {
  const d = useDB()
  const rows = d.vendors.map((v) => {
    const pos = d.pos.filter((p) => p.vendorId === v.id)
    const late = pos.filter((p) => p.status === 'Delayed').length
    const skus = d.products.filter((p) => p.vendorId === v.id).length
    const onTime = pos.length ? Math.round((100 * (pos.length - late)) / pos.length) : 100
    return { ...v, products: skus, pos: pos.length, late, onTime, open: pos.filter((p) => p.status !== 'Received').reduce((a, p) => a + p.value, 0) }
  })
  return { d, rows, vn: (id: string) => d.vendors.find((v) => v.id === id)?.name ?? id }
}

const Overview = () => {
  const { d, rows } = useV()
  const spend = d.pos.reduce((a, p) => a + p.value, 0)
  return (
    <Page title="Vendors Overview" desc="Supplier base, spend and standing at a glance.">
      <KpiRow cols={5} items={[{ label: 'Active vendors', value: d.vendors.length, trend: 4.0, prev: 'last quarter', spark: spark(1) }, { label: 'Catalog SKUs', value: d.products.length, hint: 'across all vendors' }, { label: 'PO spend', value: spend, format: compact, trend: 6.2, prev: 'last month', spark: spark(2) }, { label: 'Avg reliability', value: rows.reduce((a, v) => a + v.reliability, 0) / Math.max(1, rows.length), format: (n) => `${n.toFixed(1)}%`, trend: 0.8, prev: 'last quarter' }, { label: 'Compliance actions', value: d.vendors.filter((v) => /due/i.test(v.compliance)).length, status: 'Attention', hint: 'audits due' }]} />
      <Grid>
        <Panel title="Spend by vendor" sub="Total PO value"><Chart type="bar" legend={false} height={240} fmt={compact} data={rows.map((v) => ({ name: v.name.split(' ')[0], value: d.pos.filter((p) => p.vendorId === v.id).reduce((a, p) => a + p.value, 0) }))} series={[{ key: 'value', label: 'PO value' }]} /></Panel>
        <Panel title="Vendors by category"><Donut data={CATS.map((c) => ({ name: c, value: d.vendors.filter((v) => v.category === c).length })).filter((x) => x.value)} center={`${d.vendors.length}`} /></Panel>
      </Grid>
      <Panel title="Needs attention"><Feed items={rows.filter((v) => v.risk === 'High' || v.late > 0 || /due/i.test(v.compliance)).map((v) => ({ title: v.name, sub: [v.risk === 'High' && 'High risk', v.late > 0 && `${v.late} delayed PO`, /due/i.test(v.compliance) && 'Audit due'].filter(Boolean).join(' · '), time: `${v.reliability}% reliable`, badge: v.risk }))} /></Panel>
    </Page>
  )
}

const Directory = () => {
  const { d, rows } = useV()
  const [edit, setEdit] = useState<Vendor | 'new' | null>(null)
  const [del, setDel] = useState<Vendor | null>(null)
  const cur = edit && edit !== 'new' ? edit : undefined
  return (
    <Page title="Vendor Directory" desc="Maintain your approved supplier list." actions={<Button variant="primary" icon={Plus} onClick={() => setEdit('new')}>Add vendor</Button>}>
      <DataTable rows={rows} searchOf={(v) => `${v.id} ${v.name} ${v.category}`} empty={{ title: 'No vendors yet', body: 'Add your first supplier.', cta: 'Add vendor', onCta: () => setEdit('new') }}
        cols={[{ key: 'name', label: 'Vendor', render: (v) => <div><b className="text-heading">{v.name}</b><div className="text-xs text-muted">{v.id}</div></div> }, { key: 'category', label: 'Category' }, { key: 'products', label: 'SKUs', align: 'right' }, { key: 'leadTime', label: 'Lead time', align: 'right', render: (v) => `${v.leadTime}d` }, { key: 'reliability', label: 'Reliability', align: 'right', render: (v) => `${v.reliability}%` }, { key: 'risk', label: 'Risk', render: (v) => <StatusBadge s={v.risk} /> }, { key: 'compliance', label: 'Compliance' }]}
        actions={(v) => <><Button size="sm" onClick={() => setEdit(d.vendors.find((x) => x.id === v.id)!)}>Edit</Button><Button size="sm" variant="ghost" onClick={() => setDel(d.vendors.find((x) => x.id === v.id)!)}>Remove</Button></>} />
      <RecordModal open={!!edit} onClose={() => setEdit(null)} title={cur ? `Edit ${cur.name}` : 'Add vendor'} submitLabel={cur ? 'Save changes' : 'Add vendor'}
        initial={cur ? { name: cur.name, category: cur.category, leadTime: String(cur.leadTime), reliability: String(cur.reliability), risk: cur.risk, compliance: cur.compliance } : undefined}
        fields={[{ key: 'name', label: 'Vendor name' }, { key: 'category', label: 'Category', type: 'select', options: CATS }, { key: 'leadTime', label: 'Lead time (days)', type: 'number' }, { key: 'reliability', label: 'Reliability %', type: 'number' }, { key: 'risk', label: 'Risk', type: 'select', options: RISKS }, { key: 'compliance', label: 'Compliance', type: 'select', options: COMPLIANCE }]}
        onSubmit={(v) => {
          const base = { name: v.name, category: v.category, leadTime: parseInt(v.leadTime, 10) || 0, reliability: Math.min(100, parseInt(v.reliability, 10) || 0), risk: v.risk as Vendor['risk'], compliance: v.compliance }
          if (cur) { db.patch('vendors', cur.id, base); db.log(`Edited vendor ${v.name}`, 'Vendors', cur.name, v.name); toast(`${v.name} updated`) }
          else { const id = `VEN-${111 + d.vendors.length}`; db.add('vendors', { id, products: 0, volume: 0, contract: 'Renews 2027-10-08', ...base }, false); db.log(`Added vendor ${v.name}`, 'Vendors', '—', id); toast(`${v.name} added`) }
        }} />
      <ConfirmDialog open={!!del} danger title={`Remove ${del?.name}?`} body={`${d.products.filter((p) => p.vendorId === del?.id).length} products are assigned to this vendor. Reassign them from Products first to avoid orphaned SKUs.`} confirmLabel="Remove vendor" onClose={() => setDel(null)} onConfirm={() => { if (del) { db.remove('vendors', del.id); db.log(`Removed vendor ${del.name}`, 'Vendors', del.id, '—'); toast(`${del.name} removed`, 'info') } }} />
    </Page>
  )
}

const Performance = () => {
  const { rows } = useV()
  return (
    <Page title="Vendor Performance" desc="Delivery reliability and lead time compared across vendors.">
      <Grid>
        <Panel title="Reliability & on-time delivery"><Chart type="bar" height={260} data={rows.map((v) => ({ name: v.name.split(' ')[0], Reliability: v.reliability, 'On-time POs': v.onTime }))} series={[{ key: 'Reliability', label: 'Reliability %' }, { key: 'On-time POs', label: 'On-time POs %', color: 'var(--purple)' }]} /></Panel>
        <Panel title="Lead time ranking"><BarList items={[...rows].sort((a, b) => a.leadTime - b.leadTime).map((v) => ({ label: v.name, value: v.leadTime, max: 30, display: `${v.leadTime} days`, tone: v.leadTime > 20 ? 'danger' : v.leadTime > 14 ? 'warning' : 'success' }))} /></Panel>
      </Grid>
      <DataTable rows={rows} searchOf={(v) => v.name} cols={[{ key: 'name', label: 'Vendor', render: (v) => <b className="text-heading">{v.name}</b> }, { key: 'pos', label: 'POs', align: 'right' }, { key: 'late', label: 'Delayed', align: 'right' }, { key: 'onTime', label: 'On-time', align: 'right', render: (v) => `${v.onTime}%` }, { key: 'reliability', label: 'Reliability', align: 'right', render: (v) => <Badge tone={v.reliability >= 90 ? 'success' : v.reliability >= 82 ? 'warning' : 'danger'}>{v.reliability}%</Badge> }, { key: 'leadTime', label: 'Lead time', align: 'right', render: (v) => `${v.leadTime}d` }, { key: 'risk', label: 'Risk', render: (v) => <StatusBadge s={v.risk} /> }]} />
    </Page>
  )
}

const Products = () => {
  const { d, vn } = useV()
  const [vf, setVf] = useState('All')
  const [re, setRe] = useState<Product | null>(null)
  const [to, setTo] = useState('')
  const list = d.products.filter((p) => vf === 'All' || p.vendorId === vf)
  return (
    <Page title="Vendor Products" desc="Which vendor supplies which SKU. Reassign a product to move future purchasing.">
      <DataTable rows={list} searchOf={(p) => `${p.sku} ${p.name} ${vn(p.vendorId)}`} pageSize={10}
        filters={<select aria-label="Filter by vendor" value={vf} onChange={(e) => setVf(e.target.value)} className="h-10 rounded-lg border border-line-strong bg-surface px-3 text-sm text-heading"><option value="All">All vendors</option>{d.vendors.map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}</select>}
        cols={[{ key: 'sku', label: 'SKU', render: (p) => <b className="text-heading">{p.sku}</b> }, { key: 'name', label: 'Product' }, { key: 'category', label: 'Category' }, { key: 'price', label: 'Price', align: 'right', render: (p) => money(p.price) }, { key: 'vendorId', label: 'Vendor', sort: (p) => vn(p.vendorId), render: (p) => vn(p.vendorId) }]}
        actions={(p) => <Button size="sm" onClick={() => { setRe(p); setTo('') }}>Reassign</Button>} />
      <Modal open={!!re} onClose={() => setRe(null)} title={`Reassign ${re?.name}`} footer={<><Button onClick={() => setRe(null)}>Cancel</Button><Button variant="primary" disabled={!to} onClick={() => { const v = d.vendors.find((x) => x.name === to); if (re && v) { db.patch('products', re.id, { vendorId: v.id }); d.requests.filter((r) => r.sku === re.sku && ['Pending', 'Approved'].includes(r.status)).forEach((r) => db.patch('requests', r.id, { vendorId: v.id })); db.log(`Reassigned ${re.sku} to ${v.name}`, 'Vendors', vn(re.vendorId), v.name); toast(`${re.sku} now supplied by ${v.name}`) } setRe(null) }}>Reassign</Button></>}>
        <p className="mb-3 text-sm text-text-2">Currently supplied by <b className="text-heading">{re ? vn(re.vendorId) : ''}</b>. Open requests move with the product.</p>
        <Select label="New vendor" value={to} onChange={(e) => setTo(e.target.value)} options={d.vendors.filter((v) => v.id !== re?.vendorId).map((v) => v.name)} />
      </Modal>
    </Page>
  )
}

const POs = () => {
  const { d, rows } = useV()
  const [vf, setVf] = useState('All')
  const v = d.vendors.find((x) => x.name === vf)
  const mine = d.pos.filter((p) => !v || p.vendorId === v.id)
  return (
    <Page title="Vendor Purchase Orders" desc="Orders placed with each vendor." actions={<select aria-label="Vendor" value={vf} onChange={(e) => setVf(e.target.value)} className="h-10 rounded-lg border border-line-strong bg-surface px-3 text-sm text-heading"><option>All</option>{rows.map((x) => <option key={x.id}>{x.name}</option>)}</select>}>
      <KpiRow cols={4} items={[{ label: 'Orders', value: mine.length }, { label: 'Open value', value: mine.filter((p) => p.status !== 'Received').reduce((a, p) => a + p.value, 0), format: compact }, { label: 'Delayed', value: mine.filter((p) => p.status === 'Delayed').length, status: 'Attention' }, { label: 'Received', value: mine.filter((p) => p.status === 'Received').length, status: 'Healthy' }]} />
      <POTable vendorId={v?.id} />
    </Page>
  )
}

const Contracts = () => {
  const { rows } = useV()
  const [renew, setRenew] = useState<Vendor | null>(null)
  const days = (c: string) => Math.round((Date.parse(c.replace('Renews ', '')) - Date.parse('2026-10-08')) / 86400000)
  return (
    <Page title="Vendor Contracts" desc="Renewal dates and terms. Contracts renewing within 90 days are flagged.">
      <KpiRow cols={3} items={[{ label: 'Active contracts', value: rows.length }, { label: 'Renewing in 90 days', value: rows.filter((v) => days(v.contract) <= 90).length, status: 'Attention' }, { label: 'Committed volume', value: rows.reduce((a, v) => a + v.volume, 0), format: compact, hint: 'annual' }]} />
      <DataTable rows={rows} searchOf={(v) => v.name}
        cols={[{ key: 'name', label: 'Vendor', render: (v) => <b className="text-heading">{v.name}</b> }, { key: 'volume', label: 'Annual volume', align: 'right', render: (v) => money(v.volume) }, { key: 'contract', label: 'Renewal', sort: (v) => days(v.contract), render: (v) => v.contract.replace('Renews ', '') }, { key: 'in', label: 'Time left', align: 'right', sort: (v) => days(v.contract), render: (v) => <Badge tone={days(v.contract) <= 90 ? 'warning' : 'success'}>{days(v.contract)} days</Badge> }]}
        actions={(v) => <Button size="sm" variant={days(v.contract) <= 90 ? 'primary' : 'secondary'} onClick={() => setRenew(v)}>Renew</Button>} />
      <ConfirmDialog open={!!renew} title={`Renew ${renew?.name}?`} body="Extends the contract by 12 months from the current renewal date at existing terms." confirmLabel="Renew 12 months" onClose={() => setRenew(null)} onConfirm={() => { if (renew) { const nd = new Date(Date.parse(renew.contract.replace('Renews ', '')) + 365 * 86400000).toISOString().slice(0, 10); db.patch('vendors', renew.id, { contract: `Renews ${nd}` }); db.log(`Renewed contract ${renew.name}`, 'Vendors', renew.contract, `Renews ${nd}`); toast(`${renew.name} renewed until ${nd}`) } }} />
    </Page>
  )
}

const Payments = () => {
  const { d, rows } = useV()
  const [f, setF] = useState('All')
  const inv = d.invoices.filter((i) => f === 'All' || i.status === f)
  const owed = d.invoices.filter((i) => i.status !== 'Paid')
  return (
    <Page title="Vendor Payments" desc="Supplier invoices, what is owed and what has been paid.">
      <KpiRow cols={4} items={[{ label: 'Outstanding', value: owed.reduce((a, i) => a + i.amount + i.tax, 0), format: compact, status: owed.length ? 'Attention' : 'Healthy' }, { label: 'Overdue', value: d.invoices.filter((i) => i.status === 'Overdue').length, status: 'Critical', hint: 'invoices' }, { label: 'Paid', value: d.invoices.filter((i) => i.status === 'Paid').reduce((a, i) => a + i.amount + i.tax, 0), format: compact }, { label: 'Vendors with dues', value: new Set(owed.map((i) => i.party)).size, hint: `of ${rows.length}` }]} />
      <DataTable rows={inv} searchOf={(i) => `${i.id} ${i.party}`} filters={<Tabs value={f} onChange={setF} options={['All', 'Due', 'Overdue', 'Paid']} />}
        cols={[{ key: 'id', label: 'Invoice', render: (i) => <b className="text-heading">{i.id}</b> }, { key: 'party', label: 'Vendor' }, { key: 'amount', label: 'Amount', align: 'right', render: (i) => money(i.amount + i.tax) }, { key: 'due', label: 'Due' }, { key: 'status', label: 'Status', render: (i) => <StatusBadge s={i.status} /> }]}
        actions={(i) => i.status !== 'Paid' ? <Button size="sm" variant="primary" onClick={() => { db.patch('invoices', i.id, { status: 'Paid' }); db.add('txns', { id: `TXN-${Date.now() % 1000000}`, type: 'Payout', orderId: i.id, amount: -(i.amount + i.tax), method: 'Net Banking', date: '2026-10-08', status: 'Settled' }); db.log(`Paid ${i.id}`, 'Vendors', i.status, 'Paid'); toast(`${i.id} paid to ${i.party}`) }}>Pay now</Button> : null} />
    </Page>
  )
}

const Compliance = () => {
  const { d, rows } = useV()
  const ok = (c: string) => !/due/i.test(c)
  return (
    <Page title="Vendor Compliance" desc="Certifications and audit status for every approved vendor.">
      <KpiRow cols={3} items={[{ label: 'Compliant', value: rows.filter((v) => ok(v.compliance)).length, status: 'Healthy', hint: `of ${rows.length}` }, { label: 'Audit due', value: rows.filter((v) => !ok(v.compliance)).length, status: 'Attention' }, { label: 'High-risk vendors', value: d.vendors.filter((v) => v.risk === 'High').length, status: 'Critical' }]} />
      <DataTable rows={rows} searchOf={(v) => `${v.name} ${v.compliance}`}
        cols={[{ key: 'name', label: 'Vendor', render: (v) => <b className="text-heading">{v.name}</b> }, { key: 'category', label: 'Category' }, { key: 'compliance', label: 'Certification', render: (v) => <Badge tone={ok(v.compliance) ? 'success' : 'warning'} dot>{v.compliance}</Badge> }, { key: 'risk', label: 'Risk', render: (v) => <StatusBadge s={v.risk} /> }]}
        actions={(v) => ok(v.compliance) ? <Button size="sm" variant="ghost" onClick={() => toast(`Certificate for ${v.name} downloaded`, 'info')}>Certificate</Button> : <><Button size="sm" onClick={() => { db.notify('Compliance', `Documents requested from ${v.name}`, 'Audit paperwork requested.', '/vendors/compliance'); toast(`Document request sent to ${v.name}`) }}>Request docs</Button><Button size="sm" variant="primary" onClick={() => { db.patch('vendors', v.id, { compliance: 'ISO 9001 verified' }); db.log(`Verified compliance ${v.name}`, 'Vendors', v.compliance, 'ISO 9001 verified'); toast(`${v.name} marked verified`) }}>Mark verified</Button></>} />
    </Page>
  )
}

export const screens: Record<string, () => ReactNode> = { overview: Overview, 'vendor-directory': Directory, 'vendor-performance': Performance, products: Products, 'purchase-orders': POs, contracts: Contracts, payments: Payments, compliance: Compliance }
