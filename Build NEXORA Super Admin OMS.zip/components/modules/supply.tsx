'use client'
import { useState, type ReactNode } from 'react'
import { ClipboardList, MapPin, Package, Store, Truck, Warehouse } from 'lucide-react'
import Link from 'next/link'
import { Badge, Button, DataTable, StatusBadge, Tabs, toast } from '@/components/ui/core'
import { BarList, Chain, Feed, Grid, KpiRow, Page, Panel, Stages } from '@/components/blocks'
import { Chart, Donut } from '@/components/charts/charts'
import { ReqTable } from './procurement'
import { db, compact, inventoryStatus, money, useDB } from '@/lib/db'
import { spark } from '@/lib/metrics'
import type { PurchaseOrder } from '@/types'

function useSC() {
  const d = useDB()
  const vn = (id: string) => d.vendors.find((v) => v.id === id)?.name ?? id
  const pn = (sku: string) => d.products.find((p) => p.sku === sku)?.name ?? sku
  const stats = d.vendors.map((v) => {
    const po = d.pos.filter((p) => p.vendorId === v.id)
    const late = po.filter((p) => p.status === 'Delayed').length
    const onTime = po.length ? Math.round((100 * (po.length - late)) / po.length) : 100
    const score = Math.max(0, Math.min(100, Math.round(v.reliability * 0.6 + onTime * 0.4 - (v.leadTime > 20 ? 5 : 0) - (v.risk === 'High' ? 8 : v.risk === 'Medium' ? 3 : 0))))
    return { ...v, pos: po.length, late, onTime, open: po.filter((p) => p.status !== 'Received').length, score }
  })
  const open = d.pos.filter((p) => p.status !== 'Received')
  const avgLead = d.vendors.length ? d.vendors.reduce((a, v) => a + v.leadTime, 0) / d.vendors.length : 0
  const onTimeAll = d.pos.length ? Math.round((100 * d.pos.filter((p) => p.status !== 'Delayed').length) / d.pos.length) : 100
  return { d, vn, pn, stats, open, avgLead, onTimeAll }
}

const Overview = () => {
  const { d, vn, pn, stats, open, avgLead, onTimeAll } = useSC()
  const st = (s: string) => d.pos.filter((p) => p.status === s).length
  return (
    <Page title="Supply Chain Overview" desc="Supplier health, inbound flow and risk at a glance.">
      <KpiRow cols={5} items={[{ label: 'Active suppliers', value: d.vendors.length, hint: `${d.products.length} SKUs sourced` }, { label: 'Avg lead time', value: avgLead, format: (n) => `${n.toFixed(1)}d`, trend: 3.2, invert: true, prev: 'last month', spark: spark(1, false) }, { label: 'On-time POs', value: onTimeAll, format: (n) => `${Math.round(n)}%`, trend: 1.4, prev: 'last month', spark: spark(2) }, { label: 'Open PO value', value: open.reduce((a, p) => a + p.value, 0), format: compact, hint: `${open.length} open POs` }, { label: 'High-risk suppliers', value: d.vendors.filter((v) => v.risk === 'High').length, status: 'Critical', hint: 'need mitigation' }]} />
      <Grid>
        <Panel title="PO pipeline" sub="By status"><Donut data={['Draft', 'Sent', 'In Transit', 'Delayed', 'Received'].map((s) => ({ name: s, value: st(s) }))} center={`${d.pos.length} POs`} /></Panel>
        <Panel title="Lead time by supplier" sub="Days"><Chart type="bar" legend={false} height={220} data={stats.map((v) => ({ name: v.name.split(' ')[0], value: v.leadTime }))} series={[{ key: 'value', label: 'Lead time (days)' }]} /></Panel>
      </Grid>
      <Grid>
        <Panel title="Delayed inbound"><Feed items={d.pos.filter((p) => p.status === 'Delayed').map((p) => ({ title: `${p.id} · ${pn(p.sku)}`, sub: `${vn(p.vendorId)} · ${p.qty} units`, time: `ETA ${p.eta}`, badge: p.status }))} /></Panel>
        <Panel title="Supplier scorecard"><BarList items={[...stats].sort((a, b) => b.score - a.score).map((v) => ({ label: v.name, value: v.score, display: `${v.score}`, tone: v.score >= 85 ? 'success' : v.score >= 70 ? 'warning' : 'danger' }))} /></Panel>
      </Grid>
    </Page>
  )
}

const Flow = () => {
  const { d, stats, open } = useSC()
  const pipe = ['Draft', 'Sent', 'In Transit', 'Received'].map((s) => d.pos.filter((p) => p.status === s).length)
  const inbound = d.inventory.reduce((a, r) => a + r.incoming, 0)
  const allocated = d.orders.filter((o) => ['Allocated', 'Picking', 'Packed'].includes(o.status)).length
  const moving = d.shipments.filter((s) => ['In Transit', 'Out for Delivery', 'Active'].includes(s.status)).length
  const delayed = d.shipments.filter((s) => s.status === 'Delayed' || s.status === 'Failed').length
  return (
    <Page title="Supply Chain Map" desc="End-to-end view from supplier to customer doorstep.">
      <Panel title="Flow" sub="Live counts from procurement, warehouses and logistics">
        <Chain nodes={[
          { label: 'Supplier', value: `${d.vendors.length}`, sub: `${stats.filter((v) => v.risk === 'High').length} high risk`, icon: Store, tone: stats.some((v) => v.risk === 'High') ? 'warn' : 'ok' },
          { label: 'Purchase Order', value: `${open.length}`, sub: `${compact(open.reduce((a, p) => a + p.value, 0))} open`, icon: ClipboardList, tone: pipe[0] > 2 ? 'warn' : 'ok' },
          { label: 'Inbound', value: `${pipe[2]}`, sub: `${d.pos.filter((p) => p.status === 'Delayed').length} delayed`, icon: Truck, tone: d.pos.some((p) => p.status === 'Delayed') ? 'bad' : 'ok' },
          { label: 'Warehouse', value: inbound.toLocaleString('en-IN'), sub: 'units incoming', icon: Warehouse, tone: d.inventory.some((r) => inventoryStatus(r) === 'Out of Stock') ? 'warn' : 'ok' },
          { label: 'Fulfilment', value: `${allocated}`, sub: 'orders in pick/pack', icon: Package, tone: d.orders.some((o) => o.status === 'On Hold') ? 'warn' : 'ok' },
          { label: 'Delivery', value: `${moving}`, sub: `${delayed} exceptions`, icon: MapPin, tone: delayed > 3 ? 'bad' : delayed ? 'warn' : 'ok' },
        ]} />
      </Panel>
      <Grid>
        <Panel title="Orders by fulfilment stage"><Chart type="bar" legend={false} height={240} data={['New', 'Confirmed', 'Allocated', 'Picking', 'Packed', 'Shipped', 'Delivered'].map((s) => ({ name: s, value: d.orders.filter((o) => o.status === s).length }))} series={[{ key: 'value', label: 'Orders' }]} /></Panel>
        <Panel title="Inbound units by warehouse"><BarList items={d.warehouses.map((w) => ({ label: w.name, sub: w.city, value: d.inventory.filter((r) => r.warehouse === w.id).reduce((a, r) => a + r.incoming, 0), display: `${d.inventory.filter((r) => r.warehouse === w.id).reduce((a, r) => a + r.incoming, 0)} units` }))} /></Panel>
      </Grid>
    </Page>
  )
}

const FlowStages = ['Pending', 'Approved', 'Sent', 'In Transit', 'Received'] as const
const ProcFlow = () => {
  const { d, vn, pn } = useSC()
  const [sel, setSel] = useState<string>('Pending')
  const count = (s: string) => (s === 'Pending' || s === 'Approved' ? d.requests.filter((r) => r.status === s).length : d.pos.filter((p) => p.status === s).length)
  const rows = d.pos.filter((p) => p.status === sel)
  return (
    <Page title="Procurement Flow" desc="Track a request from approval to goods received. Select a stage to drill in.">
      <Stages onSelect={setSel} stages={FlowStages.map((s) => ({ label: s === 'Pending' ? 'Pending approval' : s, count: count(s), active: sel === s, sub: s === 'Pending' || s === 'Approved' ? 'requests' : 'POs' }))} />
      {sel === 'Pending' || sel === 'Approved' ? <ReqTable statuses={[sel as 'Pending' | 'Approved']} /> : (
        <DataTable<PurchaseOrder> rows={rows} searchOf={(p) => `${p.id} ${vn(p.vendorId)} ${p.sku}`} empty={{ title: `No POs ${sel.toLowerCase()}`, body: 'Nothing is at this stage right now.' }}
          cols={[{ key: 'id', label: 'PO', render: (p) => <b className="text-heading">{p.id}</b> }, { key: 'v', label: 'Vendor', render: (p) => vn(p.vendorId) }, { key: 'sku', label: 'Product', render: (p) => pn(p.sku) }, { key: 'qty', label: 'Qty', align: 'right' }, { key: 'value', label: 'Value', align: 'right', render: (p) => money(p.value) }, { key: 'eta', label: 'ETA' }, { key: 'status', label: 'Status', render: (p) => <StatusBadge s={p.status} /> }]}
          actions={(p) => sel === 'Received' ? null : <Button size="sm" onClick={() => { const next = p.status === 'Draft' ? 'Sent' : p.status === 'Sent' ? 'In Transit' : 'Received'; db.patch('pos', p.id, { status: next }); db.log(`Advanced ${p.id}`, 'Supply Chain', p.status, next); toast(`${p.id} → ${next}`) }}>Advance</Button>} />
      )}
    </Page>
  )
}

const Performance = () => {
  const { stats } = useSC()
  return (
    <Page title="Supplier Performance" desc="Reliability, on-time delivery and lead time, combined into one supplier score.">
      <Grid>
        <Panel title="Reliability vs on-time"><Chart type="bar" height={260} data={stats.map((v) => ({ name: v.name.split(' ')[0], Reliability: v.reliability, 'On-time': v.onTime }))} series={[{ key: 'Reliability', label: 'Reliability %' }, { key: 'On-time', label: 'On-time PO %', color: 'var(--purple)' }]} /></Panel>
        <Panel title="Supplier score"><BarList items={[...stats].sort((a, b) => b.score - a.score).map((v) => ({ label: v.name, sub: v.category, value: v.score, display: `${v.score}/100`, tone: v.score >= 85 ? 'success' : v.score >= 70 ? 'warning' : 'danger' }))} /></Panel>
      </Grid>
      <DataTable rows={stats} searchOf={(v) => `${v.name} ${v.category}`}
        cols={[{ key: 'name', label: 'Supplier', render: (v) => <b className="text-heading">{v.name}</b> }, { key: 'category', label: 'Category' }, { key: 'reliability', label: 'Reliability', align: 'right', render: (v) => `${v.reliability}%` }, { key: 'onTime', label: 'On-time', align: 'right', render: (v) => `${v.onTime}%` }, { key: 'leadTime', label: 'Lead time', align: 'right', render: (v) => `${v.leadTime}d` }, { key: 'late', label: 'Delayed POs', align: 'right' }, { key: 'score', label: 'Score', align: 'right', render: (v) => <Badge tone={v.score >= 85 ? 'success' : v.score >= 70 ? 'warning' : 'danger'}>{v.score}</Badge> }]} />
    </Page>
  )
}

const Risks = () => {
  const { d, stats } = useSC()
  const rows = stats.map((v) => {
    const reasons = [v.risk !== 'Low' && `${v.risk} risk rating`, v.late > 0 && `${v.late} delayed PO${v.late > 1 ? 's' : ''}`, v.leadTime > 20 && `Lead time ${v.leadTime}d`, /due/i.test(v.compliance) && 'Compliance audit due', v.reliability < 85 && `Reliability ${v.reliability}%`].filter(Boolean) as string[]
    const score = Math.min(100, (v.risk === 'High' ? 40 : v.risk === 'Medium' ? 20 : 0) + v.late * 15 + (v.leadTime > 20 ? 15 : 0) + (/due/i.test(v.compliance) ? 10 : 0) + Math.max(0, 90 - v.reliability))
    return { ...v, reasons, riskScore: score }
  }).sort((a, b) => b.riskScore - a.riskScore)
  const dep = (id: string) => Math.round((100 * d.products.filter((p) => p.vendorId === id).length) / Math.max(1, d.products.length))
  return (
    <Page title="Supply Risks" desc="Suppliers ranked by risk exposure, with the signals behind each score.">
      <KpiRow cols={3} items={[{ label: 'High exposure', value: rows.filter((r) => r.riskScore >= 50).length, status: 'Critical', hint: 'score 50+' }, { label: 'Watchlist', value: rows.filter((r) => r.riskScore >= 25 && r.riskScore < 50).length, status: 'Attention', hint: 'score 25-49' }, { label: 'Largest SKU dependency', value: Math.max(0, ...rows.map((r) => dep(r.id))), format: (n) => `${Math.round(n)}%`, hint: 'of catalog on one supplier' }]} />
      <DataTable rows={rows} searchOf={(r) => `${r.name} ${r.reasons.join(' ')}`}
        cols={[{ key: 'name', label: 'Supplier', render: (r) => <div><b className="text-heading">{r.name}</b><div className="text-xs text-muted">{dep(r.id)}% of SKUs</div></div> }, { key: 'risk', label: 'Rating', render: (r) => <StatusBadge s={r.risk} /> }, { key: 'reasons', label: 'Signals', sort: (r) => r.reasons.length, render: (r) => r.reasons.length ? <div className="flex flex-wrap gap-1">{r.reasons.map((x) => <Badge key={x} tone="warning">{x}</Badge>)}</div> : <span className="text-muted">None</span> }, { key: 'riskScore', label: 'Risk score', align: 'right', render: (r) => <b className="text-heading">{r.riskScore}</b> }]}
        actions={(r) => <><Button size="sm" onClick={() => { db.notify('Suppliers', `Backup sourcing for ${r.name}`, 'Qualification of a backup supplier has been requested.', '/supply-chain-management/supply-risks'); db.log(`Requested backup for ${r.name}`, 'Supply Chain', r.risk, r.risk); toast(`Backup supplier request raised for ${r.name}`) }}>Qualify backup</Button>{r.risk !== 'Low' && <Button size="sm" variant="primary" onClick={() => { const to = r.risk === 'High' ? 'Medium' : 'Low'; db.patch('vendors', r.id, { risk: to }); db.log(`Mitigated risk for ${r.name}`, 'Supply Chain', r.risk, to); toast(`${r.name} risk lowered to ${to}`) }}>Mark mitigated</Button>}</>} />
    </Page>
  )
}

const Bottlenecks = () => {
  const { d } = useSC()
  const pend = d.requests.filter((r) => r.status === 'Pending')
  const appr = d.requests.filter((r) => r.status === 'Approved')
  const late = d.pos.filter((p) => p.status === 'Delayed')
  const gaps = d.inventory.filter((r) => inventoryStatus(r) !== 'In Stock' && r.incoming === 0)
  const hold = d.orders.filter((o) => o.status === 'On Hold')
  const slow = d.shipments.filter((s) => s.status === 'Delayed' || s.status === 'Failed')
  const rows = [
    { id: 'b1', stage: 'Request approval', count: pend.length, impact: 'Replenishment waits on a decision', cta: 'Approve all', run: () => { pend.forEach((r) => db.patch('requests', r.id, { status: 'Approved' })); db.log(`Bulk approved ${pend.length} requests`, 'Supply Chain', 'Pending', 'Approved'); toast(`${pend.length} requests approved`) } },
    { id: 'b2', stage: 'Approved, not ordered', count: appr.length, impact: 'Approved demand not yet with suppliers', cta: 'Convert to POs', run: () => { appr.forEach((r, i) => { db.patch('requests', r.id, { status: 'Converted' }); db.add('pos', { id: `PO-${9100 + d.pos.length + i}`, vendorId: r.vendorId, sku: r.sku, qty: r.qty, value: r.value, status: 'Sent', eta: '2026-10-22', date: '2026-10-08' }) }); toast(`${appr.length} POs created`) } },
    { id: 'b3', stage: 'Supplier delays', count: late.length, impact: 'Inbound stock past its ETA', cta: 'Chase suppliers', run: () => { db.notify('Suppliers', 'Delayed POs escalated', `${late.length} suppliers asked for revised ETAs.`, '/supply-chain-management/bottlenecks'); toast('Suppliers contacted') } },
    { id: 'b4', stage: 'Stock gap, nothing inbound', count: gaps.length, impact: 'Low or zero stock with no PO covering it', cta: 'Raise requests', run: () => { gaps.forEach((r, i) => { const p = d.products.find((x) => x.sku === r.sku); if (p) db.add('requests', { id: `PR-${7200 + d.requests.length + i}`, sku: r.sku, qty: Math.max(100, r.reorder * 2), buyer: 'Aditi Rao', vendorId: p.vendorId, value: Math.round(p.price * 0.45 * Math.max(100, r.reorder * 2)), status: 'Pending', date: '2026-10-08' }) }); toast(`${gaps.length} purchase requests raised`) } },
    { id: 'b5', stage: 'Orders on hold', count: hold.length, impact: 'Customer orders blocked in fulfilment', cta: 'Release all', run: () => { hold.forEach((o) => db.setOrderStatus(o.id, 'Confirmed')); toast(`${hold.length} orders released`) } },
    { id: 'b6', stage: 'Delivery exceptions', count: slow.length, impact: 'Delayed or failed last-mile deliveries', cta: '', run: () => {} },
  ]
  return (
    <Page title="Bottlenecks" desc="Where the chain is slowing down, ranked by volume, with one-click remedies.">
      <Panel title="Queue depth by stage"><BarList items={[...rows].sort((a, b) => b.count - a.count).map((r) => ({ label: r.stage, value: r.count, display: `${r.count}`, max: Math.max(...rows.map((x) => x.count), 1), tone: r.count > 4 ? 'danger' : r.count > 1 ? 'warning' : 'success' }))} /></Panel>
      <DataTable rows={rows} cols={[{ key: 'stage', label: 'Stage', render: (r) => <b className="text-heading">{r.stage}</b> }, { key: 'count', label: 'Items', align: 'right' }, { key: 'impact', label: 'Impact' }, { key: 'status', label: 'Status', render: (r) => <StatusBadge s={r.count === 0 ? 'Healthy' : r.count > 4 ? 'Critical' : 'Attention'} /> }]}
        actions={(r) => r.id === 'b6' ? <Link href="/delivery-not-happening/delayed-deliveries" className="text-[13px] font-medium text-primary hover:underline">Open</Link> : <Button size="sm" disabled={r.count === 0} onClick={r.run}>{r.cta}</Button>} />
    </Page>
  )
}

const Lead = () => {
  const { stats, avgLead, pn, d } = useSC()
  const [target, setTarget] = useState('14')
  const t = Number(target)
  const trend = ['May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'].map((m, i) => ({ name: m, Actual: Math.round(avgLead * (1.14 - i * 0.025) * 10) / 10, Target: t }))
  return (
    <Page title="Lead Time Analysis" desc="Quoted lead time per supplier against your target." actions={<Tabs value={target} onChange={setTarget} options={['10', '14', '21']} />}>
      <KpiRow cols={3} items={[{ label: 'Average lead time', value: avgLead, format: (n) => `${n.toFixed(1)}d`, hint: `target ${t}d` }, { label: 'Suppliers over target', value: stats.filter((v) => v.leadTime > t).length, status: stats.some((v) => v.leadTime > t) ? 'Attention' : 'Healthy', hint: `of ${stats.length}` }, { label: 'Fastest supplier', value: Math.min(...stats.map((v) => v.leadTime)), format: (n) => `${Math.round(n)}d`, hint: [...stats].sort((a, b) => a.leadTime - b.leadTime)[0]?.name }]} />
      <Grid>
        <Panel title="Lead time by supplier"><Chart type="bar" legend={false} height={240} data={stats.map((v) => ({ name: v.name.split(' ')[0], value: v.leadTime }))} series={[{ key: 'value', label: 'Days' }]} /></Panel>
        <Panel title="Trend vs target" sub="Average days, 6 months"><Chart type="line" height={240} data={trend} series={[{ key: 'Actual', label: 'Actual' }, { key: 'Target', label: 'Target', color: 'var(--danger)' }]} /></Panel>
      </Grid>
      <DataTable rows={stats} searchOf={(v) => v.name}
        cols={[{ key: 'name', label: 'Supplier', render: (v) => <b className="text-heading">{v.name}</b> }, { key: 'leadTime', label: 'Quoted', align: 'right', render: (v) => `${v.leadTime}d` }, { key: 'gap', label: 'vs target', align: 'right', sort: (v) => v.leadTime - t, render: (v) => <span className={v.leadTime > t ? 'font-semibold text-danger' : 'text-success'}>{v.leadTime - t > 0 ? '+' : ''}{v.leadTime - t}d</span> }, { key: 'skus', label: 'SKUs', render: (v) => d.products.filter((p) => p.vendorId === v.id).slice(0, 2).map((p) => pn(p.sku)).join(', ') || '—' }, { key: 'open', label: 'Open POs', align: 'right' }]}
        actions={(v) => v.leadTime > t ? <Button size="sm" onClick={() => { db.notify('Suppliers', `Lead time review: ${v.name}`, `Quoted ${v.leadTime}d exceeds ${t}d target.`, '/supply-chain-management/lead-time-analysis'); toast(`Lead time review requested from ${v.name}`) }}>Request improvement</Button> : null} />
    </Page>
  )
}

export const screens: Record<string, () => ReactNode> = { overview: Overview, 'supply-chain-overview': Flow, 'procurement-flow': ProcFlow, 'supplier-performance': Performance, 'supply-risks': Risks, bottlenecks: Bottlenecks, 'lead-time-analysis': Lead }
