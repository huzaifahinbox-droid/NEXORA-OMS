'use client'
import { notFound } from 'next/navigation'
import { REGISTRY } from './index'

export function ModuleScreen({ module, page }: { module: string; page: string }) {
  const Screen = REGISTRY[module]?.[page]
  if (!Screen) notFound()
  return <Screen />
}
