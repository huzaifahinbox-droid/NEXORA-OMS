'use client'
import { useState, type ReactNode } from 'react'
import { Plus } from 'lucide-react'
import { Badge, Button, ConfirmDialog, DataTable, Progress, StatusBadge, Tabs, toast } from '@/components/ui/core'
import { BarList, Feed, Grid, Kanban, KpiRow, Page, Panel, RecordModal, Stages } from '@/components/blocks'
import { Chart } from '@/components/charts/charts'
import { useNames } from '@/components/tables'
import { db, money, useDB } from '@/lib/db'
import { spark } from '@/lib/metrics'
import type { Order, OrderStatus, PurchaseOrder, StockTxn, Warehouse } from '@/types'

const BASE = '/warehouse-management'
const pct = (n: number) => `${Math.round(n)}%`

const Overview = () => {
  const d = useDB()
  const n = (s: OrderStatus) => d.orders.filter((o) => o.status === s).length
  const inbound = d.pos.filter((p) => ['Sent', 'In Transit', 'Delayed'].includes(p.status)).length
  const avgOcc = d.warehouses.reduce((a, w) => a + w.occupancy, 0) / Math.max(1, d.warehouses.length)
  return (
    <Page title="Warehouse Overview" desc="Capacity, inbound and outbound flow across every fulfillment site.">
      <KpiRow cols={6} items={[{ label: 'Warehouses', value: d.warehouses.length, hint: 'active sites' }, { label: 'Avg utilization', value: avgOcc, format: pct, trend: 2.1, prev: 'last week', invert: true, spark: spark(2) }, { label: 'Inbound POs', value: inbound, hint: 'awaiting receipt' }, { label: 'To pick', value: n('Allocated'), hint: 'allocated orders' }, { label: 'To pack', value: n('Picking'), hint: 'picked orders' }, { label: 'To dispatch', value: n('Packed'), status: n('Packed') > 5 ? 'Attention' : 'Healthy', hint: 'packed orders' }]} />
      <Panel title="Fulfillment flow" sub="Select a stage to work its queue"><Stages stages={[{ label: 'Receiving', count: inbound, href: `${BASE}/receiving` }, { label: 'Putaway', count: d.stockTxns.filter((t) => t.type === 'Inbound').length, href: `${BASE}/putaway` }, { label: 'Picking', count: n('Allocated'), href: `${BASE}/picking` }, { label: 'Packing', count: n('Picking'), href: `${BASE}/packing` }, { label: 'Dispatch', count: n('Packed'), href: `${BASE}/dispatch` }]} /></Panel>
      <Grid>
        <Panel title="Utilization by site" sub="Occupancy of storage capacity"><Chart type="bar" height={240} fmt={pct} data={d.warehouses.map((w) => ({ name: w.id, Occupancy: w.occupancy }))} series={[{ key: 'Occupancy', label: 'Occupancy' }]} /></Panel>
        <Panel title="Open orders per warehouse"><BarList items={d.warehouses.map((w) => { const c = d.orders.filter((o) => o.warehouse === w.id && ['Allocated', 'Picking', 'Packed'].includes(o.status)).length; return { label: w.name, sub: w.id, value: c, display: `${c} orders`, tone: w.occupancy > 85 ? 'warning' : 'primary' } })} /></Panel>
      </Grid>
    </Page>
  )
}

const Directory = () => {
  const d = useDB()
  const [modal, setModal] = useState<{ id?: string; init: Record<string, string> } | null>(null)
  const [del, setDel] = useState<Warehouse | null>(null)
  const open = (w?: Warehouse) => setModal({ id: w?.id, init: w ? { name: w.name, city: w.city, state: w.state, capacity: String(w.capacity), manager: w.manager } : {} })
  const save = (v: Record<string, string>) => {
    const capacity = parseInt(v.capacity, 10) || 0
    if (modal?.id) { db.patch('warehouses', modal.id, { name: v.name, city: v.city, state: v.state, capacity, manager: v.manager }); db.log(`Updated warehouse ${modal.id}`, 'Warehouse', '—', v.name); toast(`${modal.id} updated`); return }
    const id = `WH-${v.city.slice(0, 3).toUpperCase()}-${String(d.warehouses.length + 1).padStart(2, '0')}`
    db.add('warehouses', { id, name: v.name, city: v.city, state: v.state, capacity, occupancy: 0, picking: 90, packing: 90, dispatch: 90, manager: v.manager }, false)
    db.log(`Created warehouse ${id}`, 'Warehouse', '—', v.name); toast(`${id} created`)
  }
  return (
    <Page title="Warehouse Directory" desc="Manage fulfillment sites, capacity and managers." actions={<Button variant="primary" icon={Plus} onClick={() => open()}>Add warehouse</Button>}>
      <DataTable rows={d.warehouses} searchOf={(w) => `${w.id} ${w.name} ${w.city} ${w.manager}`} empty={{ title: 'No warehouses yet', body: 'Add your first fulfillment site.', cta: 'Add warehouse', onCta: () => open() }}
        cols={[{ key: 'id', label: 'ID', render: (w) => <b className="text-heading">{w.id}</b> }, { key: 'name', label: 'Name' }, { key: 'city', label: 'Location', sort: (w) => w.city, render: (w) => `${w.city}, ${w.state}` }, { key: 'capacity', label: 'Capacity', align: 'right', render: (w) => w.capacity.toLocaleString('en-IN') }, { key: 'occupancy', label: 'Utilization', render: (w) => <div className="flex w-32 items-center gap-2"><div className="flex-1"><Progress value={w.occupancy} tone={w.occupancy > 85 ? 'warning' : 'primary'} /></div><span className="tabular-nums">{w.occupancy}%</span></div> }, { key: 'manager', label: 'Manager' }]}
        actions={(w) => <><Button size="sm" onClick={() => open(w)}>Edit</Button><Button size="sm" variant="ghost" onClick={() => setDel(w)}>Delete</Button></>} />
      <RecordModal open={!!modal} onClose={() => setModal(null)} title={modal?.id ? `Edit ${modal.id}` : 'Add warehouse'} initial={modal?.init} onSubmit={save} fields={[{ key: 'name', label: 'Warehouse name' }, { key: 'city', label: 'City' }, { key: 'state', label: 'State' }, { key: 'capacity', label: 'Capacity (units)', type: 'number' }, { key: 'manager', label: 'Manager', type: 'select', options: d.users.map((u) => u.name) }]} />
      <ConfirmDialog open={!!del} danger title={`Delete ${del?.id}?`} body="Warehouses that still hold stock cannot be deleted. This action is recorded in the audit log." confirmLabel="Delete" onClose={() => setDel(null)} onConfirm={() => { if (!del) return; if (d.inventory.some((r) => r.warehouse === del.id)) { toast(`${del.id} still holds stock. Transfer it first`, 'danger'); return } db.remove('warehouses', del.id); db.log(`Deleted warehouse ${del.id}`, 'Warehouse', del.name, '—'); toast(`${del.id} deleted`) }} />
    </Page>
  )
}

const Receiving = () => {
  const d = useDB()
  const { prod } = useNames()
  const rows = d.pos.filter((p) => ['Sent', 'In Transit', 'Delayed'].includes(p.status))
  const receive = (p: PurchaseOrder) => {
    const row = d.inventory.find((r) => r.sku === p.sku && r.incoming > 0) ?? d.inventory.find((r) => r.sku === p.sku)
    db.patch('pos', p.id, { status: 'Received' })
    if (row) { db.patch('inventory', row.id, { available: row.available + p.qty, incoming: Math.max(0, row.incoming - p.qty) }); db.add('stockTxns', { id: `ST-${Date.now()}`, sku: p.sku, type: 'Inbound', qty: p.qty, warehouse: row.warehouse, ref: p.id, time: 'just now' }) }
    db.log(`Received ${p.id} into ${row?.warehouse ?? 'warehouse'}`, 'Warehouse', p.status, 'Received'); toast(`${p.id} received. Stock updated${row ? ` at ${row.warehouse}` : ''}`)
  }
  return (
    <Page title="Receiving" desc="Inbound purchase orders waiting at the dock. Receiving updates inventory and the stock ledger instantly.">
      <KpiRow cols={4} items={[{ label: 'Expected POs', value: rows.length }, { label: 'Delayed', value: rows.filter((p) => p.status === 'Delayed').length, status: 'Attention' }, { label: 'Units inbound', value: rows.reduce((a, p) => a + p.qty, 0) }, { label: 'Received', value: d.pos.filter((p) => p.status === 'Received').length, hint: 'all time' }]} />
      <DataTable rows={rows} searchOf={(p) => `${p.id} ${p.sku} ${p.vendorId}`} empty={{ title: 'Dock is clear', body: 'No inbound purchase orders are waiting.' }}
        cols={[{ key: 'id', label: 'PO', render: (p) => <b className="text-heading">{p.id}</b> }, { key: 'vendorId', label: 'Vendor', render: (p) => d.vendors.find((v) => v.id === p.vendorId)?.name ?? p.vendorId }, { key: 'sku', label: 'Item', render: (p) => prod(p.sku) }, { key: 'qty', label: 'Qty', align: 'right' }, { key: 'value', label: 'Value', align: 'right', render: (p) => money(p.value) }, { key: 'eta', label: 'ETA' }, { key: 'status', label: 'Status', render: (p) => <StatusBadge s={p.status} /> }]}
        actions={(p) => <Button size="sm" variant="primary" onClick={() => receive(p)}>Mark received</Button>} />
    </Page>
  )
}

const Putaway = () => {
  const d = useDB()
  const { prod } = useNames()
  const [wh, setWh] = useState('All')
  const done = (t: StockTxn) => d.audit.some((a) => a.action === `Put away ${t.id}`)
  const tasks = d.stockTxns.filter((t) => t.type === 'Inbound' && t.qty > 0).map((t, i) => ({ ...t, bin: `${'ABCD'[i % 4]}-${(i * 7) % 20 + 1}-${(i % 3) + 1}` }))
  const rows = tasks.filter((t) => wh === 'All' || t.warehouse === wh)
  const pending = tasks.filter((t) => !done(t))
  return (
    <Page title="Putaway" desc="Move received stock from the dock to its storage bin." actions={<Tabs value={wh} onChange={setWh} options={['All', ...d.warehouses.map((w) => w.id)]} />}>
      <KpiRow cols={3} items={[{ label: 'Pending putaway', value: pending.length, status: pending.length > 4 ? 'Attention' : 'Healthy' }, { label: 'Completed', value: tasks.length - pending.length }, { label: 'Units to shelve', value: pending.reduce((a, t) => a + t.qty, 0) }]} />
      <DataTable rows={rows} searchOf={(t) => `${t.id} ${t.sku} ${t.ref} ${t.bin}`} empty={{ title: 'Nothing to put away', body: 'Received goods will appear here.' }}
        cols={[{ key: 'id', label: 'Task' }, { key: 'sku', label: 'Item', render: (t) => `${prod(t.sku)} (${t.sku})` }, { key: 'qty', label: 'Qty', align: 'right' }, { key: 'warehouse', label: 'Warehouse' }, { key: 'ref', label: 'Source' }, { key: 'bin', label: 'Suggested bin', render: (t) => <Badge tone="primary">{t.bin}</Badge> }, { key: 's', label: 'Status', sort: (t) => (done(t) ? 1 : 0), render: (t) => <StatusBadge s={done(t) ? 'Completed' : 'Pending'} /> }]}
        actions={(t) => (done(t) ? null : <Button size="sm" onClick={() => { db.log(`Put away ${t.id}`, 'Warehouse', 'Dock', t.bin); toast(`${t.qty} units placed in ${t.bin}`) }}>Put away</Button>)} />
    </Page>
  )
}

function OrderQueue({ title, desc, statuses, actionable, verb, side }: { title: string; desc: string; statuses: OrderStatus[]; actionable: OrderStatus; verb: string; side: { title: string; status: OrderStatus } }) {
  const d = useDB()
  const { cust, prod } = useNames()
  const [wh, setWh] = useState('All')
  const inWh = (o: Order) => wh === 'All' || o.warehouse === wh
  const rows = d.orders.filter((o) => statuses.includes(o.status) && inWh(o))
  const queue = d.orders.filter((o) => o.status === actionable)
  return (
    <Page title={title} desc={desc} actions={<Tabs value={wh} onChange={setWh} options={['All', ...d.warehouses.map((w) => w.id)]} />}>
      <KpiRow cols={3} items={[{ label: 'In queue', value: queue.filter(inWh).length }, { label: 'Units', value: queue.filter(inWh).reduce((a, o) => a + o.qty, 0) }, { label: 'Order value', value: queue.filter(inWh).reduce((a, o) => a + o.total, 0), format: money }]} />
      <Grid>
        <Panel title="Queue by warehouse"><BarList items={d.warehouses.map((w) => { const c = queue.filter((o) => o.warehouse === w.id).length; return { label: w.name, value: c, display: `${c} orders`, tone: c > 4 ? 'warning' : 'primary' } })} /></Panel>
        <Panel title={side.title}><Feed items={d.orders.filter((o) => o.status === side.status && inWh(o)).slice(0, 5).map((o) => ({ title: `${o.id} · ${prod(o.sku)}`, sub: `${cust(o.customerId)} · ${o.warehouse}`, time: o.date }))} /></Panel>
      </Grid>
      <DataTable rows={rows} searchOf={(o) => `${o.id} ${cust(o.customerId)} ${o.sku}`} empty={{ title: 'Queue is empty', body: 'Orders reach this stage once they are allocated.' }}
        cols={[{ key: 'id', label: 'Order', render: (o) => <b className="text-heading">{o.id}</b> }, { key: 'c', label: 'Customer', render: (o) => cust(o.customerId) }, { key: 'sku', label: 'Item', render: (o) => `${prod(o.sku)} ×${o.qty}` }, { key: 'warehouse', label: 'Warehouse' }, { key: 'channel', label: 'Channel' }, { key: 'status', label: 'Status', render: (o) => <StatusBadge s={o.status} /> }]}
        actions={(o) => (o.status === actionable ? <Button size="sm" variant="primary" onClick={() => { db.advanceOrder(o.id); toast(`${o.id}: ${verb.toLowerCase()} complete`) }}>{verb}</Button> : null)} />
    </Page>
  )
}

const Picking = () => <OrderQueue title="Picking" desc="Allocated orders waiting for a picker. Starting a pick moves the order into picking." statuses={['Allocated', 'Picking']} actionable="Allocated" verb="Start picking" side={{ title: 'Currently picking', status: 'Picking' }} />
const Packing = () => <OrderQueue title="Packing" desc="Picked orders ready for the packing station. Packing marks the order ready to dispatch." statuses={['Picking']} actionable="Picking" verb="Pack order" side={{ title: 'Packed, awaiting dispatch', status: 'Packed' }} />

const Dispatch = () => {
  const d = useDB()
  const { cust, prod } = useNames()
  const cols: OrderStatus[] = ['Packed', 'Shipped', 'Delivered']
  return (
    <Page title="Dispatch" desc="Hand packed orders to carriers. Shipping creates the shipment, deducts stock and writes the ledger.">
      <KpiRow cols={3} items={cols.map((c) => ({ label: c === 'Packed' ? 'Ready to dispatch' : c, value: d.orders.filter((o) => o.status === c).length }))} />
      <Kanban columns={cols.map((c) => ({ title: c, tone: c === 'Delivered' ? 'success' : c === 'Shipped' ? 'info' : 'warning', items: d.orders.filter((o) => o.status === c).slice(0, c === 'Packed' ? 20 : 8).map((o) => ({ id: o.id, title: o.id, sub: `${cust(o.customerId)} · ${prod(o.sku)}`, tag: o.warehouse.slice(3, 6) })) }))} onMove={(id, from) => { db.advanceOrder(id); toast(`${id} moved to ${cols[from + 1]}`) }} />
    </Page>
  )
}

const Performance = () => {
  const d = useDB()
  const rows = d.warehouses.map((w) => ({ ...w, score: Math.round((w.picking + w.packing + w.dispatch) / 3), orders: d.orders.filter((o) => o.warehouse === w.id).length })).sort((a, b) => b.score - a.score)
  const avg = (k: 'picking' | 'packing' | 'dispatch') => d.warehouses.reduce((a, w) => a + w[k], 0) / Math.max(1, d.warehouses.length)
  return (
    <Page title="Warehouse Performance" desc="Pick, pack and dispatch accuracy by site.">
      <KpiRow cols={4} items={[{ label: 'Picking accuracy', value: avg('picking'), format: pct, trend: 0.8, prev: 'last month' }, { label: 'Packing efficiency', value: avg('packing'), format: pct, trend: 1.2, prev: 'last month' }, { label: 'Dispatch on-time', value: avg('dispatch'), format: pct, trend: -0.4, prev: 'last month' }, { label: 'Orders handled', value: d.orders.length, hint: 'all sites' }]} />
      <Grid>
        <Panel title="Stage performance by site"><Chart type="bar" height={260} fmt={pct} data={d.warehouses.map((w) => ({ name: w.id, Picking: w.picking, Packing: w.packing, Dispatch: w.dispatch }))} series={[{ key: 'Picking', label: 'Picking' }, { key: 'Packing', label: 'Packing' }, { key: 'Dispatch', label: 'Dispatch' }]} /></Panel>
        <Panel title="Ranking" sub="Composite score"><BarList items={rows.map((w) => ({ label: w.name, value: w.score, max: 100, display: `${w.score}`, tone: w.score >= 92 ? 'success' : w.score >= 88 ? 'primary' : 'warning' }))} /></Panel>
      </Grid>
      <DataTable rows={rows} cols={[{ key: 'id', label: 'Site', render: (w) => <b className="text-heading">{w.id}</b> }, { key: 'manager', label: 'Manager' }, { key: 'orders', label: 'Orders', align: 'right' }, { key: 'picking', label: 'Picking', align: 'right', render: (w) => pct(w.picking) }, { key: 'packing', label: 'Packing', align: 'right', render: (w) => pct(w.packing) }, { key: 'dispatch', label: 'Dispatch', align: 'right', render: (w) => pct(w.dispatch) }, { key: 'score', label: 'Score', align: 'right', render: (w) => <Badge tone={w.score >= 92 ? 'success' : w.score >= 88 ? 'info' : 'warning'}>{w.score}</Badge> }]}
        actions={(w) => w.score < 92 ? <Button size="sm" onClick={() => { db.notify('Warehouse', `Improvement plan for ${w.id}`, `${w.manager} to review stage accuracy (score ${w.score}).`, `${BASE}/warehouse-performance`); db.log(`Raised improvement task for ${w.id}`, 'Warehouse', `${w.score}`, 'Review'); toast(`Improvement task sent to ${w.manager}`) }}>Raise task</Button> : null} />
    </Page>
  )
}

export const screens: Record<string, () => ReactNode> = { overview: Overview, 'warehouse-directory': Directory, receiving: Receiving, putaway: Putaway, picking: Picking, packing: Packing, dispatch: Dispatch, 'warehouse-performance': Performance }
