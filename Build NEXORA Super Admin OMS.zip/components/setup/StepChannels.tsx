'use client'
import { useState } from 'react'
import { Code2, Globe, Hand, Plug, ShoppingBag, ShoppingCart, Store, Package, Loader2, type LucideIcon } from 'lucide-react'
import { Button, ConfirmDialog, Input, Modal, StatusBadge, toast, cn } from '@/components/ui/core'
import { setupStore, type SetupState } from '@/lib/session'

const CHANNELS: { id: string; icon: LucideIcon; desc: string; direct?: boolean }[] = [
  { id: 'Shopify', icon: ShoppingBag, desc: 'Sync orders, products and stock from your Shopify store.' },
  { id: 'WooCommerce', icon: ShoppingCart, desc: 'Connect your WordPress / WooCommerce storefront.' },
  { id: 'Amazon', icon: Package, desc: 'Amazon Seller Central orders and FBA inventory.' },
  { id: 'Flipkart', icon: Store, desc: 'Flipkart Seller Hub orders and listings.' },
  { id: 'Marketplace', icon: Globe, desc: 'Other marketplaces such as Myntra, Nykaa and Meesho.' },
  { id: 'POS', icon: Store, desc: 'In-store point of sale sync.', direct: true },
  { id: 'Manual Orders', icon: Hand, desc: 'Create orders manually for phone and B2B sales.', direct: true },
  { id: 'API', icon: Code2, desc: 'Push orders from any system using the NEXORA REST API.' },
]
const wait = (ms: number) => new Promise((r) => setTimeout(r, ms))

export function StepChannels({ s, errors }: { s: SetupState; errors: Record<string, string> }) {
  const [modal, setModal] = useState<string | null>(null)
  const [form, setForm] = useState({ store: '', key: '' })
  const [saving, setSaving] = useState(false)
  const [confirm, setConfirm] = useState<string | null>(null)
  const [busy, setBusy] = useState<string | null>(null)
  const [fe, setFe] = useState<Record<string, string>>({})
  const setStatus = (id: string, v: SetupState['channels'][string]) => setupStore.set((x) => ({ ...x, channels: { ...x.channels, [id]: v } }))

  const open = (id: string) => { const c = s.channelCfg?.[id]; setForm({ store: c?.store ?? '', key: c?.key ?? '' }); setFe({}); setModal(id) }
  const save = async () => {
    const id = modal!
    const n: Record<string, string> = {}
    if (!form.store.trim()) n.store = 'Required.'
    if (form.key.trim().length < 6) n.key = 'Enter at least 6 characters.'
    setFe(n); if (Object.keys(n).length) return
    setSaving(true); await wait(1200)
    setupStore.set((x) => ({ ...x, channelCfg: { ...x.channelCfg, [id]: { ...form } }, channels: { ...x.channels, [id]: 'Connected' } }))
    setSaving(false); setModal(null); toast(`${id} connected.`)
  }
  const connectDirect = async (id: string) => { setBusy(id); await wait(800); setStatus(id, 'Connected'); setBusy(null); toast(`${id} enabled.`) }
  const test = async (id: string) => {
    setBusy(id); setStatus(id, 'Testing'); await wait(1500)
    setStatus(id, 'Verified'); setBusy(null); toast(`${id} connection verified.`)
  }
  const disconnect = (id: string) => { setupStore.set((x) => { const { [id]: _, ...cfg } = x.channelCfg ?? {}; return { ...x, channels: { ...x.channels, [id]: 'Not connected' }, channelCfg: cfg } }); toast(`${id} disconnected.`, 'info') }

  return (
    <div className="space-y-4">
      {errors.channels && <p role="alert" className="rounded-lg bg-danger-bg px-3 py-2 text-sm text-danger">{errors.channels}</p>}
      <div className="grid gap-3 sm:grid-cols-2">
        {CHANNELS.map((c) => {
          const st = s.channels[c.id] ?? 'Not connected'
          const on = st === 'Connected' || st === 'Verified'
          const isBusy = busy === c.id || st === 'Testing'
          return (
            <div key={c.id} className={cn('flex flex-col rounded-xl border bg-surface p-4 transition-colors', on ? 'border-primary/50' : 'border-line hover:border-line-strong')}>
              <div className="flex items-start gap-3">
                <span className="grid size-10 shrink-0 place-items-center rounded-lg bg-primary-light text-primary"><c.icon size={18} /></span>
                <div className="min-w-0 flex-1"><div className="flex flex-wrap items-center justify-between gap-2"><h3 className="text-sm font-semibold text-heading">{c.id}</h3><StatusBadge s={st} /></div><p className="mt-1 text-[13px] text-text-2">{c.desc}</p></div>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                {!on && st !== 'Testing' && <Button size="sm" variant="primary" icon={Plug} loading={busy === c.id} onClick={() => (c.direct ? connectDirect(c.id) : open(c.id))}>Connect</Button>}
                {on && <>
                  {!c.direct && <Button size="sm" onClick={() => open(c.id)}>Configure</Button>}
                  <Button size="sm" disabled={isBusy} onClick={() => test(c.id)}>Test Connection</Button>
                  <Button size="sm" variant="ghost" disabled={isBusy} onClick={() => setConfirm(c.id)}>Disconnect</Button>
                </>}
                {st === 'Testing' && <span className="inline-flex items-center gap-2 text-[13px] text-text-2"><Loader2 size={14} className="animate-spin" />Testing connection…</span>}
              </div>
            </div>
          )
        })}
      </div>
      <Modal open={!!modal} onClose={() => !saving && setModal(null)} title={`Configure ${modal ?? ''}`} footer={<><Button onClick={() => setModal(null)} disabled={saving}>Cancel</Button><Button variant="primary" loading={saving} onClick={save}>Save & Connect</Button></>}>
        <div className="space-y-4">
          <Input label={modal === 'API' ? 'Webhook URL' : 'Store / account name'} required value={form.store} onChange={(e) => setForm({ ...form, store: e.target.value })} error={fe.store} placeholder={modal === 'API' ? 'https://example.com/hooks/orders' : 'my-store.myshopify.com'} />
          <Input label="API key / token" required type="password" value={form.key} onChange={(e) => setForm({ ...form, key: e.target.value })} error={fe.key} hint="Stored locally for this demo only." />
        </div>
      </Modal>
      <ConfirmDialog open={!!confirm} danger title="Disconnect channel?" body={`${confirm} will stop syncing orders and inventory.`} confirmLabel="Disconnect" onConfirm={() => confirm && disconnect(confirm)} onClose={() => setConfirm(null)} />
    </div>
  )
}
