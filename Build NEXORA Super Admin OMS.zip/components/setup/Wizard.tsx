'use client'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useEffect, useRef, useState } from 'react'
import { ArrowLeft, ArrowRight, Check, CheckCircle2 } from 'lucide-react'
import { ThemeToggle } from '@/components/auth/AuthShell'
import { Logo } from '@/components/layout/Sidebar'
import { Button, Progress, cn, toast } from '@/components/ui/core'
import { setupStore, useSetup } from '@/lib/session'
import { hydrateAll } from '@/lib/ui'
import { StepBusiness } from './StepBusiness'
import { StepChannels } from './StepChannels'
import { StepWarehouse } from './StepWarehouse'
import { StepInventory } from './StepInventory'
import { StepLogistics } from './StepLogistics'
import { StepPlan } from './StepPlan'
import { StepReview } from './StepReview'
import { STEPS, firstInvalid, validate } from './validate'

const DESC = [
  'Tell us about your business so we can tailor your workspace.', 'Connect the channels you sell on. You can add more later.', 'Add the locations you store and ship inventory from.',
  'Set how stock is tracked, replenished and protected.', 'Add the carriers you ship with.', 'Choose the plan that fits your volume.', 'Review everything before creating your workspace.',
]

export function Wizard() {
  const router = useRouter()
  const s = useSetup()
  const [show, setShow] = useState(false)
  const [completing, setCompleting] = useState(false)
  const top = useRef<HTMLDivElement>(null)
  useEffect(() => { hydrateAll() }, [])
  const step = Math.min(7, Math.max(1, s.step || 1))
  const errors = show ? validate(step, s) : {}
  const go = (n: number) => { setShow(false); setupStore.set((x) => ({ ...x, step: n })); top.current?.scrollIntoView({ block: 'start' }) }
  const next = () => {
    if (Object.keys(validate(step, s)).length) { setShow(true); toast('Please fix the highlighted items to continue.', 'danger'); return }
    go(step + 1)
  }
  const complete = () => {
    const bad = firstInvalid(s)
    if (bad) { toast(`Step ${bad} is incomplete.`, 'danger'); go(bad); setShow(true); return }
    setCompleting(true)
    setTimeout(() => { setupStore.set((x) => ({ ...x, completed: true })); router.push('/setup-complete') }, 900)
  }
  const props = { s, errors }
  return (
    <div className="min-h-screen bg-bg lg:grid lg:grid-cols-[320px_minmax(0,1fr)]">
      <aside className="hidden border-r border-line bg-surface lg:sticky lg:top-0 lg:flex lg:h-screen lg:flex-col lg:p-8" aria-label="Setup progress">
        <Link href="/login" aria-label="NEXORA"><Logo /></Link>
        <ol className="mt-10 flex-1 space-y-1">
          {STEPS.map((t, i) => {
            const n = i + 1, done = n < step, cur = n === step
            return (
              <li key={t}>
                <button type="button" disabled={n > step} onClick={() => go(n)} aria-current={cur ? 'step' : undefined} className={cn('flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm transition-colors', cur ? 'bg-primary-light font-semibold text-primary' : done ? 'text-heading hover:bg-hover' : 'text-text-2')}>
                  <span className={cn('grid size-7 shrink-0 place-items-center rounded-full border text-xs font-semibold', done ? 'border-success bg-success text-white dark:text-slate-900' : cur ? 'border-primary bg-primary text-white' : 'border-line-strong')}>{done ? <Check size={14} /> : n}</span>{t}
                </button>
              </li>
            )
          })}
        </ol>
        <p className="text-xs text-text-2">Your progress is saved automatically.</p>
      </aside>
      <div className="flex min-w-0 flex-col">
        <header ref={top} className="sticky top-0 z-30 border-b border-line bg-surface/90 px-4 py-3 backdrop-blur sm:px-8">
          <div className="flex items-center justify-between gap-3">
            <p className="text-sm font-semibold text-heading">Step {step} of 7 <span className="font-normal text-text-2">· {STEPS[step - 1]}</span></p>
            <div className="flex items-center gap-3"><span className="hidden text-[13px] text-text-2 sm:inline">Already have an account? <Link href="/login" className="font-medium text-primary hover:underline">Sign in</Link></span><ThemeToggle /></div>
          </div>
          <div className="mt-3"><Progress value={(step / 7) * 100} /></div>
        </header>
        <main className="flex-1 px-4 py-8 sm:px-8">
          <div key={step} className="anim-fade mx-auto max-w-3xl">
            <p className="text-xs font-semibold uppercase tracking-wider text-primary">Step 0{step}</p>
            <h1 className="mt-1 text-[28px] font-bold text-heading sm:text-[32px]">{STEPS[step - 1]}</h1>
            <p className="mb-7 mt-1.5 text-sm text-text-2">{DESC[step - 1]}</p>
            {step === 1 && <StepBusiness {...props} />}
            {step === 2 && <StepChannels {...props} />}
            {step === 3 && <StepWarehouse {...props} />}
            {step === 4 && <StepInventory {...props} />}
            {step === 5 && <StepLogistics {...props} />}
            {step === 6 && <StepPlan {...props} />}
            {step === 7 && <StepReview s={s} onEdit={go} />}
          </div>
        </main>
        <footer className="sticky bottom-0 border-t border-line bg-surface/90 px-4 py-3 backdrop-blur sm:px-8">
          <div className="mx-auto flex max-w-3xl items-center justify-between">
            <Button icon={ArrowLeft} disabled={step === 1 || completing} onClick={() => go(step - 1)}>Back</Button>
            {step < 7 ? <Button variant="primary" onClick={next}>Continue<ArrowRight size={16} /></Button>
              : <Button variant="primary" size="lg" loading={completing} onClick={complete}>{!completing && <CheckCircle2 size={16} />}COMPLETE SETUP</Button>}
          </div>
        </footer>
      </div>
    </div>
  )
}
