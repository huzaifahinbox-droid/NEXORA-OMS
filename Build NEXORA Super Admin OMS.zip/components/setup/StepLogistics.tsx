'use client'
import { useState } from 'react'
import { Pencil, Plus, Trash2, Truck } from 'lucide-react'
import { Button, Card, ConfirmDialog, EmptyState, IconButton, Input, Modal, Toggle, toast } from '@/components/ui/core'
import { setupStore, type Partner, type SetupState } from '@/lib/session'

const CARRIERS = ['Delhivery', 'Blue Dart', 'DTDC', 'Ecom Express', 'XpressBees', 'Shiprocket', 'FedEx', 'DHL']
const blank = (): Partner => ({ id: '', name: '', service: 'Standard', zones: 'Metro, Tier 1' })

export function StepLogistics({ s, errors }: { s: SetupState; errors: Record<string, string> }) {
  const [edit, setEdit] = useState<Partner | null>(null)
  const [del, setDel] = useState<Partner | null>(null)
  const [fe, setFe] = useState<Record<string, string>>({})
  const L = s.logistics
  const setL = (p: Partial<SetupState['logistics']>) => setupStore.set((x) => ({ ...x, logistics: { ...x.logistics, ...p } }))
  const save = () => {
    if (!edit) return
    const n: Record<string, string> = {}
    if (!edit.name.trim()) n.name = 'Carrier name is required.'
    if (!edit.service.trim()) n.service = 'Service level is required.'
    setFe(n); if (Object.keys(n).length) return
    setL({ partners: edit.id ? L.partners.map((p) => (p.id === edit.id ? edit : p)) : [...L.partners, { ...edit, id: `lp-${Date.now()}` }] })
    toast(edit.id ? 'Partner updated.' : 'Partner added.'); setEdit(null)
  }
  const open = (p: Partner) => { setFe({}); setEdit(p) }
  const quick = CARRIERS.filter((c) => !L.partners.some((p) => p.name === c))
  return (
    <div className="space-y-5">
      {errors.partners && <p role="alert" className="rounded-lg bg-danger-bg px-3 py-2 text-sm text-danger">{errors.partners}</p>}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-2" aria-label="Quick add carriers">{quick.slice(0, 5).map((c) => <button key={c} type="button" onClick={() => open({ ...blank(), name: c })} className="rounded-full border border-line-strong px-3 py-1 text-xs font-medium text-text hover:bg-hover">+ {c}</button>)}</div>
        <Button variant="primary" icon={Plus} onClick={() => open(blank())}>Add Partner</Button>
      </div>
      {L.partners.length === 0 ? (
        <Card><EmptyState icon={Truck} title="No logistics partners yet" body="Add the carriers you ship with to route and track deliveries." cta="Add Partner" onCta={() => open(blank())} /></Card>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {L.partners.map((p) => (
            <Card key={p.id} hover className="p-4">
              <div className="flex items-start justify-between gap-2">
                <div className="flex min-w-0 items-center gap-3"><span className="grid size-9 shrink-0 place-items-center rounded-lg bg-primary-light text-primary"><Truck size={16} /></span><div className="min-w-0"><h3 className="truncate text-sm font-semibold text-heading">{p.name}</h3><p className="text-xs text-text-2">{p.service}</p></div></div>
                <div className="flex shrink-0"><IconButton label={`Edit ${p.name}`} icon={Pencil} className="size-8" onClick={() => open(p)} /><IconButton label={`Delete ${p.name}`} icon={Trash2} className="size-8 hover:text-danger" onClick={() => setDel(p)} /></div>
              </div>
              <p className="mt-3 text-[13px] text-text-2">Zones: {p.zones || 'All'}</p>
            </Card>
          ))}
        </div>
      )}
      <div className="grid gap-4 sm:grid-cols-2">
        <Input label="Delivery zones" value={L.zones} onChange={(e) => setL({ zones: e.target.value })} />
        <Input label="Shipping methods" value={L.methods} onChange={(e) => setL({ methods: e.target.value })} />
        <Input label="Pickup address / location" value={L.pickup} onChange={(e) => setL({ pickup: e.target.value })} />
        <Input label="Delivery SLA (days)" inputMode="numeric" value={L.sla} onChange={(e) => setL({ sla: e.target.value })} />
      </div>
      <Card className="flex items-center justify-between gap-4 px-5 py-3"><div><p className="text-sm font-medium text-heading">Send tracking updates to customers</p><p className="text-[13px] text-text-2">Email and SMS notifications on every shipment event.</p></div><Toggle label="Tracking updates" checked={L.tracking} onChange={(v) => setL({ tracking: v })} /></Card>
      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? 'Edit partner' : 'Add logistics partner'} footer={<><Button onClick={() => setEdit(null)}>Cancel</Button><Button variant="primary" onClick={save}>{edit?.id ? 'Save Changes' : 'Add Partner'}</Button></>}>
        {edit && <div className="space-y-4">
          <Input label="Carrier name" required list="carriers" value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} error={fe.name} />
          <datalist id="carriers">{CARRIERS.map((c) => <option key={c} value={c} />)}</datalist>
          <Input label="Service level" required value={edit.service} onChange={(e) => setEdit({ ...edit, service: e.target.value })} error={fe.service} placeholder="Standard, Express" />
          <Input label="Zones covered" value={edit.zones} onChange={(e) => setEdit({ ...edit, zones: e.target.value })} />
        </div>}
      </Modal>
      <ConfirmDialog open={!!del} danger title="Remove partner?" body={`${del?.name} will be removed from your logistics setup.`} confirmLabel="Remove" onConfirm={() => { setL({ partners: L.partners.filter((p) => p.id !== del!.id) }); toast('Partner removed.', 'info') }} onClose={() => setDel(null)} />
    </div>
  )
}
