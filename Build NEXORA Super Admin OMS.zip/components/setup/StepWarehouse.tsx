'use client'
import { useState } from 'react'
import { MapPin, Pencil, Plus, Trash2, Warehouse } from 'lucide-react'
import { Button, Card, ConfirmDialog, EmptyState, IconButton, Input, Modal, toast } from '@/components/ui/core'
import { setupStore, type SetupState, type SetupWarehouse } from '@/lib/session'

const blank = (): SetupWarehouse => ({ id: '', name: '', code: '', address: '', city: '', state: '', country: 'India', contact: '', capacity: '', hours: '09:00 - 18:00' })

export function StepWarehouse({ s, errors }: { s: SetupState; errors: Record<string, string> }) {
  const [edit, setEdit] = useState<SetupWarehouse | null>(null)
  const [del, setDel] = useState<SetupWarehouse | null>(null)
  const [fe, setFe] = useState<Record<string, string>>({})
  const set = (k: keyof SetupWarehouse, v: string) => edit && setEdit({ ...edit, [k]: v })
  const save = () => {
    if (!edit) return
    const n: Record<string, string> = {}
    if (!edit.name.trim()) n.name = 'Name is required.'
    if (!edit.code.trim()) n.code = 'Code is required.'
    else if (s.warehouses.some((w) => w.id !== edit.id && w.code.toLowerCase() === edit.code.trim().toLowerCase())) n.code = 'Code already in use.'
    if (!edit.address.trim()) n.address = 'Address is required.'
    if (!edit.city.trim()) n.city = 'City is required.'
    if (edit.capacity && (isNaN(Number(edit.capacity)) || Number(edit.capacity) < 0)) n.capacity = 'Enter a valid number.'
    setFe(n); if (Object.keys(n).length) return
    const w = { ...edit, code: edit.code.trim().toUpperCase() }
    setupStore.set((x) => ({ ...x, warehouses: w.id ? x.warehouses.map((y) => (y.id === w.id ? w : y)) : [...x.warehouses, { ...w, id: `wh-${Date.now()}` }] }))
    toast(edit.id ? 'Warehouse updated.' : 'Warehouse added.'); setEdit(null)
  }
  const open = (w: SetupWarehouse) => { setFe({}); setEdit(w) }
  return (
    <div className="space-y-4">
      {errors.warehouses && <p role="alert" className="rounded-lg bg-danger-bg px-3 py-2 text-sm text-danger">{errors.warehouses}</p>}
      <div className="flex justify-end"><Button variant="primary" icon={Plus} onClick={() => open(blank())}>Add Warehouse</Button></div>
      {s.warehouses.length === 0 ? (
        <Card><EmptyState icon={Warehouse} title="No warehouses yet" body="Add the locations where you store and ship inventory from." cta="Add Warehouse" onCta={() => open(blank())} /></Card>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {s.warehouses.map((w) => (
            <Card key={w.id} hover className="p-4">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0"><h3 className="truncate text-sm font-semibold text-heading">{w.name}</h3><p className="text-xs text-text-2">{w.code}</p></div>
                <div className="flex shrink-0"><IconButton label={`Edit ${w.name}`} icon={Pencil} className="size-8" onClick={() => open(w)} /><IconButton label={`Delete ${w.name}`} icon={Trash2} className="size-8 hover:text-danger" onClick={() => setDel(w)} /></div>
              </div>
              <p className="mt-3 flex items-start gap-1.5 text-[13px] text-text-2"><MapPin size={14} className="mt-0.5 shrink-0" />{[w.address, w.city, w.state, w.country].filter(Boolean).join(', ')}</p>
              <p className="mt-2 text-xs text-text-2">{w.capacity ? `Capacity ${Number(w.capacity).toLocaleString()} units · ` : ''}{w.hours}</p>
            </Card>
          ))}
        </div>
      )}
      <Modal open={!!edit} onClose={() => setEdit(null)} wide title={edit?.id ? 'Edit warehouse' : 'Add warehouse'} footer={<><Button onClick={() => setEdit(null)}>Cancel</Button><Button variant="primary" onClick={save}>{edit?.id ? 'Save Changes' : 'Add Warehouse'}</Button></>}>
        {edit && (
          <div className="grid gap-4 sm:grid-cols-2">
            <Input label="Warehouse name" required value={edit.name} onChange={(e) => set('name', e.target.value)} error={fe.name} />
            <Input label="Code" required value={edit.code} onChange={(e) => set('code', e.target.value)} error={fe.code} placeholder="BLR-01" />
            <div className="sm:col-span-2"><Input label="Address" required value={edit.address} onChange={(e) => set('address', e.target.value)} error={fe.address} /></div>
            <Input label="City" required value={edit.city} onChange={(e) => set('city', e.target.value)} error={fe.city} />
            <Input label="State" value={edit.state} onChange={(e) => set('state', e.target.value)} />
            <Input label="Country" value={edit.country} onChange={(e) => set('country', e.target.value)} />
            <Input label="Contact person / phone" value={edit.contact} onChange={(e) => set('contact', e.target.value)} />
            <Input label="Capacity (units)" inputMode="numeric" value={edit.capacity} onChange={(e) => set('capacity', e.target.value)} error={fe.capacity} />
            <Input label="Operating hours" value={edit.hours} onChange={(e) => set('hours', e.target.value)} />
          </div>
        )}
      </Modal>
      <ConfirmDialog open={!!del} danger title="Delete warehouse?" body={`${del?.name} will be removed from your setup.`} confirmLabel="Delete" onConfirm={() => { setupStore.set((x) => ({ ...x, warehouses: x.warehouses.filter((y) => y.id !== del!.id) })); toast('Warehouse deleted.', 'info') }} onClose={() => setDel(null)} />
    </div>
  )
}
