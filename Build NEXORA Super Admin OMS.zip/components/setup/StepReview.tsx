'use client'
import { Pencil } from 'lucide-react'
import type { ReactNode } from 'react'
import { Button, Card } from '@/components/ui/core'
import { PLANS, type SetupState } from '@/lib/session'
import { connected, STEPS, validate } from './validate'
import { priceOf } from './StepPlan'

export function SetupSummary({ s, onEdit }: { s: SetupState; onEdit?: (step: number) => void }) {
  const b = s.biz, i = s.inventory
  const plan = PLANS.find((p) => p.id === s.plan.id) ?? PLANS[1]
  const sections: { step: number; body: ReactNode }[] = [
    { step: 1, body: <Rows r={[['Business', b.name], ['Type', b.type], ['Industry', b.industry], ['GST / Tax ID', b.tax], ['Contact', `${b.email} · ${b.phone}`], ['Address', [b.address, b.city, b.state, b.zip, b.country].filter(Boolean).join(', ')], ['Currency / Timezone', `${b.currency} · ${b.timezone}`]]} /> },
    { step: 2, body: <Rows r={[['Connected channels', connected(s).join(', ') || 'None']]} /> },
    { step: 3, body: <Rows r={s.warehouses.length ? s.warehouses.map((w) => [w.code, `${w.name} — ${w.city}`] as [string, string]) : [['Warehouses', 'None']]} /> },
    { step: 4, body: <Rows r={[['Tracking', i.tracking], ['Units', i.units], ['Low stock / Safety / Reorder', `${i.lowStock} / ${i.safety} / ${i.reorder}`], ['Reorder policy', i.reorderPolicy], ['Backorders', i.backorders ? 'Allowed' : 'Not allowed'], ['Negative inventory', i.allowNegative ? 'Allowed' : 'Not allowed']]} /> },
    { step: 5, body: <Rows r={[['Partners', s.logistics.partners.map((p) => p.name).join(', ') || 'None'], ['SLA', `${s.logistics.sla} days`], ['Customer tracking', s.logistics.tracking ? 'On' : 'Off']]} /> },
    { step: 6, body: <Rows r={[['Plan', plan.name], ['Billing', s.plan.cycle], ['Price', plan.monthly ? `${priceOf(plan, s.plan.cycle)} / month` : 'Custom pricing']]} /> },
  ]
  return (
    <div className="space-y-3">
      {sections.map(({ step, body }) => {
        const bad = Object.keys(validate(step, s)).length > 0
        return (
          <Card key={step} className="p-5">
            <div className="mb-3 flex items-center justify-between gap-2">
              <h3 className="text-[15px] font-semibold text-heading"><span className="mr-2 text-xs text-muted">0{step}</span>{STEPS[step - 1]}{bad && <span className="ml-2 text-xs font-medium text-danger">Incomplete</span>}</h3>
              {onEdit && <Button size="sm" icon={Pencil} onClick={() => onEdit(step)}>Edit</Button>}
            </div>
            {body}
          </Card>
        )
      })}
    </div>
  )
}
function Rows({ r }: { r: [string, string][] }) {
  return <dl className="grid gap-x-6 gap-y-2 text-[13px] sm:grid-cols-[170px_1fr]">{r.map(([k, v], n) => <div key={k + n} className="contents"><dt className="text-text-2">{k}</dt><dd className="break-words font-medium text-heading">{v || '—'}</dd></div>)}</dl>
}
export const StepReview = SetupSummary
