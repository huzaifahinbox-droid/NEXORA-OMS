'use client'
import { Check } from 'lucide-react'
import { Badge, Tabs, cn } from '@/components/ui/core'
import { PLANS, setupStore, type SetupState } from '@/lib/session'

export const priceOf = (p: (typeof PLANS)[number], cycle: 'Monthly' | 'Yearly') => (p.monthly === 0 ? 'Custom' : `$${cycle === 'Yearly' ? p.yearly : p.monthly}`)

export function StepPlan({ s }: { s: SetupState; errors?: Record<string, string> }) {
  const { id, cycle } = s.plan
  const set = (p: Partial<SetupState['plan']>) => setupStore.set((x) => ({ ...x, plan: { ...x.plan, ...p } }))
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <Tabs value={cycle} onChange={(v) => set({ cycle: v })} options={['Monthly', 'Yearly'] as const} />
        <Badge tone="success">Save ~20% yearly</Badge>
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        {PLANS.map((p) => {
          const sel = id === p.id
          return (
            <button key={p.id} type="button" aria-pressed={sel} onClick={() => set({ id: p.id })} className={cn('relative rounded-xl border bg-surface p-5 text-left transition-all', sel ? 'border-primary ring-2 ring-primary/30' : 'border-line hover:border-line-strong')}>
              {p.id === 'growth' && <span className="absolute right-4 top-4"><Badge tone="primary">Popular</Badge></span>}
              <h3 className="text-base font-semibold text-heading">{p.name}</h3>
              <p className="mt-2"><span className="text-3xl font-bold text-heading">{priceOf(p, cycle)}</span>{p.monthly > 0 && <span className="text-sm text-text-2"> / month</span>}</p>
              <ul className="mt-4 space-y-1.5 text-[13px] text-text">
                {[`${p.orders} orders`, `${p.users} users`, `${p.warehouses} warehouses`, `${p.ai} AI`, `${p.integrations} integrations`, `${p.support} support`].map((f) => <li key={f} className="flex items-center gap-2"><Check size={14} className="shrink-0 text-success" />{f}</li>)}
              </ul>
              <span className={cn('mt-4 inline-flex h-8 items-center rounded-lg px-3 text-[13px] font-medium', sel ? 'bg-primary text-white' : 'border border-line-strong text-heading')}>{sel ? 'Selected' : p.monthly === 0 ? 'Choose Enterprise' : 'Select plan'}</span>
            </button>
          )
        })}
      </div>
    </div>
  )
}
