'use client'
import { Input, Select } from '@/components/ui/core'
import { setupStore, type SetupState } from '@/lib/session'

export const TYPES = ['Private Limited', 'Public Limited', 'Partnership', 'Sole Proprietorship', 'LLP']
export const INDUSTRIES = ['Fashion & Apparel', 'Electronics', 'Beauty & Personal Care', 'Home & Living', 'Food & Beverage', 'Health & Wellness', 'Automotive', 'Other']
export const COUNTRIES = ['India', 'United States', 'United Kingdom', 'United Arab Emirates', 'Singapore', 'Australia', 'Germany']
export const CURRENCIES = ['INR', 'USD', 'GBP', 'AED', 'SGD', 'AUD', 'EUR']
export const TIMEZONES = ['Asia/Kolkata', 'Asia/Dubai', 'Asia/Singapore', 'Europe/London', 'Europe/Berlin', 'America/New_York', 'Australia/Sydney']

export function StepBusiness({ s, errors }: { s: SetupState; errors: Record<string, string> }) {
  const set = (k: keyof SetupState['biz'], v: string) => setupStore.set((x) => ({ ...x, biz: { ...x.biz, [k]: v } }))
  const b = s.biz
  const inp = (k: keyof SetupState['biz'], label: string, extra: Record<string, unknown> = {}) => <Input label={label} required={k !== 'state' && k !== 'zip'} value={b[k]} onChange={(e) => set(k, e.target.value)} error={errors[k]} {...extra} />
  return (
    <div className="space-y-5">
      <div className="grid gap-4 sm:grid-cols-2">
        {inp('name', 'Business name', { placeholder: 'DTC Operations Pvt. Ltd.', autoComplete: 'organization' })}
        <Select label="Business type" required options={TYPES} value={b.type} onChange={(e) => set('type', e.target.value)} error={errors.type} />
        <Select label="Industry" required options={INDUSTRIES} value={b.industry} onChange={(e) => set('industry', e.target.value)} error={errors.industry} />
        {inp('tax', 'GST / Tax ID', { placeholder: '27AAPFU0939F1ZV' })}
        {inp('email', 'Business email', { type: 'email', placeholder: 'ops@company.com' })}
        {inp('phone', 'Phone', { type: 'tel', placeholder: '+91 98765 43210' })}
      </div>
      {inp('address', 'Address', { placeholder: 'Street, building, area' })}
      <div className="grid gap-4 sm:grid-cols-3">
        {inp('city', 'City')}{inp('state', 'State / Region')}{inp('zip', 'Postal code')}
      </div>
      <div className="grid gap-4 sm:grid-cols-3">
        <Select label="Country" required options={COUNTRIES} value={b.country} onChange={(e) => set('country', e.target.value)} error={errors.country} />
        <Select label="Currency" required options={CURRENCIES} value={b.currency} onChange={(e) => set('currency', e.target.value)} error={errors.currency} />
        <Select label="Timezone" required options={TIMEZONES} value={b.timezone} onChange={(e) => set('timezone', e.target.value)} error={errors.timezone} />
      </div>
    </div>
  )
}
