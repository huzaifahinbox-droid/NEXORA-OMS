'use client'
import { Card, Input, Select, Toggle } from '@/components/ui/core'
import { setupStore, type SetupState } from '@/lib/session'

export function StepInventory({ s, errors }: { s: SetupState; errors: Record<string, string> }) {
  const i = s.inventory
  const set = <K extends keyof SetupState['inventory']>(k: K, v: SetupState['inventory'][K]) => setupStore.set((x) => ({ ...x, inventory: { ...x.inventory, [k]: v, saved: true } }))
  const tog = (k: 'backorders' | 'allowNegative' | 'autoReorder' | 'batch' | 'serial' | 'expiry', label: string, desc: string) => (
    <div className="flex items-center justify-between gap-4 py-3"><div><p className="text-sm font-medium text-heading">{label}</p><p className="text-[13px] text-text-2">{desc}</p></div><Toggle label={label} checked={i[k]} onChange={(v) => set(k, v)} /></div>
  )
  return (
    <div className="space-y-5">
      <div className="grid gap-4 sm:grid-cols-2">
        <Select label="Tracking method" required options={['SKU', 'Batch / Lot', 'Serial number', 'Batch + Expiry']} value={i.tracking} onChange={(e) => set('tracking', e.target.value)} error={errors.tracking} />
        <Select label="Unit of measure" required options={['Pieces', 'Boxes', 'Kilograms', 'Litres', 'Pairs']} value={i.units} onChange={(e) => set('units', e.target.value)} error={errors.units} />
        <Input label="Low stock threshold" required inputMode="numeric" value={i.lowStock} onChange={(e) => set('lowStock', e.target.value)} error={errors.lowStock} hint="Alert when available units fall below this." />
        <Input label="Safety stock" required inputMode="numeric" value={i.safety} onChange={(e) => set('safety', e.target.value)} error={errors.safety} hint="Buffer kept to absorb demand spikes." />
        <Select label="Reorder policy" options={['Min / Max', 'Fixed quantity', 'Demand forecast (AI)', 'Manual']} value={i.reorderPolicy} onChange={(e) => set('reorderPolicy', e.target.value)} />
        <Input label="Default reorder quantity" required inputMode="numeric" value={i.reorder} onChange={(e) => set('reorder', e.target.value)} error={errors.reorder} />
      </div>
      <Input label="SKU structure" value={i.skuStructure} onChange={(e) => set('skuStructure', e.target.value)} />
      <Card className="divide-y divide-line px-5">
        {tog('backorders', 'Allow backorders', 'Keep accepting orders when stock reaches zero.')}
        {tog('allowNegative', 'Allow negative inventory', 'Let stock go below zero until it is received.')}
        {tog('autoReorder', 'Auto-create purchase suggestions', 'Draft reorders when stock hits the threshold.')}
        {tog('batch', 'Batch tracking', 'Track inventory by batch / lot number.')}
        {tog('serial', 'Serial number tracking', 'Track each unit by serial number.')}
        {tog('expiry', 'Expiry dates', 'Track expiry and enforce FEFO picking.')}
      </Card>
    </div>
  )
}
