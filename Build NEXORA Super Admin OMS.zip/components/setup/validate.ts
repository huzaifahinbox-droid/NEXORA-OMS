import type { SetupState } from '@/lib/session'
import { isEmail } from '@/components/auth/AuthShell'

export const STEPS = ['Business Information', 'Sales Channels', 'Warehouse', 'Inventory', 'Logistics', 'Subscription', 'Review'] as const
export const connected = (s: SetupState) => Object.entries(s.channels).filter(([, v]) => v === 'Connected' || v === 'Verified').map(([k]) => k)
const num = (v: string) => v.trim() !== '' && !isNaN(Number(v)) && Number(v) >= 0

export function validate(step: number, s: SetupState): Record<string, string> {
  const e: Record<string, string> = {}
  const req = (k: string, v: string, label: string) => { if (!v?.trim()) e[k] = `${label} is required.` }
  if (step === 1) {
    const b = s.biz
    req('name', b.name, 'Business name'); req('type', b.type, 'Business type'); req('industry', b.industry, 'Industry'); req('tax', b.tax, 'GST / Tax ID')
    req('email', b.email, 'Business email'); if (b.email && !isEmail(b.email)) e.email = 'Enter a valid email address.'
    req('phone', b.phone, 'Phone'); if (b.phone && !/^[+\d][\d\s-]{6,}$/.test(b.phone.trim())) e.phone = 'Enter a valid phone number.'
    req('address', b.address, 'Address'); req('city', b.city, 'City'); req('country', b.country, 'Country'); req('currency', b.currency, 'Currency'); req('timezone', b.timezone, 'Timezone')
  }
  if (step === 2 && connected(s).length === 0) e.channels = 'Connect at least one sales channel to continue.'
  if (step === 3 && s.warehouses.length === 0) e.warehouses = 'Add at least one warehouse to continue.'
  if (step === 4) {
    const i = s.inventory
    if (!num(i.lowStock)) e.lowStock = 'Enter a valid number.'
    if (!num(i.safety)) e.safety = 'Enter a valid number.'
    if (!num(i.reorder)) e.reorder = 'Enter a valid number.'
    req('tracking', i.tracking, 'Tracking method'); req('units', i.units, 'Unit of measure')
  }
  if (step === 5 && s.logistics.partners.length === 0) e.partners = 'Add at least one logistics partner to continue.'
  return e
}
export const firstInvalid = (s: SetupState) => [1, 2, 3, 4, 5, 6].find((n) => Object.keys(validate(n, s)).length > 0)
