'use client'
import { useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import { AlertTriangle, Download, RefreshCw } from 'lucide-react'
import { Badge, Button, Card, CardHeader, cn, Tabs, toast, type Tone } from '@/components/ui/core'
import { Page, KpiRow, Panel, Stages, Split } from '@/components/blocks'
import { Chart } from '@/components/charts/charts'
import { useDB, db, compact, inventoryStatus } from '@/lib/db'
import { PERIOD_DAYS, PERIOD_MULT, PERIOD_PREV, series, spark } from '@/lib/metrics'
import { PIPELINE } from '@/types'

const PERIODS = ['Today', '7 Days', '30 Days', '90 Days', 'Custom'] as const
const TABS = ['Orders', 'Revenue', 'Deliveries'] as const
const RANGES = ['7D', '30D', '90D'] as const
const AVG: Record<string, string> = { New: '12m', Confirmed: '35m', Allocated: '1.2h', Picking: '2.4h', Packed: '1.1h', Shipped: '1.8d', Delivered: '—' }

interface Attn { id: string; kind: string; title: string; body: string; tone: Tone; href: string; act: string; run: () => void }

export function Dashboard() {
  const d = useDB()
  const router = useRouter()
  const [period, setPeriod] = useState<(typeof PERIODS)[number]>('30 Days')
  const [tab, setTab] = useState<(typeof TABS)[number]>('Orders')
  const [range, setRange] = useState<(typeof RANGES)[number]>('30D')
  const [spin, setSpin] = useState(0)
  const [tick, setTick] = useState(0)
  const mult = PERIOD_MULT[period]
  const prev = PERIOD_PREV[period]

  const total = Math.round(d.orders.length * (mult / 8))
  const count = (s: string[]) => d.orders.filter((o) => s.includes(o.status)).length
  const delivered = count(['Delivered']), done = delivered + count(['Shipped'])
  const delayed = d.shipments.filter((s) => s.status === 'Delayed' || s.status === 'Failed').length
  const revenue = d.orders.filter((o) => o.status !== 'Cancelled').reduce((a, o) => a + o.total, 0) * (mult / 8)
  const invValue = d.inventory.reduce((a, r) => a + (r.available + r.reserved) * (d.products.find((p) => p.sku === r.sku)?.price ?? 0) * 0.5, 0)
  const fulfil = Math.min(99, 80 + (done / Math.max(1, d.orders.length)) * 40)
  const data = useMemo(() => {
    const k = tab === 'Orders' ? 'orders' : tab === 'Revenue' ? 'revenue' : 'deliveries'
    return series(k, range === '7D' ? 7 : range === '30D' ? 30 : 90).map((p) => ({ name: p.name, Current: p.value, Previous: p.prev }))
  }, [tab, range, tick])

  const stages = PIPELINE.map((s) => { const c = d.orders.filter((o) => o.status === s).length; return { label: s, count: c, pct: Math.round((c / d.orders.length) * 100), sub: AVG[s], href: `/order-management/all-orders` } })

  const att: Attn[] = [
    ...d.inventory.filter((r) => inventoryStatus(r) === 'Out of Stock').slice(0, 2).map((r): Attn => ({ id: `att-stock-${r.id}`, kind: 'Stockout Risk', title: `${r.sku} is out of stock at ${r.warehouse}`, body: `${d.orders.filter((o) => o.sku === r.sku && ['New', 'Confirmed'].includes(o.status)).length} open orders depend on this SKU.`, tone: 'danger', href: '/inventory-management/out-of-stock', act: 'Request transfer', run: () => { db.add('transfers', { id: `TRF-${400 + d.transfers.length}`, from: 'WH-BLR-02', to: r.warehouse, sku: r.sku, qty: 80, status: 'Requested' }); toast('Transfer requested') } })),
    ...d.tickets.filter((t) => t.breached && t.status !== 'Resolved').slice(0, 1).map((t): Attn => ({ id: `att-sla-${t.id}`, kind: 'SLA Breach', title: `${t.id} breached its response SLA`, body: `${t.customer} · ${t.issue}`, tone: 'danger', href: '/customer-support/sla-breaches', act: 'Escalate', run: () => { db.patch('tickets', t.id, { status: 'Escalated' }); toast(`${t.id} escalated`) } })),
    ...d.pos.filter((p) => p.status === 'Delayed').slice(0, 1).map((p): Attn => ({ id: `att-po-${p.id}`, kind: 'Procurement Delay', title: `${p.id} is running late`, body: `Vendor ${d.vendors.find((v) => v.id === p.vendorId)?.name} · ETA ${p.eta}`, tone: 'warning', href: '/order-procurement/purchase-orders', act: 'Nudge vendor', run: () => { db.notify('Procurement', `Reminder sent for ${p.id}`, 'Vendor has been asked for a revised ETA.', '/order-procurement/purchase-orders'); toast('Vendor reminded') } })),
    ...d.warehouses.filter((w) => w.occupancy >= 85).slice(0, 1).map((w): Attn => ({ id: `att-wh-${w.id}`, kind: 'Warehouse Bottleneck', title: `${w.name} is at ${w.occupancy}% capacity`, body: `${w.picking} orders waiting in picking.`, tone: 'warning', href: '/warehouse-management/warehouse-performance', act: 'Rebalance', run: () => { db.patch('warehouses', w.id, { occupancy: w.occupancy - 8 }); toast('Rebalancing started') } })),
    ...d.shipments.filter((s) => s.status === 'Failed' || s.status === 'Delayed').slice(0, 2).map((s): Attn => ({ id: `att-ship-${s.id}`, kind: 'Carrier Exception', title: `${s.id} ${s.status.toLowerCase()} with ${s.carrier}`, body: s.issue ?? s.lastScan, tone: 'warning', href: '/delivery-not-happening/carrier-exceptions', act: 'Reattempt', run: () => { db.patch('shipments', s.id, { status: 'In Transit', issue: undefined }); db.log(`Reattempt ${s.id}`, 'Delivery', s.status, 'In Transit'); toast(`${s.id} reattempt scheduled`) } })),
    ...d.txns.filter((t) => t.status === 'Failed').slice(0, 1).map((t): Attn => ({ id: `att-pay-${t.id}`, kind: 'Payment Issue', title: `${t.id} payment failed`, body: `${t.orderId} · ${t.method}`, tone: 'danger', href: '/account-billing/payments', act: 'Retry', run: () => { db.patch('txns', t.id, { status: 'Settled' }); toast('Payment retried successfully') } })),
  ].filter((a) => !d.dismissedAttention.includes(a.id))

  const health = [
    { l: 'Order', v: fulfil > 92 ? 'Healthy' : 'Attention', n: `${fulfil.toFixed(1)}% fulfilled`, h: '/order-management/overview' },
    { l: 'Inventory', v: d.inventory.some((r) => inventoryStatus(r) === 'Out of Stock') ? 'Critical' : 'Healthy', n: `${d.inventory.filter((r) => inventoryStatus(r) !== 'In Stock').length} at risk`, h: '/inventory-management/overview' },
    { l: 'Warehouse', v: d.warehouses.some((w) => w.occupancy >= 90) ? 'Critical' : d.warehouses.some((w) => w.occupancy >= 85) ? 'Attention' : 'Healthy', n: `${Math.max(...d.warehouses.map((w) => w.occupancy))}% peak load`, h: '/warehouse-management/overview' },
    { l: 'Delivery', v: delayed > 4 ? 'Critical' : delayed > 0 ? 'Attention' : 'Healthy', n: `${delayed} delayed`, h: '/delivery-not-happening/overview' },
    { l: 'Supply', v: d.pos.some((p) => p.status === 'Delayed') ? 'Attention' : 'Healthy', n: `${d.pos.filter((p) => p.status === 'Delayed').length} POs late`, h: '/supply-chain-management/overview' },
  ]
  const hTone = (v: string): Tone => (v === 'Healthy' ? 'success' : v === 'Attention' ? 'warning' : 'danger')

  return (
    <Page title="Command Center" desc="Real-time visibility across your entire operation." actions={<>
      <Tabs value={period} onChange={setPeriod} options={PERIODS} />
      <Button icon={RefreshCw} onClick={() => { setSpin((s) => s + 1); setTick((t) => t + 1); toast('Dashboard refreshed', 'info') }} aria-label="Refresh"><span className="sr-only sm:not-sr-only">Refresh</span></Button>
      <Button icon={Download} onClick={() => { const csv = ['Metric,Value', `Total Orders,${total}`, `Net Revenue,${Math.round(revenue)}`, `Fulfillment,${fulfil.toFixed(1)}`].join('\n'); const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); a.download = `nexora-${period.replace(' ', '-')}.csv`; a.click(); toast('Report exported') }}>Export</Button>
    </>}>
      <span key={spin} className="hidden" />
      <KpiRow cols={6} key={`${period}-${tick}`} items={[
        { label: 'Total Orders', value: total, trend: 8.2, prev: prev, spark: spark(1), status: 'Healthy' },
        { label: 'Processing', value: count(['Confirmed', 'Allocated', 'Picking', 'Packed']), trend: 3.1, prev, spark: spark(2), status: 'Healthy' },
        { label: 'Fulfillment Rate', value: fulfil, format: (n) => `${n.toFixed(1)}%`, trend: 8.4, prev, spark: spark(3), status: fulfil > 92 ? 'Healthy' : 'Attention' },
        { label: 'Delayed', value: delayed, trend: 14.0, invert: true, prev, spark: spark(4, false), status: delayed > 4 ? 'Critical' : 'Attention' },
        { label: 'Net Revenue', value: revenue, format: compact, trend: 11.6, prev, spark: spark(5), status: 'Healthy' },
        { label: 'Inventory Value', value: invValue, format: compact, trend: -2.3, prev, spark: spark(6, false), status: 'Attention' },
      ]} />
      <Panel title="Performance" sub="Current period vs previous" action={<div className="flex flex-wrap gap-2"><Tabs value={tab} onChange={setTab} options={TABS} /><Tabs value={range} onChange={setRange} options={RANGES} /></div>}>
        <Chart type={tab === 'Revenue' ? 'area' : 'line'} data={data} series={[{ key: 'Current', label: 'Current' }, { key: 'Previous', label: 'Previous', color: 'var(--purple)' }]} fmt={tab === 'Revenue' ? compact : undefined} height={300} />
      </Panel>
      <Panel title="Order pipeline" sub="Click a stage to open Order Management"><Stages stages={stages} onSelect={() => router.push('/order-management/all-orders')} /></Panel>
      <Split main={
        <Card><CardHeader title="Needs attention" sub={`${att.length} open items`} />
          <ul className="mt-2 divide-y divide-line">
            {att.length === 0 && <li className="p-8 text-center text-sm text-text-2">Nothing needs your attention. Nice work.</li>}
            {att.map((a) => (
              <li key={a.id} className="flex flex-wrap items-center gap-3 p-4 px-5 anim-fade">
                <span className={cn('grid size-9 shrink-0 place-items-center rounded-lg', a.tone === 'danger' ? 'bg-danger-bg text-danger' : 'bg-warning-bg text-warning')}><AlertTriangle size={18} /></span>
                <div className="min-w-48 flex-1"><div className="flex items-center gap-2"><Badge tone={a.tone}>{a.kind}</Badge></div><p className="mt-1 text-sm font-medium text-heading">{a.title}</p><p className="text-[13px] text-text-2">{a.body}</p></div>
                <div className="flex gap-2"><Button size="sm" onClick={() => router.push(a.href)}>Review</Button><Button size="sm" variant="primary" onClick={() => { a.run(); db.dismissAttention(a.id) }}>{a.act}</Button><Button size="sm" variant="ghost" onClick={() => { db.dismissAttention(a.id); toast('Dismissed', 'info') }}>Dismiss</Button></div>
              </li>
            ))}
          </ul></Card>
      } side={
        <Panel title="Operational health" sub="Live status by area">
          <ul className="space-y-2">{health.map((h) => (
            <li key={h.l}><button onClick={() => router.push(h.h)} className="flex w-full items-center justify-between rounded-lg border border-line bg-surface-2 px-4 py-3 text-left transition-colors hover:bg-hover"><div><p className="text-sm font-semibold text-heading">{h.l}</p><p className="text-xs text-text-2">{h.n}</p></div><Badge tone={hTone(h.v)} dot>{h.v}</Badge></button></li>
          ))}</ul>
        </Panel>
      } />
    </Page>
  )
}
