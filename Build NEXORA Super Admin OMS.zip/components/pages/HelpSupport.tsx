'use client'
import { useState } from 'react'
import { BookOpen, ChevronDown, LifeBuoy, MessageCircle, Sparkles } from 'lucide-react'
import { Button, Card, Input, Select, SearchBox, Textarea, toast, cn } from '@/components/ui/core'
import { Page, Panel } from '@/components/blocks'
import { ui } from '@/lib/ui'

const FAQ = [
  ['How do I connect a new sales channel?', 'Open Settings → Integrations and toggle the channel. Orders sync every 2 minutes once connected.'],
  ['How does NEXORA decide reorder quantities?', 'Forecasting combines trailing demand, vendor lead time and safety stock. See Inventory Forecasting → Reorder Recommendations.'],
  ['Can I undo a stock adjustment?', 'Adjustments are immutable, but you can submit a compensating adjustment. Both are written to Audit Logs.'],
  ['How do I invite teammates?', 'Go to User Management → User Directory and choose Invite user. Assign a role with the permission matrix.'],
  ['What happens when a shipment is delayed?', 'It appears in Delivery Not Happening and on the dashboard Needs Attention list, with one-click Reattempt or Escalate.'],
  ['How do I export data?', 'Most tables and the dashboard have an Export button that downloads a CSV.'],
]
const GUIDES = ['Getting started with NEXORA', 'Order lifecycle explained', 'Setting up warehouses', 'Understanding AI insights', 'Managing roles and permissions']

export function HelpSupport() {
  const [q, setQ] = useState('')
  const [open, setOpen] = useState<number | null>(0)
  const [f, setF] = useState({ subject: '', category: '', message: '' })
  const [err, setErr] = useState<Record<string, string>>({})
  const [sent, setSent] = useState<string | null>(null)
  const faq = FAQ.filter(([a, b]) => `${a} ${b}`.toLowerCase().includes(q.toLowerCase()))
  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    const er: Record<string, string> = {}
    if (!f.subject.trim()) er.subject = 'Add a subject'
    if (!f.category) er.category = 'Choose a category'
    if (f.message.trim().length < 10) er.message = 'Tell us a little more (10+ characters)'
    setErr(er)
    if (!Object.keys(er).length) { setSent(`HLP-${Math.floor(1000 + Math.random() * 9000)}`); setF({ subject: '', category: '', message: '' }); toast('Request submitted') }
  }
  return (
    <Page title="Help & Support" desc="Find answers, read guides or talk to the NEXORA team.">
      <div className="grid gap-4 md:grid-cols-3">
        {[[Sparkles, 'Ask NEXORA AI', 'Instant answers about your data', () => ui.set({ copilot: true })], [MessageCircle, 'Live chat', 'Average reply under 3 minutes', () => toast('Connecting you to an agent…', 'info')], [BookOpen, 'Documentation', 'Guides and API reference', () => toast('Opening documentation…', 'info')]].map(([Icon, t, s, fn]) => { const I = Icon as typeof Sparkles; return <button key={t as string} onClick={fn as () => void} className="rounded-xl border border-line bg-surface p-5 text-left shadow-card transition-all hover:-translate-y-0.5 hover:shadow-pop"><span className="grid size-10 place-items-center rounded-lg bg-primary-light text-primary"><I size={20} /></span><p className="mt-3 font-semibold text-heading">{t as string}</p><p className="text-[13px] text-text-2">{s as string}</p></button> })}
      </div>
      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_420px]">
        <Panel title="Frequently asked questions" action={<SearchBox value={q} onChange={setQ} placeholder="Search help…" />}>
          {faq.length === 0 ? <p className="py-6 text-center text-sm text-text-2">No answers match “{q}”.</p> : <ul className="divide-y divide-line">{faq.map(([a, b], i) => <li key={a}><button aria-expanded={open === i} onClick={() => setOpen(open === i ? null : i)} className="flex w-full items-center justify-between gap-3 py-3.5 text-left text-sm font-medium text-heading">{a}<ChevronDown size={16} className={cn('transition-transform', open === i && 'rotate-180')} /></button>{open === i && <p className="pb-4 text-[13px] text-text-2 anim-fade">{b}</p>}</li>)}</ul>}
          <h3 className="mb-2 mt-6 font-semibold text-heading">Guides</h3>
          <ul className="grid gap-2 sm:grid-cols-2">{GUIDES.map((g) => <li key={g}><button onClick={() => toast(`Opening “${g}”`, 'info')} className="w-full rounded-lg border border-line px-3 py-2.5 text-left text-[13px] text-text hover:bg-hover">{g}</button></li>)}</ul>
        </Panel>
        <Card className="p-6">{sent ? <div className="py-8 text-center anim-pop"><LifeBuoy className="mx-auto text-success" size={36} /><p className="mt-3 font-semibold text-heading">Request {sent} received</p><p className="text-sm text-text-2">We’ll reply to your email within 4 business hours.</p><Button className="mt-4" onClick={() => setSent(null)}>Submit another</Button></div> :
          <form onSubmit={submit} className="space-y-4" noValidate><h3 className="font-semibold text-heading">Contact support</h3><Input label="Subject" value={f.subject} error={err.subject} onChange={(e) => setF({ ...f, subject: e.target.value })} /><Select label="Category" value={f.category} error={err.category} onChange={(e) => setF({ ...f, category: e.target.value })} options={['Orders', 'Inventory', 'Billing', 'Integrations', 'Other']} /><div><Textarea label="Message" value={f.message} onChange={(e) => setF({ ...f, message: e.target.value })} />{err.message && <p className="mt-1 text-xs text-danger">{err.message}</p>}</div><Button type="submit" variant="primary" className="w-full">Send request</Button></form>}</Card>
      </div>
    </Page>
  )
}
