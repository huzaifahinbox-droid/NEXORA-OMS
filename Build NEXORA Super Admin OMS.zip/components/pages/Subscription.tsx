'use client'
import { useState } from 'react'
import { Check } from 'lucide-react'
import { Badge, Button, Card, ConfirmDialog, Progress, Tabs, toast } from '@/components/ui/core'
import { Page, Panel } from '@/components/blocks'
import { authStore, PLANS, useAuth } from '@/lib/session'
import { useDB } from '@/lib/db'

export function Subscription() {
  const a = useAuth()
  const d = useDB()
  const [cycle, setCycle] = useState<'Monthly' | 'Yearly'>(a.billing.cycle)
  const [pick, setPick] = useState<string | null>(null)
  const cur = PLANS.find((p) => p.id === a.billing.plan)!
  const target = PLANS.find((p) => p.id === pick)
  const usage = [['Orders', Math.min(100, Math.round((d.orders.length / 10000) * 100 * 30)), `${d.orders.length * 30} / 10,000`], ['Users', Math.round((d.users.length / 15) * 100), `${d.users.length} / 15`], ['Warehouses', Math.round((d.warehouses.length / 3) * 100), `${d.warehouses.length} / 3`], ['AI credits', 42, '2,100 / 5,000']] as const
  return (
    <Page title="Subscription" desc="Your plan, usage and billing cycle." actions={<Tabs value={cycle} onChange={setCycle} options={['Monthly', 'Yearly'] as const} />}>
      <Card className="flex flex-wrap items-center justify-between gap-4 p-6"><div><p className="text-sm text-text-2">Current plan</p><p className="text-2xl font-bold text-heading">{cur.name} <Badge tone="success" dot>Active</Badge></p><p className="text-sm text-text-2">Renews on 08 Nov 2026 · {a.billing.cycle}</p></div><p className="text-3xl font-bold text-heading">{cur.monthly ? `$${a.billing.cycle === 'Yearly' ? cur.yearly : cur.monthly}` : 'Custom'}<span className="text-sm font-normal text-text-2">/mo</span></p></Card>
      <Panel title="Usage this cycle"><div className="grid gap-5 sm:grid-cols-2">{usage.map(([k, v, t]) => <div key={k}><div className="mb-1.5 flex justify-between text-sm"><span className="font-medium text-heading">{k}</span><span className="text-text-2">{t}</span></div><Progress value={v} tone={v > 85 ? 'danger' : v > 65 ? 'warning' : 'primary'} /></div>)}</div></Panel>
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">{PLANS.map((p) => { const isCur = p.id === a.billing.plan; return (
        <Card key={p.id} className={`flex flex-col p-5 ${isCur ? 'border-primary ring-1 ring-primary' : ''}`}>
          <p className="font-semibold text-heading">{p.name} {isCur && <Badge tone="primary">Current</Badge>}</p>
          <p className="mt-2 text-3xl font-bold text-heading">{p.monthly ? `$${cycle === 'Yearly' ? p.yearly : p.monthly}` : 'Custom'}{p.monthly > 0 && <span className="text-sm font-normal text-text-2">/mo</span>}</p>
          <ul className="my-4 flex-1 space-y-2 text-[13px] text-text">{[`${p.orders} orders`, `${p.users} users`, `${p.warehouses} warehouses`, `${p.ai} AI`, `${p.support} support`].map((f) => <li key={f} className="flex gap-2"><Check size={14} className="mt-0.5 text-success" />{f}</li>)}</ul>
          <Button variant={isCur ? 'secondary' : 'primary'} disabled={isCur} onClick={() => setPick(p.id)}>{isCur ? 'Current plan' : p.monthly ? 'Switch plan' : 'Contact sales'}</Button>
        </Card>) })}</div>
      <ConfirmDialog open={!!target} onClose={() => setPick(null)} title={`Switch to ${target?.name}?`} body={`Your plan changes immediately and is billed ${cycle.toLowerCase()}.`} confirmLabel="Confirm change" onConfirm={() => { authStore.set((s) => ({ ...s, billing: { plan: pick!, cycle } })); toast(`Switched to ${target?.name}`); setPick(null) }} />
    </Page>
  )
}
