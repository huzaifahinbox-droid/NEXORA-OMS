'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Bell, CheckCheck } from 'lucide-react'
import { Badge, Button, Card, EmptyState, Tabs } from '@/components/ui/core'
import { Page } from '@/components/blocks'
import { dbStore, useDB } from '@/lib/db'

const read = (id?: string) => dbStore.set((s) => ({ ...s, notices: s.notices.map((n) => (!id || n.id === id ? { ...n, read: true } : n)) }))

export function Notifications() {
  const d = useDB()
  const router = useRouter()
  const cats = ['All', ...Array.from(new Set(d.notices.map((n) => n.category)))]
  const [c, setC] = useState('All')
  const rows = d.notices.filter((n) => c === 'All' || n.category === c)
  return (
    <Page title="Notifications" desc="Everything that needs your attention, in one place." actions={<Button icon={CheckCheck} onClick={() => read()}>Mark all read</Button>}>
      <Tabs value={c} onChange={setC} options={cats} />
      <Card>{rows.length === 0 ? <EmptyState icon={Bell} title="You’re all caught up" body="No notifications in this category." /> :
        <ul className="divide-y divide-line">{rows.map((n) => (
          <li key={n.id} className="flex flex-wrap items-center gap-3 p-4 px-5">
            <span className={`size-2.5 shrink-0 rounded-full ${n.read ? 'bg-transparent' : 'bg-primary'}`} />
            <div className="min-w-56 flex-1"><div className="flex items-center gap-2"><Badge tone="primary">{n.category}</Badge><span className="text-xs text-text-2">{n.time}</span></div><p className={`mt-1 text-sm ${n.read ? 'text-text' : 'font-semibold text-heading'}`}>{n.title}</p><p className="text-[13px] text-text-2">{n.body}</p></div>
            <div className="flex gap-2">{!n.read && <Button size="sm" variant="ghost" onClick={() => read(n.id)}>Mark read</Button>}<Button size="sm" onClick={() => { read(n.id); router.push(n.href) }}>Open</Button></div>
          </li>))}</ul>}</Card>
    </Page>
  )
}
