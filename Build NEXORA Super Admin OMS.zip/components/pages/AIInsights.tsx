'use client'
import { useRouter } from 'next/navigation'
import { Sparkles } from 'lucide-react'
import { Badge, Button, Card, EmptyState, toast } from '@/components/ui/core'
import { Page, KpiRow } from '@/components/blocks'
import { db, useDB } from '@/lib/db'
import { spark } from '@/lib/metrics'

const SECTIONS = [
  ['Today’s Intelligence', 'Today'], ['Demand Forecast', 'Demand'], ['Inventory Risk', 'Inventory'], ['Delivery Prediction', 'Delivery'],
  ['Supplier Risk', 'Supplier'], ['Warehouse Bottlenecks', 'Warehouse'], ['Revenue Forecast', 'Revenue'], ['Operational Anomalies', 'Anomaly'],
] as const

export function AIInsights() {
  const d = useDB()
  const router = useRouter()
  const live = d.insights.filter((i) => i.status !== 'Dismissed')
  return (
    <Page title="AI Insights" desc="Observations, predictions and recommended actions from NEXORA AI." actions={<Button icon={Sparkles} onClick={() => { db.notify('AI', 'Insights re-generated', 'NEXORA AI refreshed all models.', '/ai-insights'); toast('Models refreshed', 'info') }}>Regenerate</Button>}>
      <KpiRow items={[{ label: 'New insights', value: d.insights.filter((i) => i.status === 'New').length, spark: spark(1) }, { label: 'Applied', value: d.insights.filter((i) => i.status === 'Applied').length, spark: spark(2) }, { label: 'Avg. confidence', value: live.reduce((a, i) => a + i.confidence, 0) / Math.max(1, live.length), format: (n) => `${n.toFixed(0)}%` }, { label: 'Dismissed', value: d.insights.filter((i) => i.status === 'Dismissed').length, spark: spark(4, false) }]} />
      {SECTIONS.map(([title, area], idx) => {
        const items = live.filter((i) => (idx === 0 ? i.status === 'New' : i.area === area))
        return (
          <section key={title} aria-labelledby={`s-${area}`} className="space-y-3">
            <h2 id={`s-${area}`} className="text-lg font-semibold text-heading">{title}</h2>
            {items.length === 0 ? <Card><EmptyState icon={Sparkles} title="No insights here" body="NEXORA AI has nothing to flag for this area right now." /></Card> :
              <div className="grid gap-4 xl:grid-cols-2">{items.map((i) => (
                <Card key={`${title}-${i.id}`} className="space-y-3 p-5" hover>
                  <div className="flex items-start justify-between gap-3"><h3 className="font-semibold text-heading">{i.title}</h3><Badge tone={i.status === 'Applied' ? 'success' : i.status === 'Reviewed' ? 'info' : 'primary'}>{i.status}</Badge></div>
                  <dl className="space-y-2 text-[13px]">
                    {([['Observation', i.observation], ['Why it matters', i.why], ['Impact', i.impact], ['Recommendation', i.recommendation]] as const).map(([k, v]) => <div key={k}><dt className="text-xs font-semibold uppercase tracking-wide text-text-2">{k}</dt><dd className="mt-0.5 text-text">{v}</dd></div>)}
                  </dl>
                  <div className="flex items-center gap-2 text-xs text-text-2"><span className="ai-pulse size-2 rounded-full bg-primary" />Confidence <b className="text-heading">{i.confidence}%</b></div>
                  <div className="flex flex-wrap gap-2 pt-1">
                    <Button size="sm" onClick={() => { db.patch('insights', i.id, { status: 'Reviewed' }); router.push(i.href) }}>Review</Button>
                    <Button size="sm" variant="primary" disabled={i.status === 'Applied'} onClick={() => { db.patch('insights', i.id, { status: 'Applied' }); db.log(`Applied insight ${i.id}`, 'AI Insights', i.status, 'Applied'); toast('Recommendation applied') }}>{i.status === 'Applied' ? 'Applied ✓' : 'Apply'}</Button>
                    <Button size="sm" variant="ghost" onClick={() => { db.patch('insights', i.id, { status: 'Dismissed' }); toast('Insight dismissed', 'info') }}>Dismiss</Button>
                  </div>
                </Card>))}</div>}
          </section>)
      })}
    </Page>
  )
}
