'use client'
import { useState } from 'react'
import { Laptop, Smartphone } from 'lucide-react'
import { Badge, Button, Card, Input, Select, Tabs, Toggle, toast } from '@/components/ui/core'
import { Page } from '@/components/blocks'
import { authStore, useAuth } from '@/lib/session'
import { useUI, ui } from '@/lib/ui'

const TABS = ['Profile', 'Security', 'Preferences', 'Sessions'] as const

export function Profile() {
  const a = useAuth()
  const { profileTab } = useUI()
  const tab = (TABS as readonly string[]).includes(profileTab) ? (profileTab as (typeof TABS)[number]) : 'Profile'
  const [p, setP] = useState(a.profile)
  const [pw, setPw] = useState({ cur: '', next: '', conf: '' })
  const [err, setErr] = useState<Record<string, string>>({})
  const [sessions, setSessions] = useState([{ id: 's1', d: 'Chrome · macOS', loc: 'Bengaluru, IN', now: true }, { id: 's2', d: 'Safari · iPhone', loc: 'Bengaluru, IN', now: false }, { id: 's3', d: 'Edge · Windows', loc: 'Mumbai, IN', now: false }])
  const initials = p.name.split(' ').map((x) => x[0]).join('').slice(0, 2)
  const savePw = (e: React.FormEvent) => {
    e.preventDefault()
    const er: Record<string, string> = {}
    if (!pw.cur) er.cur = 'Enter your current password'
    if (pw.next.length < 8) er.next = 'Use at least 8 characters'
    if (pw.conf !== pw.next) er.conf = 'Passwords do not match'
    setErr(er)
    if (!Object.keys(er).length) { setPw({ cur: '', next: '', conf: '' }); toast('Password updated') }
  }
  return (
    <Page title="Profile" desc="Manage your personal information, security and preferences.">
      <Tabs value={tab} onChange={(t) => ui.set({ profileTab: t })} options={TABS} />
      <div className="grid gap-6 xl:grid-cols-[320px_minmax(0,1fr)]">
        <Card className="flex flex-col items-center p-6 text-center"><span className="grid size-20 place-items-center rounded-full bg-primary text-2xl font-bold text-white">{initials}</span><p className="mt-3 text-lg font-semibold text-heading">{p.name}</p><p className="text-sm text-text-2">{p.email}</p><div className="mt-3 flex gap-2"><Badge tone="primary">{p.role}</Badge><Badge tone="success" dot>Active</Badge></div><Button className="mt-5" size="sm" onClick={() => toast('Photo upload is simulated in this demo', 'info')}>Change photo</Button></Card>
        <Card className="space-y-5 p-6">
          {tab === 'Profile' && <><div className="grid gap-4 sm:grid-cols-2"><Input label="Full name" value={p.name} onChange={(e) => setP({ ...p, name: e.target.value })} /><Input label="Email" value={p.email} onChange={(e) => setP({ ...p, email: e.target.value })} /><Input label="Phone" value={p.phone} onChange={(e) => setP({ ...p, phone: e.target.value })} /><Input label="Department" value={p.department} onChange={(e) => setP({ ...p, department: e.target.value })} /></div><Button variant="primary" onClick={() => { authStore.set((s) => ({ ...s, profile: p })); toast('Profile saved') }}>Save profile</Button></>}
          {tab === 'Security' && <><Toggle label="Two-factor authentication" checked={p.twoFA} onChange={(v) => { setP({ ...p, twoFA: v }); authStore.set((s) => ({ ...s, profile: { ...s.profile, twoFA: v } })); toast(`2FA ${v ? 'enabled' : 'disabled'}`, 'info') }} />
            <form onSubmit={savePw} className="space-y-4 border-t border-line pt-5" noValidate><h3 className="font-semibold text-heading">Change password</h3><Input label="Current password" type="password" value={pw.cur} error={err.cur} onChange={(e) => setPw({ ...pw, cur: e.target.value })} /><Input label="New password" type="password" value={pw.next} error={err.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} /><Input label="Confirm new password" type="password" value={pw.conf} error={err.conf} onChange={(e) => setPw({ ...pw, conf: e.target.value })} /><Button type="submit" variant="primary">Update password</Button></form></>}
          {tab === 'Preferences' && <><div className="grid gap-4 sm:grid-cols-2"><Select label="Language" value={p.language} onChange={(e) => setP({ ...p, language: e.target.value })} options={['English', 'हिन्दी', 'Español']} /><Select label="Timezone" value={p.timezone} onChange={(e) => setP({ ...p, timezone: e.target.value })} options={['Asia/Kolkata', 'Asia/Dubai', 'Europe/London']} /><Select label="Date format" value={p.dateFormat} onChange={(e) => setP({ ...p, dateFormat: e.target.value })} options={['DD/MM/YYYY', 'MM/DD/YYYY', 'YYYY-MM-DD']} /></div><Button variant="primary" onClick={() => { authStore.set((s) => ({ ...s, profile: p })); toast('Preferences saved') }}>Save preferences</Button></>}
          {tab === 'Sessions' && <ul className="divide-y divide-line">{sessions.map((s, i) => <li key={s.id} className="flex items-center gap-3 py-3">{i === 1 ? <Smartphone size={18} /> : <Laptop size={18} />}<div className="flex-1"><p className="text-sm font-medium text-heading">{s.d}{s.now && <Badge tone="success">This device</Badge>}</p><p className="text-xs text-text-2">{s.loc}</p></div>{!s.now && <Button size="sm" variant="danger" onClick={() => { setSessions((x) => x.filter((y) => y.id !== s.id)); toast('Session revoked') }}>Revoke</Button>}</li>)}</ul>}
        </Card>
      </div>
    </Page>
  )
}
