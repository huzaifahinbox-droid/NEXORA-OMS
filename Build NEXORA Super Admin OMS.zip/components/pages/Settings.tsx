'use client'
import { useState } from 'react'
import { Save } from 'lucide-react'
import { Button, Card, Input, Select, Tabs, Toggle, toast } from '@/components/ui/core'
import { Page } from '@/components/blocks'
import { useTheme, type Theme } from '@/components/theme'
import { createStore } from '@/lib/store'

const TABS = ['General', 'Notifications', 'Appearance', 'Integrations', 'Security'] as const
const settingsStore = createStore('nexora-settings-v1', () => ({
  general: { company: 'DTC Operations Pvt Ltd', currency: 'INR (₹)', timezone: 'Asia/Kolkata', fiscal: 'April', slaHours: '24' },
  notify: { Orders: true, Inventory: true, Logistics: true, Procurement: false, Billing: true, AI: true, Email: true, Push: false },
  integrations: { Shopify: true, WooCommerce: false, Amazon: true, Delhivery: true, Razorpay: true, Slack: false } as Record<string, boolean>,
  security: { twoFA: true, sso: false, sessionTimeout: '30', ipAllow: false },
}))

export function Settings() {
  const s = settingsStore.use()
  const [tab, setTab] = useState<(typeof TABS)[number]>('General')
  const { theme, setTheme } = useTheme()
  const [g, setG] = useState(s.general)
  const save = () => { settingsStore.set((x) => ({ ...x, general: g })); toast('Settings saved') }
  const flip = (k: 'notify' | 'integrations' | 'security', key: string, v: boolean) => { settingsStore.set((x) => ({ ...x, [k]: { ...x[k], [key]: v } })); toast(`${key} ${v ? 'enabled' : 'disabled'}`, 'info') }
  return (
    <Page title="Settings" desc="Configure your workspace, notifications, appearance, integrations and security.">
      <Tabs value={tab} onChange={setTab} options={TABS} />
      <Card className="max-w-3xl space-y-5 p-6">
        {tab === 'General' && <>
          <Input label="Company name" value={g.company} onChange={(e) => setG({ ...g, company: e.target.value })} />
          <div className="grid gap-4 sm:grid-cols-2"><Select label="Currency" value={g.currency} onChange={(e) => setG({ ...g, currency: e.target.value })} options={['INR (₹)', 'USD ($)', 'EUR (€)']} /><Select label="Timezone" value={g.timezone} onChange={(e) => setG({ ...g, timezone: e.target.value })} options={['Asia/Kolkata', 'Asia/Dubai', 'Europe/London', 'America/New_York']} /><Select label="Fiscal year starts" value={g.fiscal} onChange={(e) => setG({ ...g, fiscal: e.target.value })} options={['January', 'April', 'July']} /><Input label="Default SLA (hours)" value={g.slaHours} onChange={(e) => setG({ ...g, slaHours: e.target.value })} /></div>
          <Button variant="primary" icon={Save} onClick={save}>Save changes</Button></>}
        {tab === 'Notifications' && Object.entries(s.notify).map(([k, v]) => <Toggle key={k} label={`${k} ${['Email', 'Push'].includes(k) ? 'notifications' : 'alerts'}`} checked={v} onChange={(x) => flip('notify', k, x)} />)}
        {tab === 'Appearance' && <div role="radiogroup" aria-label="Theme" className="grid gap-3 sm:grid-cols-3">{(['light', 'dark', 'system'] as Theme[]).map((t) => <button key={t} role="radio" aria-checked={theme === t} onClick={() => setTheme(t)} className={`rounded-xl border p-4 text-left capitalize transition-colors ${theme === t ? 'border-primary bg-primary-light text-primary' : 'border-line hover:bg-hover text-heading'}`}><span className="font-semibold">{t}</span><span className="mt-1 block text-xs text-text-2">{t === 'system' ? 'Match your device' : `Always ${t}`}</span></button>)}</div>}
        {tab === 'Integrations' && Object.entries(s.integrations).map(([k, v]) => <Toggle key={k} label={`${k} — ${v ? 'Connected' : 'Not connected'}`} checked={v} onChange={(x) => flip('integrations', k, x)} />)}
        {tab === 'Security' && <><Toggle label="Two-factor authentication" checked={s.security.twoFA} onChange={(x) => flip('security', 'twoFA', x)} /><Toggle label="Single sign-on (SSO)" checked={s.security.sso} onChange={(x) => flip('security', 'sso', x)} /><Toggle label="Restrict to allow-listed IPs" checked={s.security.ipAllow} onChange={(x) => flip('security', 'ipAllow', x)} /><Select label="Session timeout (minutes)" value={s.security.sessionTimeout} onChange={(e) => settingsStore.set((x) => ({ ...x, security: { ...x.security, sessionTimeout: e.target.value } }))} options={['15', '30', '60', '120']} /></>}
      </Card>
    </Page>
  )
}
