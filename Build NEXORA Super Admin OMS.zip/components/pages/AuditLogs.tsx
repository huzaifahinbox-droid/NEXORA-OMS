'use client'
import { useState } from 'react'
import { Download, Eye, ShieldCheck } from 'lucide-react'
import { Button, DataTable, Modal, toast } from '@/components/ui/core'
import { Page } from '@/components/blocks'
import { useDB } from '@/lib/db'
import type { AuditLog } from '@/types'

export function AuditLogs() {
  const d = useDB()
  const [mod, setMod] = useState('All')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [sel, setSel] = useState<AuditLog | null>(null)
  const mods = ['All', ...Array.from(new Set(d.audit.map((a) => a.module)))]
  const rows = d.audit.filter((a) => (mod === 'All' || a.module === mod) && (!from || a.time.slice(0, 10) >= from) && (!to || a.time.slice(0, 10) <= to))
  const ctl = 'h-10 rounded-lg border border-line-strong bg-surface px-3 text-sm text-heading'
  return (
    <Page title="Audit Logs" desc="A read-only, tamper-evident record of every change in your workspace." actions={<Button icon={Download} onClick={() => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([rows.map((r) => [r.id, r.user, r.action, r.module, r.time].join(',')).join('\n')], { type: 'text/csv' })); a.download = 'audit-logs.csv'; a.click(); toast('Audit log exported') }}>Export</Button>}>
      <div className="flex items-center gap-2 rounded-lg bg-info-bg px-4 py-2.5 text-[13px] text-info"><ShieldCheck size={16} />Audit logs are immutable. They cannot be edited or deleted.</div>
      <DataTable rows={rows} searchOf={(a) => `${a.user} ${a.action} ${a.module} ${a.id}`} onRow={setSel}
        toolbar={<div className="flex flex-wrap items-center gap-2"><select aria-label="Module" className={ctl} value={mod} onChange={(e) => setMod(e.target.value)}>{mods.map((m) => <option key={m}>{m}</option>)}</select><input aria-label="From date" type="date" className={ctl} value={from} onChange={(e) => setFrom(e.target.value)} /><input aria-label="To date" type="date" className={ctl} value={to} onChange={(e) => setTo(e.target.value)} /></div>}
        cols={[{ key: 'time', label: 'Time' }, { key: 'user', label: 'User' }, { key: 'action', label: 'Action' }, { key: 'module', label: 'Module' }, { key: 'device', label: 'Device' }]}
        actions={(a) => <Button size="sm" variant="ghost" icon={Eye} onClick={() => setSel(a)}>View</Button>} />
      <Modal open={!!sel} onClose={() => setSel(null)} title={sel?.action ?? ''}>
        {sel && <dl className="grid gap-3 text-sm sm:grid-cols-2">{[['Log ID', sel.id], ['User', sel.user], ['Module', sel.module], ['Time', sel.time], ['Device', sel.device]].map(([k, v]) => <div key={k}><dt className="text-xs text-text-2">{k}</dt><dd className="font-medium text-heading">{v}</dd></div>)}
          <div className="rounded-lg bg-danger-bg p-3"><dt className="text-xs text-danger">Before</dt><dd className="text-heading">{sel.before}</dd></div><div className="rounded-lg bg-success-bg p-3"><dt className="text-xs text-success">After</dt><dd className="text-heading">{sel.after}</dd></div></dl>}
      </Modal>
    </Page>
  )
}
