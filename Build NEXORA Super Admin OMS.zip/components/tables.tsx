'use client'
import { useState } from 'react'
import { Truck } from 'lucide-react'
import { Badge, Button, ConfirmDialog, DataTable, Dropdown, Modal, Select, StatusBadge, toast, type Col } from '@/components/ui/core'
import { RecordModal, Timeline } from '@/components/blocks'
import { db, inventoryStatus, money, useDB } from '@/lib/db'
import { CARRIERS } from '@/data/seed'
import { PIPELINE, type InventoryRow, type Order, type OrderStatus, type Shipment } from '@/types'

export const useNames = () => {
  const d = useDB()
  return { cust: (id: string) => d.customers.find((c) => c.id === id)?.name ?? id, prod: (sku: string) => d.products.find((p) => p.sku === sku)?.name ?? sku }
}

export function OrderDetail({ id, onClose }: { id: string | null; onClose: () => void }) {
  const d = useDB()
  const o = d.orders.find((x) => x.id === id)
  const { cust, prod } = useNames()
  if (!o) return null
  const sh = d.shipments.find((s) => s.orderId === o.id)
  const inv = d.inventory.find((r) => r.sku === o.sku && r.warehouse === o.warehouse)
  const idx = PIPELINE.indexOf(o.status)
  return (
    <Modal open onClose={onClose} title={`Order ${o.id}`} wide footer={<><Button onClick={onClose}>Close</Button>{idx >= 0 && idx < 6 && <Button variant="primary" onClick={() => { db.advanceOrder(o.id); toast(`${o.id} advanced`) }}>Advance to {PIPELINE[idx + 1]}</Button>}</>}>
      <div className="grid gap-6 sm:grid-cols-2">
        <dl className="space-y-2 text-sm">
          {[['Customer', cust(o.customerId)], ['Product', `${prod(o.sku)} (${o.sku}) × ${o.qty}`], ['Total', money(o.total)], ['Channel', o.channel], ['Warehouse', o.warehouse], ['Placed', o.date], ['Shipment', sh ? `${sh.id} · ${sh.carrier} · ${sh.status}` : 'Not yet created'], ['Stock position', inv ? `${inv.available} available / ${inv.reserved} reserved` : '—']].map(([k, v]) => <div key={k} className="flex justify-between gap-4"><dt className="text-text-2">{k}</dt><dd className="text-right font-medium text-heading">{v}</dd></div>)}
          <div className="flex justify-between"><dt className="text-text-2">Status</dt><dd><StatusBadge s={o.status} /></dd></div>
          {o.reason && <div className="flex justify-between"><dt className="text-text-2">Reason</dt><dd className="font-medium text-heading">{o.reason}</dd></div>}
        </dl>
        <Timeline events={PIPELINE.map((s, i) => ({ title: s, time: i <= idx ? 'Completed' : 'Pending', done: i <= idx }))} />
      </div>
    </Modal>
  )
}

export function OrdersTable({ statuses, reason, title, pageSize, showFilter }: { statuses?: OrderStatus[]; reason?: boolean; title?: string; pageSize?: number; showFilter?: boolean }) {
  const d = useDB()
  const { cust, prod } = useNames()
  const [detail, setDetail] = useState<string | null>(null)
  const [confirm, setConfirm] = useState<{ id: string; to: OrderStatus } | null>(null)
  const [filter, setFilter] = useState('')
  const rows = d.orders.filter((o) => (!statuses || statuses.includes(o.status)) && (!filter || o.status === filter))
  const cols: Col<Order>[] = [
    { key: 'id', label: 'Order', render: (o) => <b className="text-heading">{o.id}</b> },
    { key: 'customerId', label: 'Customer', sort: (o) => cust(o.customerId), render: (o) => cust(o.customerId) },
    { key: 'sku', label: 'Item', render: (o) => <span>{prod(o.sku)} <span className="text-muted">×{o.qty}</span></span> },
    { key: 'channel', label: 'Channel' },
    { key: 'total', label: 'Total', align: 'right', render: (o) => money(o.total) },
    ...(reason ? [{ key: 'reason', label: 'Reason', render: (o: Order) => o.reason ?? '—' }] : []),
    { key: 'status', label: 'Status', render: (o) => <StatusBadge s={o.status} /> },
    { key: 'date', label: 'Date' },
  ]
  return (
    <>
      <DataTable rows={rows} cols={cols} pageSize={pageSize} searchOf={(o) => `${o.id} ${cust(o.customerId)} ${o.sku} ${o.channel} ${o.status}`} onRow={(o) => setDetail(o.id)}
        filters={showFilter ? <select aria-label="Filter by status" value={filter} onChange={(e) => setFilter(e.target.value)} className="h-10 rounded-lg border border-line-strong bg-surface px-3 text-sm text-heading"><option value="">All statuses</option>{[...PIPELINE, 'On Hold', 'Cancelled', 'Returned'].map((s) => <option key={s}>{s}</option>)}</select> : undefined}
        empty={{ title: title ?? 'No orders here', body: 'Orders matching this view will appear as they move through the pipeline.' }}
        actions={(o) => (
          <>
            {PIPELINE.indexOf(o.status) >= 0 && PIPELINE.indexOf(o.status) < 6 && <Button size="sm" onClick={() => { db.advanceOrder(o.id); toast(`${o.id} → ${PIPELINE[PIPELINE.indexOf(o.status) + 1]}`) }}>Advance</Button>}
            {o.status === 'On Hold' && <Button size="sm" onClick={() => { db.setOrderStatus(o.id, 'Confirmed'); toast(`${o.id} released from hold`) }}>Release</Button>}
            <Dropdown label="More" items={[{ label: 'View details', onClick: () => setDetail(o.id) }, ...(PIPELINE.indexOf(o.status) >= 0 && PIPELINE.indexOf(o.status) < 5 ? [{ label: 'Put on hold', onClick: () => setConfirm({ id: o.id, to: 'On Hold' as OrderStatus }) }] : []), ...(['New', 'Confirmed', 'Allocated', 'Picking', 'Packed', 'On Hold'].includes(o.status) ? [{ label: 'Cancel order', danger: true, onClick: () => setConfirm({ id: o.id, to: 'Cancelled' as OrderStatus }) }] : [])]}
              trigger={<span className="grid h-8 w-8 place-items-center rounded-lg text-text-2 hover:bg-hover" aria-label={`More actions for ${o.id}`}>⋯</span>} />
          </>
        )} />
      <OrderDetail id={detail} onClose={() => setDetail(null)} />
      <ConfirmDialog open={!!confirm} danger={confirm?.to === 'Cancelled'} title={`${confirm?.to === 'Cancelled' ? 'Cancel' : 'Hold'} ${confirm?.id}?`} body="This updates the order, releases any reserved stock and is recorded in the audit log." confirmLabel="Confirm" onClose={() => setConfirm(null)} onConfirm={() => { if (confirm) { db.setOrderStatus(confirm.id, confirm.to); toast(`${confirm.id} is now ${confirm.to}`) } }} />
    </>
  )
}

export function ShipmentActions({ s, compact }: { s: Shipment; compact?: boolean }) {
  const [modal, setModal] = useState<'carrier' | 'address' | null>(null)
  const [carrier, setCarrier] = useState(CARRIERS[1])
  const log = (kind: string, patch?: Partial<Shipment>, msg?: string) => {
    db.add('actions', { id: `ACT-${Date.now()}`, kind, shipmentId: s.id, owner: 'Aditi Rao', priority: s.sla === 'Breached' ? 'High' : 'Medium', sla: '8h', status: 'In Progress' })
    if (patch) db.patch('shipments', s.id, patch)
    db.log(`${kind} for ${s.id}`, 'Logistics', s.status, patch?.status ?? s.status)
    toast(msg ?? `${kind} initiated for ${s.id}`)
  }
  return (
    <>
      <Dropdown label="Actions" items={[
        { label: 'Reattempt', onClick: () => log('Reattempt delivery', { status: 'Scheduled', issue: undefined, sla: 'At risk' }) },
        { label: 'Change Carrier', onClick: () => setModal('carrier') },
        { label: 'Update Address', onClick: () => setModal('address') },
        { label: 'Escalate', onClick: () => log('Escalate to carrier') },
        { label: 'Contact Customer', onClick: () => log('Contact customer', undefined, `Customer notified about ${s.id}`) },
      ]} trigger={<span className={compact ? 'grid size-8 place-items-center rounded-lg text-text-2 hover:bg-hover' : 'inline-flex h-8 items-center gap-1 rounded-lg border border-line-strong px-3 text-[13px] font-medium text-heading hover:bg-hover'} aria-label={`Actions for ${s.id}`}>{compact ? '⋯' : 'Actions'}</span>} />
      <Modal open={modal === 'carrier'} onClose={() => setModal(null)} title={`Change carrier — ${s.id}`} footer={<><Button onClick={() => setModal(null)}>Cancel</Button><Button variant="primary" onClick={() => { log('Change carrier', { carrier, status: 'In Transit', issue: undefined, sla: 'At risk' }, `${s.id} reassigned to ${carrier}`); setModal(null) }}>Reassign</Button></>}>
        <Select label="New carrier" value={carrier} onChange={(e) => setCarrier(e.target.value)} options={CARRIERS.filter((c) => c !== s.carrier)} />
      </Modal>
      <RecordModal open={modal === 'address'} onClose={() => setModal(null)} title={`Update address — ${s.id}`} fields={[{ key: 'addr', label: 'New delivery address', type: 'textarea' }, { key: 'city', label: 'City' }]} initial={{ city: s.destination }} onSubmit={(v) => log('Update address', { destination: v.city, issue: undefined }, `Address updated for ${s.id}`)} />
    </>
  )
}

export function ShipmentsTable({ statuses, filter, actions, showIssue, pageSize }: { statuses?: Shipment['status'][]; filter?: (s: Shipment) => boolean; actions?: boolean; showIssue?: boolean; pageSize?: number }) {
  const d = useDB()
  const rows = d.shipments.filter((s) => (!statuses || statuses.includes(s.status)) && (!filter || filter(s)))
  const cols: Col<Shipment>[] = [
    { key: 'id', label: 'Shipment', render: (s) => <b className="text-heading">{s.id}</b> },
    { key: 'orderId', label: 'Order' },
    { key: 'carrier', label: 'Carrier' },
    { key: 'destination', label: 'Destination' },
    ...(showIssue ? [{ key: 'issue', label: 'Issue', render: (s: Shipment) => s.issue ?? s.lastScan }] : [{ key: 'lastScan', label: 'Last scan' }]),
    { key: 'status', label: 'Status', render: (s) => <StatusBadge s={s.status} /> },
    { key: 'eta', label: 'ETA' },
    { key: 'sla', label: 'SLA', render: (s) => <Badge tone={s.sla === 'Breached' ? 'danger' : s.sla === 'At risk' ? 'warning' : 'success'}>{s.sla}</Badge> },
  ]
  return <DataTable rows={rows} cols={cols} pageSize={pageSize} searchOf={(s) => `${s.id} ${s.orderId} ${s.carrier} ${s.destination} ${s.awb}`} empty={{ title: 'No shipments in this view', body: 'Everything here is moving smoothly.' }} actions={actions ? (s) => <ShipmentActions s={s} compact /> : undefined} />
}

export function InventoryTable({ filter, pageSize, adjust }: { filter?: (r: InventoryRow) => boolean; pageSize?: number; adjust?: boolean }) {
  const d = useDB()
  const [edit, setEdit] = useState<InventoryRow | null>(null)
  const p = (sku: string) => d.products.find((x) => x.sku === sku)
  const rows = d.inventory.filter((r) => !filter || filter(r))
  const cols: Col<InventoryRow>[] = [
    { key: 'sku', label: 'SKU', render: (r) => <b className="text-heading">{r.sku}</b> },
    { key: 'product', label: 'Product', sort: (r) => p(r.sku)?.name ?? '', render: (r) => p(r.sku)?.name },
    { key: 'category', label: 'Category', render: (r) => p(r.sku)?.category },
    { key: 'warehouse', label: 'Warehouse' },
    { key: 'available', label: 'Available', align: 'right' },
    { key: 'reserved', label: 'Reserved', align: 'right' },
    { key: 'incoming', label: 'Incoming', align: 'right' },
    { key: 'reorder', label: 'Reorder pt', align: 'right' },
    { key: 'status', label: 'Status', sort: (r) => inventoryStatus(r), render: (r) => <StatusBadge s={inventoryStatus(r)} /> },
  ]
  return (
    <>
      <DataTable rows={rows} cols={cols} pageSize={pageSize} searchOf={(r) => `${r.sku} ${p(r.sku)?.name} ${r.warehouse} ${p(r.sku)?.category}`} empty={{ title: 'No SKUs in this view', body: 'Stock positions matching this view will appear here.' }} actions={adjust ? (r) => <Button size="sm" onClick={() => setEdit(r)}>Adjust</Button> : undefined} />
      <RecordModal open={!!edit} onClose={() => setEdit(null)} title={`Adjust ${edit?.sku} @ ${edit?.warehouse}`} fields={[{ key: 'qty', label: 'Quantity change (+/-)', type: 'number' }, { key: 'reason', label: 'Reason', type: 'select', options: ['Cycle count correction', 'Damaged', 'Lost item', 'Found stock'] }]} onSubmit={(v) => { if (!edit) return; const q = parseInt(v.qty, 10) || 0; db.add('adjustments', { id: `ADJ-${Date.now() % 100000}`, sku: edit.sku, warehouse: edit.warehouse, qty: q, reason: v.reason, approval: 'Pending', by: 'Aditi Rao', time: 'just now' }); toast('Adjustment submitted for approval') }} />
    </>
  )
}
export const TruckIcon = Truck
