'use client'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { useMemo, useState } from 'react'
import { Bell, ChevronRight, HelpCircle, LogOut, Menu, Monitor, Moon, Search, Sparkles, Sun, User } from 'lucide-react'
import { NAV, STATIC_TITLES, findModule } from '@/lib/nav'
import { Badge, cn, hint, IconButton, Tabs, toast, useOutside } from '@/components/ui/core'
import { useDB, db } from '@/lib/db'
import { authStore, useAuth } from '@/lib/session'
import { ui } from '@/lib/ui'
import { useTheme, type Theme } from '@/components/theme'

function Breadcrumb() {
  const path = usePathname()
  const [m, p] = path.split('/').filter(Boolean)
  const mod = m ? findModule(m) : undefined
  const crumbs: { label: string; href?: string }[] = []
  if (mod) {
    const g = NAV.find((x) => x.modules?.some((y) => y.slug === mod.slug))
    crumbs.push({ label: g?.label ?? 'NEXORA' }, { label: mod.name, href: `/${mod.slug}/overview` })
    const pg = mod.pages.find((x) => x.slug === (p ?? 'overview'))
    crumbs.push({ label: pg?.name ?? 'Overview' })
  } else {
    const g = NAV.find((x) => x.leaves?.some((l) => l.href === path))
    crumbs.push({ label: g?.label ?? 'Account' }, { label: STATIC_TITLES[path] ?? 'Page' })
  }
  return (
    <nav aria-label="Breadcrumb" className="hidden min-w-0 lg:block">
      <ol className="flex items-center gap-1.5 text-[13px]">
        {crumbs.map((c, i) => (
          <li key={i} className="flex items-center gap-1.5 whitespace-nowrap">
            {i > 0 && <ChevronRight size={14} className="text-muted" />}
            {c.href ? <Link href={c.href} className="text-text-2 hover:text-heading">{c.label}</Link> : <span className={i === crumbs.length - 1 ? 'font-semibold text-heading' : 'text-text-2'} aria-current={i === crumbs.length - 1 ? 'page' : undefined}>{c.label}</span>}
          </li>
        ))}
      </ol>
    </nav>
  )
}

function GlobalSearch() {
  const [q, setQ] = useState('')
  const [open, setOpen] = useState(false)
  const router = useRouter()
  const d = useDB()
  const ref = useOutside(() => setOpen(false))
  const results = useMemo(() => {
    const t = q.trim().toLowerCase()
    if (t.length < 2) return []
    const has = (...v: string[]) => v.some((x) => x.toLowerCase().includes(t))
    const r: { group: string; label: string; sub: string; href: string }[] = []
    d.orders.filter((o) => has(o.id, o.sku, o.channel)).slice(0, 3).forEach((o) => r.push({ group: 'Orders', label: o.id, sub: `${o.status} · ${o.sku}`, href: '/order-management/all-orders' }))
    d.customers.filter((c) => has(c.name, c.email, c.id)).slice(0, 3).forEach((c) => r.push({ group: 'Customers', label: c.name, sub: c.email, href: '/customer-management/customer-directory' }))
    d.products.filter((p) => has(p.sku, p.name)).slice(0, 3).forEach((p) => r.push({ group: 'SKUs', label: p.sku, sub: p.name, href: '/inventory-management/sku-catalog' }))
    d.shipments.filter((s) => has(s.id, s.awb, s.orderId)).slice(0, 3).forEach((s) => r.push({ group: 'Shipments', label: s.id, sub: `${s.carrier} · ${s.status}`, href: '/shipment-management/shipment-directory' }))
    d.warehouses.filter((w) => has(w.id, w.name, w.city)).slice(0, 2).forEach((w) => r.push({ group: 'Warehouses', label: w.id, sub: w.name, href: '/warehouse-management/warehouse-directory' }))
    d.vendors.filter((v) => has(v.id, v.name)).slice(0, 2).forEach((v) => r.push({ group: 'Vendors', label: v.name, sub: v.id, href: '/vendors/vendor-directory' }))
    d.buyers.filter((b) => has(b.id, b.name)).slice(0, 2).forEach((b) => r.push({ group: 'Buyers', label: b.name, sub: b.department, href: '/buyers/buyer-directory' }))
    d.users.filter((u) => has(u.name, u.email)).slice(0, 2).forEach((u) => r.push({ group: 'Users', label: u.name, sub: u.role, href: '/user-management/user-directory' }))
    return r
  }, [q, d])
  const go = (href: string, label: string) => { hint.q = label; hint.at = Date.now(); setOpen(false); setQ(''); router.push(href) }
  return (
    <div ref={ref} className="relative w-full max-w-md">
      <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
      <input role="combobox" aria-expanded={open} aria-label="Global search" value={q} onFocus={() => setOpen(true)} onChange={(e) => { setQ(e.target.value); setOpen(true) }} placeholder="Search orders, customers, SKUs, shipments…" className="h-10 w-full rounded-lg border border-line bg-surface-2 pl-9 pr-3 text-sm text-heading placeholder:text-muted focus:border-primary focus:bg-surface focus:outline-none focus:ring-2 focus:ring-primary/30" />
      {open && q.trim().length >= 2 && (
        <div className="anim-pop scroll-thin absolute left-0 right-0 z-50 mt-2 max-h-96 overflow-y-auto rounded-xl border border-line bg-surface p-1.5 shadow-pop" role="listbox">
          {results.length === 0 ? <p className="px-3 py-6 text-center text-sm text-text-2">No matches for “{q}”.</p> : results.map((r, i) => (
            <button key={i} role="option" aria-selected="false" onClick={() => go(r.href, r.label)} className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left hover:bg-hover">
              <Badge tone="primary">{r.group}</Badge><span className="min-w-0 flex-1"><span className="block truncate text-sm font-medium text-heading">{r.label}</span><span className="block truncate text-xs text-text-2">{r.sub}</span></span>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

const CATS = ['All', 'Orders', 'Inventory', 'Procurement', 'Warehouse', 'Logistics', 'Finance', 'Security', 'AI Alerts'] as const
function Notifications() {
  const [open, setOpen] = useState(false)
  const [cat, setCat] = useState<(typeof CATS)[number]>('All')
  const d = useDB()
  const router = useRouter()
  const ref = useOutside(() => setOpen(false))
  const unread = d.notices.filter((n) => !n.read).length
  const list = d.notices.filter((n) => cat === 'All' || n.category === cat)
  return (
    <div ref={ref} className="relative">
      <button aria-label={`Notifications, ${unread} unread`} aria-expanded={open} onClick={() => setOpen(!open)} className="relative grid size-10 place-items-center rounded-lg text-text-2 hover:bg-hover hover:text-heading"><Bell size={18} />{unread > 0 && <span className="absolute right-1.5 top-1.5 grid min-w-4 place-items-center rounded-full bg-danger px-1 text-[10px] font-bold text-white dark:text-slate-900">{unread}</span>}</button>
      {open && (
        <div className="anim-pop fixed inset-x-3 top-[76px] z-50 rounded-xl border border-line bg-surface shadow-pop sm:absolute sm:inset-x-auto sm:right-0 sm:top-auto sm:mt-2 sm:w-[400px]">
          <div className="flex items-center justify-between px-4 pt-4"><h3 className="font-semibold text-heading">Notifications</h3><button className="text-[13px] font-medium text-primary hover:underline" onClick={() => { d.notices.forEach((n) => db.patch('notices', n.id, { read: true })); toast('All notifications marked as read') }}>Mark All Read</button></div>
          <div className="px-4 pt-3"><Tabs value={cat} onChange={setCat} options={CATS} className="w-full" /></div>
          <ul className="scroll-thin mt-2 max-h-[360px] overflow-y-auto p-2">
            {list.length === 0 && <li className="px-3 py-8 text-center text-sm text-text-2">You’re all caught up.</li>}
            {list.map((n) => (
              <li key={n.id} className={cn('rounded-lg p-3 hover:bg-hover', !n.read && 'bg-primary-light/40')}>
                <div className="flex items-start gap-2"><span className={cn('mt-1.5 size-2 shrink-0 rounded-full', n.read ? 'bg-transparent' : 'bg-primary')} /><div className="min-w-0 flex-1"><p className="text-sm font-medium text-heading">{n.title}</p><p className="text-[13px] text-text-2">{n.body}</p><div className="mt-1.5 flex items-center gap-3 text-xs"><Badge>{n.category}</Badge><span className="text-muted">{n.time}</span><button className="ml-auto font-medium text-primary hover:underline" onClick={() => { db.patch('notices', n.id, { read: true }); setOpen(false); router.push(n.href) }}>Open</button>{!n.read && <button className="font-medium text-text-2 hover:text-heading" onClick={() => db.patch('notices', n.id, { read: true })}>Mark Read</button>}</div></div></div>
              </li>
            ))}
          </ul>
          <div className="border-t border-line p-2"><Link href="/notifications" onClick={() => setOpen(false)} className="block rounded-lg py-2 text-center text-[13px] font-medium text-primary hover:bg-hover">View all notifications</Link></div>
        </div>
      )}
    </div>
  )
}

function ProfileMenu() {
  const [open, setOpen] = useState(false)
  const router = useRouter()
  const { profile } = useAuth()
  const { theme, setTheme } = useTheme()
  const ref = useOutside(() => setOpen(false))
  const item = 'flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm text-text hover:bg-hover'
  const go = (href: string, tab?: string) => { if (tab) ui.set({ profileTab: tab }); setOpen(false); router.push(href) }
  const initials = profile.name.split(' ').map((x) => x[0]).join('')
  return (
    <div ref={ref} className="relative">
      <button aria-label="Profile menu" aria-expanded={open} onClick={() => setOpen(!open)} className="grid size-10 place-items-center rounded-full bg-gradient-to-br from-primary to-purple text-sm font-semibold text-white ring-offset-2 ring-offset-surface transition hover:ring-2 hover:ring-primary/40">{initials}</button>
      {open && (
        <div role="menu" className="anim-pop absolute right-0 z-50 mt-2 w-64 rounded-xl border border-line bg-surface p-1.5 shadow-pop">
          <div className="border-b border-line px-3 pb-2.5 pt-1.5"><p className="text-sm font-semibold text-heading">{profile.name}</p><p className="text-xs text-text-2">{profile.email}</p></div>
          <div className="py-1.5">
            <button role="menuitem" className={item} onClick={() => go('/profile', 'Profile')}><User size={16} />Profile</button>
            <button role="menuitem" className={item} onClick={() => go('/settings')}>Account Settings</button>
            <button role="menuitem" className={item} onClick={() => go('/profile', 'Security')}>Security</button>
          </div>
          <div className="flex items-center justify-between border-t border-line px-3 py-2"><span className="text-sm text-text">Theme</span>
            <div className="flex rounded-lg bg-hover p-0.5">{([['light', Sun], ['dark', Moon], ['system', Monitor]] as [Theme, typeof Sun][]).map(([t, I]) => <button key={t} aria-label={`${t} theme`} aria-pressed={theme === t} onClick={() => setTheme(t)} className={cn('grid size-7 place-items-center rounded-md', theme === t ? 'bg-surface text-primary shadow-xs' : 'text-text-2')}><I size={14} /></button>)}</div></div>
          <div className="border-t border-line pt-1.5"><button role="menuitem" className={cn(item, 'text-danger')} onClick={() => { authStore.set((s) => ({ ...s, signedIn: false })); router.push('/login') }}><LogOut size={16} />Sign Out</button></div>
        </div>
      )}
    </div>
  )
}

export function Topbar() {
  const router = useRouter()
  return (
    <header className="sticky top-0 z-30 flex h-[72px] shrink-0 items-center gap-3 border-b border-line bg-surface/90 px-4 backdrop-blur md:px-6">
      <IconButton label="Open menu" icon={Menu} className="md:hidden" onClick={() => ui.set({ mobileOpen: true })} />
      <Breadcrumb />
      <div className="mx-auto flex flex-1 justify-center lg:justify-end"><GlobalSearch /></div>
      <div className="flex items-center gap-1">
        <Notifications />
        <IconButton label="Help" icon={HelpCircle} className="hidden sm:grid" onClick={() => router.push('/help-support')} />
        <button onClick={() => ui.set({ copilot: true })} className="ai-pulse ml-1 hidden h-10 items-center gap-2 rounded-lg bg-primary-light px-3 text-sm font-semibold text-primary transition-colors hover:bg-primary hover:text-white sm:flex"><Sparkles size={16} />NEXORA AI</button>
        <div className="ml-2"><ProfileMenu /></div>
      </div>
    </header>
  )
}
