'use client'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import { ChevronDown, ChevronsLeft, ChevronsRight, LogOut, Monitor, Moon, Sun, X, Hexagon } from 'lucide-react'
import { BOTTOM, NAV } from '@/lib/nav'
import { cn, Dropdown, toast } from '@/components/ui/core'
import { useTheme, type Theme } from '@/components/theme'
import { authStore } from '@/lib/session'
import { ui, useUI } from '@/lib/ui'

export function Logo({ compact }: { compact?: boolean }) {
  return (
    <span className="flex items-center gap-2.5">
      <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-primary to-purple text-white"><Hexagon size={18} strokeWidth={2.5} /></span>
      {!compact && <span className="text-[17px] font-bold tracking-[0.12em] text-heading">NEXORA</span>}
    </span>
  )
}

export function Sidebar() {
  const path = usePathname()
  const router = useRouter()
  const { collapsed, mobileOpen } = useUI()
  const { theme, setTheme } = useTheme()
  const [open, setOpen] = useState<Record<string, boolean>>({})
  const [ws, setWs] = useState('DTC Operations')
  const activeModule = path.split('/')[1]
  useEffect(() => { setOpen((o) => ({ ...o, [activeModule]: true })); ui.set({ mobileOpen: false }) }, [activeModule, path])
  const narrow = collapsed && !mobileOpen
  const signOut = () => { authStore.set((s) => ({ ...s, signedIn: false })); toast('You have been signed out.', 'info'); router.push('/login') }
  const THEMES: { t: Theme; icon: typeof Sun }[] = [{ t: 'light', icon: Sun }, { t: 'dark', icon: Moon }, { t: 'system', icon: Monitor }]

  const leaf = (name: string, href: string, Icon: typeof Sun) => {
    const active = path === href
    return (
      <Link key={href} href={href} title={narrow ? name : undefined} aria-current={active ? 'page' : undefined} className={cn('flex h-10 items-center gap-3 rounded-lg px-3 text-sm font-medium transition-colors', active ? 'bg-primary-light text-primary' : 'text-text hover:bg-hover hover:text-heading', narrow && 'justify-center px-0')}>
        <Icon size={18} className="shrink-0" />{!narrow && name}
      </Link>
    )
  }
  return (
    <>
      {mobileOpen && <div className="fixed inset-0 z-40 bg-slate-950/50 anim-fade md:hidden" onClick={() => ui.set({ mobileOpen: false })} />}
      <aside aria-label="Primary" className={cn('fixed inset-y-0 left-0 z-50 flex h-screen flex-col border-r border-line bg-surface transition-[width,transform] duration-300 md:sticky md:top-0 md:translate-x-0', narrow ? 'w-[256px] md:w-[76px]' : 'w-[256px]', mobileOpen ? 'translate-x-0' : '-translate-x-full')}>
        <div className={cn('flex h-[72px] shrink-0 items-center justify-between border-b border-line px-4', narrow && 'md:justify-center md:px-0')}>
          <Link href="/dashboard" aria-label="NEXORA home"><Logo compact={narrow} /></Link>
          <button aria-label="Close menu" className="grid size-9 place-items-center rounded-lg hover:bg-hover md:hidden" onClick={() => ui.set({ mobileOpen: false })}><X size={18} /></button>
        </div>
        {!narrow && (
          <div className="px-3 pt-3">
            <Dropdown align="left" label={ws} items={['DTC Operations', 'B2B Wholesale', 'Marketplace Ops'].map((w) => ({ label: w, onClick: () => { setWs(w); toast(`Switched to ${w}`, 'info') } }))}
              trigger={<span className="flex h-11 w-[232px] items-center gap-2 rounded-lg border border-line bg-surface-2 px-3 text-left text-sm font-semibold text-heading"><span className="grid size-6 place-items-center rounded-md bg-primary text-[11px] text-white">{ws[0]}</span><span className="flex-1 truncate">{ws}</span><ChevronDown size={16} className="text-text-2" /></span>} />
          </div>
        )}
        <nav className="scroll-thin min-h-0 flex-1 space-y-4 overflow-y-auto px-3 py-4" aria-label="Main">
          {NAV.map((g) => (
            <div key={g.label}>
              {!narrow ? <p className="mb-1.5 px-3 text-[11px] font-semibold uppercase tracking-wider text-muted">{g.label}</p> : <div className="mx-3 mb-2 border-t border-line" />}
              <div className="space-y-0.5">
                {g.leaves?.map((l) => leaf(l.name, l.href, l.icon))}
                {g.modules?.map((m) => {
                  const isActive = activeModule === m.slug
                  const isOpen = !!open[m.slug] && !narrow
                  const Icon = m.icon
                  if (narrow) return <Link key={m.slug} href={`/${m.slug}/overview`} title={m.name} className={cn('flex h-10 items-center justify-center rounded-lg transition-colors', isActive ? 'bg-primary-light text-primary' : 'text-text hover:bg-hover')}><Icon size={18} /></Link>
                  return (
                    <div key={m.slug}>
                      <button aria-expanded={isOpen} aria-controls={`sub-${m.slug}`} onClick={() => setOpen((o) => ({ ...o, [m.slug]: !o[m.slug] }))} className={cn('flex h-10 w-full items-center gap-3 rounded-lg px-3 text-sm font-medium transition-colors', isActive ? 'text-primary' : 'text-text hover:bg-hover hover:text-heading', isActive && 'bg-primary-light/60')}>
                        <Icon size={18} className="shrink-0" /><span className="flex-1 truncate text-left">{m.name}</span>
                        <ChevronDown size={16} className={cn('shrink-0 transition-transform duration-200', isOpen && 'rotate-180')} />
                      </button>
                      <div id={`sub-${m.slug}`} className={cn('grid transition-[grid-template-rows] duration-300 ease-out', isOpen ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]')}>
                        <div className="overflow-hidden">
                          <ul className="ml-[21px] mt-0.5 space-y-0.5 border-l border-line pb-1 pl-3">
                            {m.pages.map((p) => {
                              const href = `/${m.slug}/${p.slug}`
                              const act = path === href || (p.slug === 'overview' && path === `/${m.slug}`)
                              return <li key={p.slug}><Link href={href} tabIndex={isOpen ? 0 : -1} aria-current={act ? 'page' : undefined} className={cn('flex h-8 items-center rounded-md px-2.5 text-[13px] transition-colors', act ? 'bg-primary text-white font-medium' : 'text-text-2 hover:bg-hover hover:text-heading')}>{p.name}</Link></li>
                            })}
                          </ul>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          ))}
        </nav>
        <div className="shrink-0 space-y-0.5 border-t border-line p-3">
          {BOTTOM.map((l) => leaf(l.name, l.href, l.icon))}
          {!narrow ? (
            <div className="flex h-10 items-center justify-between rounded-lg px-3">
              <span className="text-sm font-medium text-text">Theme</span>
              <div role="radiogroup" aria-label="Theme" className="flex rounded-lg bg-hover p-0.5">
                {THEMES.map(({ t, icon: I }) => <button key={t} role="radio" aria-checked={theme === t} aria-label={`${t} theme`} onClick={() => setTheme(t)} className={cn('grid size-7 place-items-center rounded-md transition-colors', theme === t ? 'bg-surface text-primary shadow-xs' : 'text-text-2')}><I size={14} /></button>)}
              </div>
            </div>
          ) : (
            <button aria-label="Toggle theme" title="Theme" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} className="flex h-10 w-full items-center justify-center rounded-lg text-text hover:bg-hover">{theme === 'dark' ? <Moon size={18} /> : <Sun size={18} />}</button>
          )}
          <button onClick={signOut} title={narrow ? 'Sign Out' : undefined} className={cn('flex h-10 w-full items-center gap-3 rounded-lg px-3 text-sm font-medium text-danger transition-colors hover:bg-danger-bg', narrow && 'justify-center px-0')}><LogOut size={18} />{!narrow && 'Sign Out'}</button>
          <button aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'} onClick={() => ui.set({ collapsed: !collapsed })} className="hidden h-9 w-full items-center justify-center rounded-lg text-text-2 hover:bg-hover md:flex">{collapsed ? <ChevronsRight size={18} /> : <><ChevronsLeft size={18} /><span className="ml-2 text-[13px]">Collapse</span></>}</button>
        </div>
      </aside>
    </>
  )
}
