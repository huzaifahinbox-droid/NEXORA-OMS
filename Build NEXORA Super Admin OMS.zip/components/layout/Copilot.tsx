'use client'
import { usePathname, useRouter } from 'next/navigation'
import { useEffect, useRef, useState } from 'react'
import { Send, Sparkles, X } from 'lucide-react'
import { Button, cn, toast } from '@/components/ui/core'
import { db, dbStore, inventoryStatus, money, useDB } from '@/lib/db'
import { findModule } from '@/lib/nav'
import { ui, useUI } from '@/lib/ui'

interface Msg { role: 'user' | 'ai'; text: string; links?: { label: string; href: string }[]; confirm?: { label: string; run: () => void; state?: 'pending' | 'done' | 'cancelled' } }

const CONTEXT: Record<string, { name: string; prompts: string[] }> = {
  dashboard: { name: 'Command Center', prompts: ["Summarize today's operational risks.", 'What should I act on first?', 'Show delayed shipments.'] },
  'inventory-management': { name: 'Inventory', prompts: ['Which SKUs may stock out?', 'Show out of stock SKUs', 'What should I purchase?'] },
  'inventory-forecasting': { name: 'Forecasting', prompts: ['Which SKUs may stock out?', 'Predict demand risk', 'What should I purchase?'] },
  'logistics-management': { name: 'Logistics', prompts: ['Show delayed shipments.', 'Which carrier is worst?', 'Go to Delivery Not Happening'] },
  'delivery-not-happening': { name: 'Delivery', prompts: ['Show delayed shipments.', 'Recommend actions', 'Which carrier is worst?'] },
  vendors: { name: 'Vendors', prompts: ['Which vendors are underperforming?', 'Explain vendor risk', 'Go to Purchase Orders'] },
  'order-procurement': { name: 'Procurement', prompts: ['What should I purchase?', 'Which vendors are underperforming?', 'Show open purchase orders'] },
  'customer-support': { name: 'Support', prompts: ["Summarize this customer's issue.", 'Show escalated tickets', 'Which tickets breach SLA?'] },
  'order-management': { name: 'Orders', prompts: ['Show orders on hold', 'Mark ORD-10482 as shipped', 'Summarize order pipeline'] },
}

export function Copilot() {
  const { copilot } = useUI()
  const path = usePathname()
  const router = useRouter()
  const d = useDB()
  const key = path.split('/')[1] ?? 'dashboard'
  const ctx = CONTEXT[key] ?? { name: findModule(key)?.name ?? 'NEXORA', prompts: ["Summarize today's operational risks.", 'Which SKUs may stock out?', 'Show delayed shipments.'] }
  const [msgs, setMsgs] = useState<Msg[]>([])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const end = useRef<HTMLDivElement>(null)
  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth' }) }, [msgs, busy])
  useEffect(() => { if (copilot) document.getElementById('copilot-input')?.focus() }, [copilot])

  const answer = (qRaw: string): Msg => {
    const q = qRaw.toLowerCase()
    const s = dbStore.get()
    const low = s.inventory.filter((r) => inventoryStatus(r) !== 'In Stock')
    const delayed = s.shipments.filter((x) => ['Delayed', 'Failed'].includes(x.status))
    const m = qRaw.match(/ORD-\d+/i)
    if (m && /(ship|dispatch|advance|confirm|cancel)/.test(q)) {
      const o = s.orders.find((x) => x.id === m[0].toUpperCase())
      if (!o) return { role: 'ai', text: `I couldn't find ${m[0]}.` }
      const cancel = /cancel/.test(q)
      const to = cancel ? 'Cancelled' : /ship/.test(q) ? 'Shipped' : null
      return { role: 'ai', text: `${o.id} is currently ${o.status}. This will change live data${to === 'Shipped' ? ' (creates a shipment and releases reserved stock)' : ''}. Please confirm.`, confirm: { label: `${cancel ? 'Cancel' : to === 'Shipped' ? 'Mark shipped' : 'Advance'} ${o.id}`, state: 'pending', run: () => (to ? db.setOrderStatus(o.id, to) : db.advanceOrder(o.id)) } }
    }
    const nav = q.match(/(?:go to|open|navigate to|take me to)\s+(.+)/)
    if (nav) {
      const t = nav[1].replace(/[.?!]/g, '').trim()
      const flat = [{ n: 'Dashboard', h: '/dashboard' }, { n: 'AI Insights', h: '/ai-insights' }, { n: 'Settings', h: '/settings' }, { n: 'Notifications', h: '/notifications' }, { n: 'Audit Logs', h: '/audit-logs' }]
      const hit = flat.find((f) => f.n.toLowerCase().includes(t)) ?? (() => { for (const mod of [findModule(t.replace(/\s+/g, '-'))]) if (mod) return { n: mod.name, h: `/${mod.slug}/overview` } })() ?? findAny(t)
      if (hit) { setTimeout(() => router.push(hit.h), 400); return { role: 'ai', text: `Taking you to ${hit.n}.`, links: [{ label: hit.n, href: hit.h }] } }
    }
    if (/stock ?out|low stock|out of stock|inventory|sku/.test(q)) {
      const rows = low.slice(0, 5).map((r) => `• ${r.sku} @ ${r.warehouse}: ${r.available} available (reorder ${r.reorder}) — ${inventoryStatus(r)}`).join('\n')
      return { role: 'ai', text: `${low.length} stock positions need attention. SKU-2048 in Chennai is projected to stock out in ~4 days (91% confidence).\n${rows}`, links: [{ label: 'Open Low Stock', href: '/inventory-management/low-stock' }] }
    }
    if (/delay|late|shipment|carrier|sla|deliver/.test(q)) {
      const by: Record<string, number> = {}; delayed.forEach((x) => (by[x.carrier] = (by[x.carrier] ?? 0) + 1))
      const worst = Object.entries(by).sort((a, b) => b[1] - a[1])[0]
      return { role: 'ai', text: `${delayed.length} shipments are delayed or failed${worst ? `; ${worst[0]} accounts for ${worst[1]} of them` : ''}.\n${delayed.slice(0, 4).map((x) => `• ${x.id} → ${x.destination} (${x.issue ?? x.status})`).join('\n')}\nRecommendation: switch eligible lanes to a backup carrier and contact affected customers.`, links: [{ label: 'Delayed deliveries', href: '/delivery-not-happening/delayed-deliveries' }] }
    }
    if (/vendor|supplier|underperform/.test(q)) {
      const bad = s.vendors.filter((v) => v.reliability < 90 || v.risk !== 'Low')
      return { role: 'ai', text: `${bad.length} vendors need review:\n${bad.map((v) => `• ${v.name} — reliability ${v.reliability}%, lead time ${v.leadTime}d, risk ${v.risk}`).join('\n')}`, links: [{ label: 'Vendor performance', href: '/vendors/vendor-performance' }] }
    }
    if (/purchase|procure|reorder|buy/.test(q)) {
      const need = low.slice(0, 4)
      return { role: 'ai', text: `Recommended purchases:\n${need.map((r) => `• ${r.sku}: order ${Math.max(100, r.reorder * 3 - r.available)} units`).join('\n')}\nSKU-2048 is the highest priority.`, links: [{ label: 'Reorder recommendations', href: '/inventory-forecasting/reorder-recommendations' }] }
    }
    if (/ticket|customer|support|issue/.test(q)) {
      const t = s.tickets.filter((x) => x.status === 'Escalated' || x.breached)
      return { role: 'ai', text: `${t.length} tickets are escalated or past SLA. Most common theme: “${t[0]?.issue ?? 'delivery status'}”. Sentiment is trending negative on delivery delays.\n${t.slice(0, 3).map((x) => `• ${x.id} ${x.customer} — ${x.issue}`).join('\n')}`, links: [{ label: 'Escalated tickets', href: '/customer-support/escalated-tickets' }] }
    }
    if (/hold|order|pipeline/.test(q)) {
      const hold = s.orders.filter((o) => o.status === 'On Hold')
      const count = (st: string) => s.orders.filter((o) => o.status === st).length
      return { role: 'ai', text: `Pipeline: ${count('New')} new, ${count('Picking')} picking, ${count('Packed')} packed, ${count('Shipped')} shipped. ${hold.length} orders are on hold (${hold.slice(0, 3).map((o) => o.id).join(', ')}).`, links: [{ label: 'On hold', href: '/order-management/on-hold' }] }
    }
    if (/risk|summar|today|act on|first|predict|recommend|explain/.test(q)) {
      const top = s.insights.filter((i) => i.status === 'New').slice(0, 3)
      const revenue = s.orders.filter((o) => !['Cancelled'].includes(o.status)).reduce((a, o) => a + o.total, 0)
      return { role: 'ai', text: `Today: ${delayed.length} delayed/failed shipments, ${low.length} stock risks, ${s.tickets.filter((t) => t.breached).length} SLA-breached tickets. Open order value ${money(revenue)}.\nTop AI insights:\n${top.map((i) => `• ${i.title} (${i.confidence}% confidence) — ${i.recommendation}`).join('\n')}`, links: [{ label: 'Open AI Insights', href: '/ai-insights' }] }
    }
    const t = qRaw.trim().toLowerCase()
    const hits = [...s.orders.filter((o) => o.id.toLowerCase().includes(t)).map((o) => `${o.id} (${o.status})`), ...s.customers.filter((c) => c.name.toLowerCase().includes(t)).map((c) => c.name), ...s.products.filter((p) => p.name.toLowerCase().includes(t) || p.sku.toLowerCase() === t).map((p) => `${p.sku} ${p.name}`)]
    if (hits.length) return { role: 'ai', text: `Search results:\n${hits.slice(0, 6).map((h) => `• ${h}`).join('\n')}` }
    return { role: 'ai', text: `I can search, filter, navigate, summarize, analyze, predict and recommend across ${ctx.name}. Try one of the suggestions below.` }
  }

  const send = (text: string) => {
    if (!text.trim() || busy) return
    setMsgs((m) => [...m, { role: 'user', text }]); setInput(''); setBusy(true)
    setTimeout(() => { setMsgs((m) => [...m, answer(text)]); setBusy(false) }, 650)
  }
  const resolve = (i: number, ok: boolean) => {
    const c = msgs[i].confirm
    if (!c) return
    if (ok) { c.run(); toast('Action completed') }
    setMsgs((m) => m.map((x, j) => (j === i ? { ...x, confirm: { ...c, state: ok ? 'done' : 'cancelled' } } : x)))
  }

  return (
    <>
      {!copilot && <button aria-label="Open NEXORA AI" onClick={() => ui.set({ copilot: true })} className="ai-pulse fixed bottom-5 right-5 z-40 flex h-12 items-center gap-2 rounded-full bg-gradient-to-r from-primary to-purple px-5 text-sm font-semibold text-white shadow-pop transition-transform hover:scale-105 sm:hidden md:flex"><Sparkles size={18} />NEXORA AI</button>}
      {copilot && (
        <div role="dialog" aria-label="NEXORA AI Copilot" className="anim-slide fixed inset-0 z-[70] flex flex-col bg-surface sm:inset-auto sm:bottom-5 sm:right-5 sm:h-[620px] sm:max-h-[calc(100vh-40px)] sm:w-[420px] sm:rounded-2xl sm:border sm:border-line sm:shadow-pop">
          <div className="flex items-center gap-3 border-b border-line px-5 py-4">
            <span className="ai-pulse grid size-9 place-items-center rounded-xl bg-gradient-to-br from-primary to-purple text-white"><Sparkles size={17} /></span>
            <div className="flex-1"><p className="font-semibold text-heading">NEXORA AI</p><p className="text-xs text-text-2">Context: {ctx.name}</p></div>
            <button aria-label="Close copilot" onClick={() => ui.set({ copilot: false })} className="grid size-9 place-items-center rounded-lg text-text-2 hover:bg-hover"><X size={18} /></button>
          </div>
          <div className="scroll-thin flex-1 space-y-4 overflow-y-auto p-5" aria-live="polite">
            {msgs.length === 0 && <div className="rounded-xl bg-surface-2 p-4 text-sm text-text">Hi Aditi, I’m looking at <b className="text-heading">{ctx.name}</b>. Ask me to search, summarize, predict or take action — I’ll always ask before changing data.</div>}
            {msgs.map((m, i) => (
              <div key={i} className={cn('flex', m.role === 'user' && 'justify-end')}>
                <div className={cn('max-w-[88%] whitespace-pre-line rounded-2xl px-4 py-2.5 text-sm', m.role === 'user' ? 'bg-primary text-white' : 'bg-surface-2 text-text')}>
                  {m.text}
                  {m.links && <div className="mt-2 flex flex-wrap gap-2">{m.links.map((l) => <button key={l.href} onClick={() => { router.push(l.href); if (window.innerWidth < 640) ui.set({ copilot: false }) }} className="rounded-md bg-primary-light px-2.5 py-1 text-xs font-medium text-primary hover:underline">{l.label} →</button>)}</div>}
                  {m.confirm && (m.confirm.state === 'pending' ? <div className="mt-3 flex gap-2"><Button size="sm" variant="primary" onClick={() => resolve(i, true)}>{m.confirm.label}</Button><Button size="sm" onClick={() => resolve(i, false)}>Cancel</Button></div> : <p className="mt-2 text-xs font-semibold">{m.confirm.state === 'done' ? '✓ Done' : 'Cancelled'}</p>)}
                </div>
              </div>
            ))}
            {busy && <div className="flex gap-1 px-2" aria-label="NEXORA AI is thinking">{[0, 1, 2].map((i) => <span key={i} className="size-2 animate-bounce rounded-full bg-primary" style={{ animationDelay: `${i * 120}ms` }} />)}</div>}
            <div ref={end} />
          </div>
          <div className="border-t border-line p-4">
            <div className="mb-3 flex flex-wrap gap-2">{ctx.prompts.map((p) => <button key={p} onClick={() => send(p)} className="rounded-full border border-line px-3 py-1 text-xs text-text hover:border-primary hover:text-primary">{p}</button>)}</div>
            <form onSubmit={(e) => { e.preventDefault(); send(input) }} className="flex gap-2">
              <input id="copilot-input" aria-label="Ask NEXORA AI" value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask anything about your operation…" className="h-10 flex-1 rounded-lg border border-line-strong bg-surface px-3 text-sm text-heading placeholder:text-muted focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30" />
              <Button type="submit" variant="primary" aria-label="Send" disabled={!input.trim()}><Send size={16} /></Button>
            </form>
          </div>
        </div>
      )}
    </>
  )
}

import { MODULES } from '@/lib/nav'
function findAny(t: string) {
  for (const m of MODULES) {
    const p = m.pages.find((x) => x.name.toLowerCase().includes(t))
    if (p) return { n: p.name, h: `/${m.slug}/${p.slug}` }
    if (m.name.toLowerCase().includes(t)) return { n: m.name, h: `/${m.slug}/overview` }
  }
  return null
}
