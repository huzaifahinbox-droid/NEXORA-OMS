'use client'
import Link from 'next/link'
import { useState, type ReactNode } from 'react'
import { Boxes, Eye, EyeOff, Monitor, Moon, Package, Sun, Truck, Warehouse, Sparkles } from 'lucide-react'
import { Logo } from '@/components/layout/Sidebar'
import { useTheme, type Theme } from '@/components/theme'
import { cn, Field } from '@/components/ui/core'

export function ThemeToggle() {
  const { theme, setTheme } = useTheme()
  const opts: { t: Theme; icon: typeof Sun; label: string }[] = [{ t: 'light', icon: Sun, label: 'Light' }, { t: 'dark', icon: Moon, label: 'Dark' }, { t: 'system', icon: Monitor, label: 'System' }]
  return (
    <div role="group" aria-label="Theme" className="inline-flex gap-0.5 rounded-lg border border-line bg-surface p-0.5">
      {opts.map(({ t, icon: I, label }) => (
        <button key={t} type="button" aria-label={`${label} theme`} aria-pressed={theme === t} onClick={() => setTheme(t)} className={cn('grid size-8 place-items-center rounded-md transition-colors', theme === t ? 'bg-primary-light text-primary' : 'text-text-2 hover:text-heading')}><I size={15} /></button>
      ))}
    </div>
  )
}

const NODES = [
  { icon: Package, label: 'Orders', x: 8, y: 22 }, { icon: Boxes, label: 'Inventory', x: 50, y: 8 }, { icon: Warehouse, label: 'Warehouse', x: 50, y: 70 },
  { icon: Truck, label: 'Shipping', x: 92, y: 22 }, { icon: Sparkles, label: 'AI Insights', x: 92, y: 78 },
]
function WorkflowVisual() {
  return (
    <div className="relative mx-auto h-72 w-full max-w-md" aria-hidden>
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 size-full">
        {[[0, 1], [1, 3], [0, 2], [2, 3], [2, 4], [3, 4]].map(([a, b], i) => (
          <line key={i} x1={NODES[a].x} y1={NODES[a].y} x2={NODES[b].x} y2={NODES[b].y} stroke="rgb(255 255 255 / 0.45)" strokeWidth="0.5" vectorEffect="non-scaling-stroke" className="flow-line" />
        ))}
      </svg>
      {NODES.map((n, i) => (
        <div key={n.label} className="anim-float absolute -translate-x-1/2 -translate-y-1/2" style={{ left: `${n.x}%`, top: `${n.y}%`, animationDelay: `${i * 0.7}s` }}>
          <div className="flex items-center gap-2 rounded-xl border border-white/25 bg-white/15 px-3 py-2 text-xs font-medium text-white backdrop-blur">
            <n.icon size={16} /><span className="node-glow" style={{ animationDelay: `${i * 0.4}s` }}>{n.label}</span>
          </div>
        </div>
      ))}
    </div>
  )
}

export function AuthShell({ children, title, subtitle, wide }: { children: ReactNode; title?: string; subtitle?: string; wide?: boolean }) {
  return (
    <div className="grid min-h-screen bg-bg lg:grid-cols-[minmax(0,5fr)_minmax(0,6fr)]">
      <aside className="relative hidden overflow-hidden bg-gradient-to-br from-indigo-700 via-indigo-600 to-purple p-10 text-white lg:flex lg:flex-col lg:justify-between" aria-label="NEXORA overview">
        <div className="pointer-events-none absolute -right-24 -top-24 size-96 rounded-full bg-white/10 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-32 -left-16 size-96 rounded-full bg-cyan/20 blur-3xl" />
        <span className="relative flex items-center gap-2.5 text-[17px] font-bold tracking-[0.12em]"><span className="grid size-9 place-items-center rounded-xl bg-white/20">N</span>NEXORA</span>
        <div className="relative space-y-8">
          <WorkflowVisual />
          <div>
            <h2 className="text-3xl font-bold leading-tight">One command center for every order, unit and shipment.</h2>
            <p className="mt-3 max-w-md text-sm text-white/80">AI-powered order management that keeps inventory, fulfilment and logistics in sync across all your channels.</p>
          </div>
        </div>
        <p className="relative text-xs text-white/60">© 2026 NEXORA. All rights reserved.</p>
      </aside>
      <main className="flex min-h-screen flex-col">
        <header className="flex items-center justify-between px-5 py-4 sm:px-8">
          <Link href="/login" aria-label="NEXORA" className="lg:invisible"><Logo /></Link>
          <ThemeToggle />
        </header>
        <div className="flex flex-1 items-center justify-center px-5 pb-10 sm:px-8">
          <div className={cn('anim-fade w-full', wide ? 'max-w-lg' : 'max-w-[420px]')}>
            {title && <div className="mb-7"><h1 className="text-[28px] font-bold leading-tight text-heading sm:text-[32px]">{title}</h1>{subtitle && <p className="mt-2 text-sm text-text-2">{subtitle}</p>}</div>}
            {children}
          </div>
        </div>
      </main>
    </div>
  )
}

export function passwordScore(p: string) {
  let n = 0
  if (p.length >= 8) n++
  if (/[A-Z]/.test(p) && /[a-z]/.test(p)) n++
  if (/\d/.test(p)) n++
  if (/[^A-Za-z0-9]/.test(p)) n++
  return n
}
export function Strength({ value }: { value: string }) {
  if (!value) return null
  const n = passwordScore(value)
  const label = ['Too weak', 'Weak', 'Fair', 'Good', 'Strong'][n]
  const color = n <= 1 ? 'bg-danger' : n === 2 ? 'bg-warning' : 'bg-success'
  return (
    <div className="mt-2" aria-live="polite">
      <div className="flex gap-1">{[1, 2, 3, 4].map((i) => <span key={i} className={cn('h-1.5 flex-1 rounded-full transition-colors', i <= n ? color : 'bg-hover')} />)}</div>
      <p className="mt-1 text-xs text-text-2">Password strength: {label}</p>
    </div>
  )
}
export function PasswordField({ label, value, onChange, error, strength, autoComplete, placeholder, hint }: { label: string; value: string; onChange: (v: string) => void; error?: string; strength?: boolean; autoComplete?: string; placeholder?: string; hint?: string }) {
  const [show, setShow] = useState(false)
  return (
    <div>
      <Field label={label} error={error} hint={hint}>
        {(id) => (
          <div className="relative">
            <input id={id} type={show ? 'text' : 'password'} value={value} onChange={(e) => onChange(e.target.value)} autoComplete={autoComplete} placeholder={placeholder} aria-invalid={!!error} className={cn('h-10 w-full rounded-lg border border-line-strong bg-surface px-3 pr-10 text-sm text-heading placeholder:text-muted transition-colors focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30', error && 'border-danger')} />
            <button type="button" aria-label={show ? 'Hide password' : 'Show password'} onClick={() => setShow(!show)} className="absolute right-1 top-1/2 grid size-8 -translate-y-1/2 place-items-center rounded-md text-text-2 hover:text-heading">{show ? <EyeOff size={16} /> : <Eye size={16} />}</button>
          </div>
        )}
      </Field>
      {strength && <Strength value={value} />}
    </div>
  )
}
export const GoogleIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden><path fill="#4285F4" d="M22.5 12.3c0-.8-.1-1.5-.2-2.2H12v4.2h5.9a5 5 0 0 1-2.2 3.3v2.7h3.5c2.1-1.9 3.3-4.7 3.3-8z" /><path fill="#34A853" d="M12 23c3 0 5.4-1 7.2-2.7l-3.5-2.7c-1 .7-2.2 1-3.7 1-2.8 0-5.2-1.9-6-4.5H2.4v2.8A11 11 0 0 0 12 23z" /><path fill="#FBBC05" d="M6 14.1a6.6 6.6 0 0 1 0-4.2V7.1H2.4a11 11 0 0 0 0 9.8L6 14.1z" /><path fill="#EA4335" d="M12 5.4c1.6 0 3 .6 4.2 1.6l3.1-3.1A11 11 0 0 0 2.4 7.1L6 9.9c.8-2.6 3.2-4.5 6-4.5z" /></svg>
)
export const isEmail = (v: string) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim())
