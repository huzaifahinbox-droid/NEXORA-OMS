'use client'
import { useEffect, useId, useRef, useState, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes } from 'react'
import { AlertTriangle, ArrowDown, ArrowUp, ArrowUpDown, CheckCircle2, ChevronDown, ChevronLeft, ChevronRight, Info, Loader2, Search, X, type LucideIcon, Inbox } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { createStore } from '@/lib/store'

import { cn } from '@/lib/cn'
export { cn }

/* ---------- Button ---------- */
type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'ghost' | 'danger'; size?: 'sm' | 'md' | 'lg'; loading?: boolean; icon?: LucideIcon }
const BTN = {
  primary: 'bg-primary text-white hover:bg-primary-hover shadow-xs',
  secondary: 'bg-surface text-heading border border-line-strong hover:bg-hover',
  ghost: 'text-text hover:bg-hover',
  danger: 'bg-danger text-white hover:opacity-90 dark:text-slate-900',
}
export function Button({ variant = 'secondary', size = 'md', loading, icon: Icon, children, className, disabled, ...p }: BtnProps) {
  return (
    <button disabled={disabled || loading} className={cn('inline-flex items-center justify-center gap-2 rounded-lg font-medium whitespace-nowrap transition-all duration-150 active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none', size === 'sm' ? 'h-8 px-3 text-[13px]' : size === 'lg' ? 'h-11 px-6 text-[15px]' : 'h-10 px-4 text-sm', BTN[variant], className)} {...p}>
      {loading ? <Loader2 size={16} className="animate-spin" /> : Icon ? <Icon size={16} /> : null}
      {children}
    </button>
  )
}
export function IconButton({ label, icon: Icon, className, ...p }: ButtonHTMLAttributes<HTMLButtonElement> & { label: string; icon: LucideIcon }) {
  return <button aria-label={label} title={label} className={cn('grid size-10 place-items-center rounded-lg text-text-2 transition-colors hover:bg-hover hover:text-heading', className)} {...p}><Icon size={18} /></button>
}

/* ---------- Card / Badge ---------- */
export function Card({ className, children, hover, ...p }: { className?: string; children: ReactNode; hover?: boolean } & React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('rounded-xl border border-line bg-surface shadow-xs', hover && 'transition-colors hover:border-line-strong', className)} {...p}>{children}</div>
}
export function CardHeader({ title, sub, action }: { title: string; sub?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-wrap items-start justify-between gap-3 px-5 pt-5">
      <div className="min-w-0"><h3 className="text-[15px] font-semibold text-heading">{title}</h3>{sub && <p className="mt-0.5 text-[13px] text-text-2">{sub}</p>}</div>
      {action}
    </div>
  )
}
export type Tone = 'success' | 'warning' | 'danger' | 'info' | 'neutral' | 'primary'
const TONES: Record<Tone, string> = { success: 'bg-success-bg text-success', warning: 'bg-warning-bg text-warning', danger: 'bg-danger-bg text-danger', info: 'bg-info-bg text-info', neutral: 'bg-hover text-text', primary: 'bg-primary-light text-primary' }
export function Badge({ tone = 'neutral', children, dot }: { tone?: Tone; children: ReactNode; dot?: boolean }) {
  return <span className={cn('inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-medium', TONES[tone])}>{dot && <span className="size-1.5 rounded-full bg-current" />}{children}</span>
}
const MAP: [RegExp, Tone][] = [
  [/deliver|settled|paid|approved|active|healthy|connected|verified|completed|received|resolved|done|in stock|low$|on track|high value|vip|applied|converted|on-time/i, 'success'],
  [/delay|breach|fail|overdue|critical|reject|cancel|out of stock|escalat|urgent|suspend|high$|refused|error|returned|at risk|refunded|unassigned/i, 'danger'],
  [/hold|pending|low stock|medium|invited|attention|requested|draft|due|inactive|new$/i, 'warning'],
  [/ship|transit|picking|packed|allocated|confirmed|processing|open|sent|scheduled|out for|in progress|reviewed|returning|testing/i, 'info'],
]
export const toneFor = (s: string): Tone => MAP.find(([r]) => r.test(s))?.[1] ?? 'neutral'
export const StatusBadge = ({ s }: { s: string }) => <Badge tone={toneFor(s)} dot>{s}</Badge>

/* ---------- Forms ---------- */
export function Field({ label, error, hint, children, required }: { label: string; error?: string; hint?: string; children: (id: string) => ReactNode; required?: boolean }) {
  const id = useId()
  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="block text-[13px] font-medium text-heading">{label}{required && <span className="text-danger"> *</span>}</label>
      {children(id)}
      {error ? <p role="alert" className="text-xs text-danger">{error}</p> : hint ? <p className="text-xs text-text-2">{hint}</p> : null}
    </div>
  )
}
const ctl = 'h-10 w-full rounded-lg border border-line-strong bg-surface px-3 text-sm text-heading placeholder:text-muted transition-colors focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30'
export function Input({ label, error, hint, required, className, ...p }: InputHTMLAttributes<HTMLInputElement> & { label: string; error?: string; hint?: string }) {
  return <Field label={label} error={error} hint={hint} required={required}>{(id) => <input id={id} aria-invalid={!!error} className={cn(ctl, error && 'border-danger', className)} {...p} />}</Field>
}
export function Select({ label, error, options, required, ...p }: SelectHTMLAttributes<HTMLSelectElement> & { label: string; error?: string; options: string[] }) {
  return <Field label={label} error={error} required={required}>{(id) => <select id={id} className={cn(ctl, error && 'border-danger')} {...p}><option value="">Select…</option>{options.map((o) => <option key={o}>{o}</option>)}</select>}</Field>
}
export function Textarea({ label, ...p }: TextareaHTMLAttributes<HTMLTextAreaElement> & { label: string }) {
  return <Field label={label}>{(id) => <textarea id={id} rows={3} className={cn(ctl, 'h-auto py-2')} {...p} />}</Field>
}
export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button type="button" role="switch" aria-checked={checked} aria-label={label} onClick={() => onChange(!checked)} className={cn('relative h-6 w-11 shrink-0 rounded-full transition-colors duration-200', checked ? 'bg-primary' : 'bg-line-strong')}>
      <span className={cn('absolute left-0.5 top-0.5 size-5 rounded-full bg-white shadow transition-transform duration-200', checked && 'translate-x-5')} />
    </button>
  )
}
export function SearchBox({ value, onChange, placeholder = 'Search…', className }: { value: string; onChange: (v: string) => void; placeholder?: string; className?: string }) {
  return (
    <div className={cn('relative', className)}>
      <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
      <input aria-label={placeholder} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className={cn(ctl, 'pl-9')} />
    </div>
  )
}

/* ---------- Tabs / Segmented ---------- */
export function Tabs<T extends string>({ value, onChange, options, className }: { value: T; onChange: (v: T) => void; options: readonly T[]; className?: string }) {
  return (
    <div role="tablist" className={cn('inline-flex max-w-full gap-1 overflow-x-auto rounded-lg bg-hover p-1 scroll-thin', className)}>
      {options.map((o) => (
        <button key={o} role="tab" aria-selected={value === o} onClick={() => onChange(o)} className={cn('h-8 whitespace-nowrap rounded-md px-3 text-[13px] font-medium transition-all duration-150', value === o ? 'bg-surface text-heading shadow-xs' : 'text-text-2 hover:text-heading')}>{o}</button>
      ))}
    </div>
  )
}

/* ---------- Modal / Dropdown ---------- */
export function Modal({ open, onClose, title, children, footer, wide }: { open: boolean; onClose: () => void; title: string; children: ReactNode; footer?: ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!open) return
    const prev = document.activeElement as HTMLElement | null
    const first = ref.current?.querySelector<HTMLElement>('input,select,textarea,button:not([aria-label="Close"])')
    first?.focus()
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
      if (e.key === 'Tab' && ref.current) {
        const f = [...ref.current.querySelectorAll<HTMLElement>('a,button,input,select,textarea,[tabindex]:not([tabindex="-1"])')].filter((x) => !x.hasAttribute('disabled'))
        if (!f.length) return
        const a = f[0], b = f[f.length - 1]
        if (e.shiftKey && document.activeElement === a) { e.preventDefault(); b.focus() } else if (!e.shiftKey && document.activeElement === b) { e.preventDefault(); a.focus() }
      }
    }
    document.addEventListener('keydown', key)
    return () => { document.removeEventListener('keydown', key); prev?.focus() }
  }, [open, onClose])
  if (!open) return null
  return (
    <div className="fixed inset-0 z-[80] grid place-items-center p-4">
      <div className="absolute inset-0 bg-slate-950/50 anim-fade" onClick={onClose} />
      <div ref={ref} role="dialog" aria-modal="true" aria-label={title} className={cn('anim-pop relative flex max-h-[90vh] w-full flex-col rounded-2xl border border-line bg-surface shadow-pop', wide ? 'max-w-2xl' : 'max-w-md')}>
        <div className="flex items-center justify-between border-b border-line px-6 py-4"><h2 className="text-lg font-semibold text-heading">{title}</h2><IconButton label="Close" icon={X} onClick={onClose} className="-mr-2 size-8" /></div>
        <div className="overflow-y-auto px-6 py-5">{children}</div>
        {footer && <div className="flex justify-end gap-2 border-t border-line px-6 py-4">{footer}</div>}
      </div>
    </div>
  )
}
export function ConfirmDialog({ open, title, body, confirmLabel = 'Confirm', danger, onConfirm, onClose }: { open: boolean; title: string; body: string; confirmLabel?: string; danger?: boolean; onConfirm: () => void; onClose: () => void }) {
  return (
    <Modal open={open} onClose={onClose} title={title} footer={<><Button onClick={onClose}>Cancel</Button><Button variant={danger ? 'danger' : 'primary'} onClick={() => { onConfirm(); onClose() }}>{confirmLabel}</Button></>}>
      <p className="text-sm text-text">{body}</p>
    </Modal>
  )
}
export function useOutside(onOut: () => void) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const d = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) onOut() }
    const k = (e: KeyboardEvent) => e.key === 'Escape' && onOut()
    document.addEventListener('mousedown', d); document.addEventListener('keydown', k)
    return () => { document.removeEventListener('mousedown', d); document.removeEventListener('keydown', k) }
  })
  return ref
}
export function Dropdown({ label, items, align = 'right', trigger, icon: Icon }: { label: string; items: { label: string; onClick: () => void; danger?: boolean }[]; align?: 'left' | 'right'; trigger?: ReactNode; icon?: LucideIcon }) {
  const [open, setOpen] = useState(false)
  const ref = useOutside(() => setOpen(false))
  return (
    <div ref={ref} className="relative">
      <button aria-haspopup="menu" aria-expanded={open} onClick={() => setOpen(!open)} className={trigger ? '' : 'inline-flex h-10 items-center gap-2 rounded-lg border border-line-strong bg-surface px-3 text-sm font-medium text-heading transition-colors hover:bg-hover'}>
        {trigger ?? <>{Icon && <Icon size={16} />}{label}<ChevronDown size={16} className={cn('transition-transform duration-200', open && 'rotate-180')} /></>}
      </button>
      {open && (
        <div role="menu" className={cn('anim-pop absolute z-50 mt-2 min-w-44 rounded-xl border border-line bg-surface p-1 shadow-pop', align === 'right' ? 'right-0' : 'left-0')}>
          {items.map((it) => <button key={it.label} role="menuitem" onClick={() => { it.onClick(); setOpen(false) }} className={cn('flex w-full items-center rounded-lg px-3 py-2 text-left text-sm hover:bg-hover', it.danger ? 'text-danger' : 'text-text')}>{it.label}</button>)}
        </div>
      )}
    </div>
  )
}

/* ---------- States ---------- */
export function Skeleton({ className }: { className?: string }) { return <div className={cn('skeleton', className)} aria-hidden /> }
export function PageSkeleton() {
  return (
    <div className="space-y-6" role="status" aria-label="Loading">
      <div className="space-y-2"><Skeleton className="h-8 w-64" /><Skeleton className="h-4 w-96 max-w-full" /></div>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-28" />)}</div>
      <Skeleton className="h-72" />
      <div className="space-y-2">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-11" />)}</div>
    </div>
  )
}
export function EmptyState({ icon: Icon = Inbox, title, body, cta, onCta }: { icon?: LucideIcon; title: string; body: string; cta?: string; onCta?: () => void }) {
  return (
    <div className="flex flex-col items-center px-6 py-14 text-center">
      <div className="mb-4 grid size-12 place-items-center rounded-full bg-primary-light text-primary"><Icon size={22} /></div>
      <h3 className="text-base font-semibold text-heading">{title}</h3>
      <p className="mt-1 max-w-sm text-sm text-text-2">{body}</p>
      {cta && <Button variant="primary" className="mt-5" onClick={onCta}>{cta}</Button>}
    </div>
  )
}
export function ErrorState({ onRetry }: { onRetry?: () => void }) {
  const router = useRouter()
  return (
    <Card className="flex flex-col items-center px-6 py-16 text-center" role="alert">
      <div className="mb-4 grid size-12 place-items-center rounded-full bg-danger-bg text-danger"><AlertTriangle size={22} /></div>
      <h3 className="text-lg font-semibold text-heading">Something went wrong.</h3>
      <p className="mt-1 text-sm text-text-2">Unable to load this information.</p>
      <div className="mt-5 flex gap-2"><Button variant="primary" onClick={onRetry}>Retry</Button><Button onClick={() => router.back()}>Go Back</Button></div>
    </Card>
  )
}
export function Progress({ value, tone = 'primary' }: { value: number; tone?: 'primary' | 'success' | 'warning' | 'danger' }) {
  const c = { primary: 'bg-primary', success: 'bg-success', warning: 'bg-warning', danger: 'bg-danger' }[tone]
  return <div className="h-2 w-full overflow-hidden rounded-full bg-hover" role="progressbar" aria-valuenow={value} aria-valuemin={0} aria-valuemax={100}><div className={cn('h-full rounded-full transition-[width] duration-500 ease-out', c)} style={{ width: `${Math.min(100, value)}%` }} /></div>
}

/* ---------- Toast ---------- */
interface T { id: number; msg: string; tone: 'success' | 'danger' | 'info' }
const toasts = createStore<{ list: T[] }>('nexora-toast', () => ({ list: [] }), false)
export function toast(msg: string, tone: T['tone'] = 'success') {
  const id = Date.now() + Math.random()
  toasts.set((s) => ({ list: [...s.list, { id, msg, tone }] }))
  setTimeout(() => toasts.set((s) => ({ list: s.list.filter((x) => x.id !== id) })), 3600)
}
export function Toaster() {
  const { list } = toasts.use()
  return (
    <div className="pointer-events-none fixed bottom-5 left-1/2 z-[100] flex -translate-x-1/2 flex-col gap-2 sm:left-auto sm:right-5 sm:translate-x-0" aria-live="polite">
      {list.map((t) => (
        <div key={t.id} className="anim-slide pointer-events-auto flex items-center gap-3 rounded-xl border border-line bg-surface px-4 py-3 text-sm text-heading shadow-pop">
          {t.tone === 'success' ? <CheckCircle2 size={18} className="text-success" /> : t.tone === 'danger' ? <AlertTriangle size={18} className="text-danger" /> : <Info size={18} className="text-info" />}
          {t.msg}
        </div>
      ))}
    </div>
  )
}

/* ---------- DataTable ---------- */
export const hint = { q: '', at: 0 }
export interface Col<T> { key: string; label: string; render?: (r: T) => ReactNode; sort?: (r: T) => string | number; align?: 'right'; className?: string }
export function DataTable<T extends { id: string }>({ rows, cols, searchOf, pageSize = 8, toolbar, onRow, empty, actions, filters }: {
  rows: T[]; cols: Col<T>[]; searchOf?: (r: T) => string; pageSize?: number; toolbar?: ReactNode; onRow?: (r: T) => void
  empty?: { title: string; body: string; cta?: string; onCta?: () => void }; actions?: (r: T) => ReactNode; filters?: ReactNode
}) {
  const [q, setQ] = useState(() => (Date.now() - hint.at < 4000 ? hint.q : ''))
  const [sort, setSort] = useState<{ key: string; dir: 1 | -1 } | null>(null)
  const [page, setPage] = useState(0)
  let data = rows
  if (q && searchOf) data = data.filter((r) => searchOf(r).toLowerCase().includes(q.toLowerCase()))
  if (sort) {
    const c = cols.find((x) => x.key === sort.key)
    const get = c?.sort ?? ((r: T) => (r as Record<string, never>)[sort.key] as string | number)
    data = [...data].sort((a, b) => { const x = get(a), y = get(b); return (x > y ? 1 : x < y ? -1 : 0) * sort.dir })
  }
  const pages = Math.max(1, Math.ceil(data.length / pageSize))
  const cur = Math.min(page, pages - 1)
  const slice = data.slice(cur * pageSize, cur * pageSize + pageSize)
  return (
    <Card className="overflow-hidden">
      {(searchOf || toolbar || filters) && (
        <div className="flex flex-wrap items-center gap-3 border-b border-line p-4">
          {searchOf && <SearchBox value={q} onChange={(v) => { setQ(v); setPage(0) }} className="w-full sm:w-72" />}
          {filters}
          <div className="ml-auto flex items-center gap-2">{toolbar}</div>
        </div>
      )}
      {data.length === 0 ? (
        <EmptyState title={q ? 'No results found' : empty?.title ?? 'Nothing here yet'} body={q ? `No records match “${q}”. Try a different search.` : empty?.body ?? 'Records will appear here.'} cta={q ? 'Clear search' : empty?.cta} onCta={q ? () => setQ('') : empty?.onCta} />
      ) : (
        <div className="overflow-x-auto scroll-thin">
          <table className="w-full min-w-[640px] text-[13px]">
            <thead className="bg-surface-2 text-left text-xs font-semibold uppercase tracking-wide text-text-2">
              <tr>
                {cols.map((c) => (
                  <th key={c.key} scope="col" aria-sort={sort?.key === c.key ? (sort.dir === 1 ? 'ascending' : 'descending') : undefined} className={cn('px-4 py-3', c.align === 'right' && 'text-right')}>
                    <button className="inline-flex items-center gap-1 uppercase hover:text-heading" onClick={() => setSort(sort?.key === c.key ? (sort.dir === 1 ? { key: c.key, dir: -1 } : null) : { key: c.key, dir: 1 })}>
                      {c.label}{sort?.key === c.key ? (sort.dir === 1 ? <ArrowUp size={12} /> : <ArrowDown size={12} />) : <ArrowUpDown size={12} className="opacity-40" />}
                    </button>
                  </th>
                ))}
                {actions && <th className="px-4 py-3"><span className="sr-only">Actions</span></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {slice.map((r) => (
                <tr key={r.id} onClick={onRow ? () => onRow(r) : undefined} className={cn('transition-colors hover:bg-hover', onRow && 'cursor-pointer')}>
                  {cols.map((c) => <td key={c.key} className={cn('px-4 py-3 text-text', c.align === 'right' && 'text-right tabular-nums', c.className)}>{c.render ? c.render(r) : String((r as Record<string, unknown>)[c.key] ?? '')}</td>)}
                  {actions && <td className="px-4 py-3 text-right" onClick={(e) => e.stopPropagation()}><div className="flex justify-end gap-1">{actions(r)}</div></td>}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {data.length > pageSize && (
        <div className="flex items-center justify-between border-t border-line px-4 py-3 text-[13px] text-text-2">
          <span>{cur * pageSize + 1}–{Math.min(data.length, (cur + 1) * pageSize)} of {data.length}</span>
          <div className="flex items-center gap-1">
            <IconButton label="Previous page" icon={ChevronLeft} className="size-8" disabled={cur === 0} onClick={() => setPage(cur - 1)} />
            <span className="px-2">Page {cur + 1} / {pages}</span>
            <IconButton label="Next page" icon={ChevronRight} className="size-8" disabled={cur >= pages - 1} onClick={() => setPage(cur + 1)} />
          </div>
        </div>
      )}
    </Card>
  )
}
