'use client'
import { useEffect, useState } from 'react'

export function useMounted() {
  const [m, setM] = useState(false)
  useEffect(() => setM(true), [])
  return m
}
export { useLoading } from '@/components/blocks'
export { useDB } from '@/lib/db'
export { useAuth, useSetup } from '@/lib/session'
export { useUI } from '@/lib/ui'
