'use client'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import { CheckCircle2, AlertCircle, KeyRound } from 'lucide-react'
import { AuthShell, GoogleIcon, PasswordField, isEmail } from '@/components/auth/AuthShell'
import { Button, Input, toast } from '@/components/ui/core'
import { authStore, DEMO } from '@/lib/session'
import { hydrateAll } from '@/lib/ui'

export default function LoginPage() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [remember, setRemember] = useState(true)
  const [errs, setErrs] = useState<{ email?: string; password?: string }>({})
  const [formErr, setFormErr] = useState('')
  const [loading, setLoading] = useState<'' | 'form' | 'google'>('')
  const [done, setDone] = useState(false)

  useEffect(() => {
    hydrateAll()
    if (authStore.get().signedIn) { router.replace('/dashboard'); return }
    try { const r = localStorage.getItem('nexora-remember'); if (r) setEmail(r) } catch {}
  }, [router])

  const finish = (mail: string) => {
    authStore.set((s) => ({ ...s, signedIn: true, email: mail }))
    try { if (remember) localStorage.setItem('nexora-remember', mail); else localStorage.removeItem('nexora-remember') } catch {}
    setDone(true); toast('Signed in successfully.')
    setTimeout(() => router.push('/dashboard'), 900)
  }
  const submit = (e: React.FormEvent) => {
    e.preventDefault(); setFormErr('')
    const n: typeof errs = {}
    if (!email.trim()) n.email = 'Email is required.'; else if (!isEmail(email)) n.email = 'Enter a valid email address.'
    if (!password) n.password = 'Password is required.'
    setErrs(n)
    if (Object.keys(n).length) return
    setLoading('form')
    setTimeout(() => {
      const mail = email.trim().toLowerCase()
      const acc = authStore.get().account
      const ok = (mail === DEMO.email && password === DEMO.password) || (acc && acc.email.toLowerCase() === mail && acc.password === password)
      setLoading('')
      if (ok) finish(mail); else setFormErr('Invalid email or password. Please try again.')
    }, 900)
  }
  const google = () => { setLoading('google'); setTimeout(() => { setLoading(''); finish(authStore.get().account?.email ?? DEMO.email) }, 900) }

  if (done) return (
    <AuthShell>
      <div className="anim-pop flex flex-col items-center py-10 text-center" role="status">
        <div className="mb-4 grid size-14 place-items-center rounded-full bg-success-bg text-success"><CheckCircle2 size={28} /></div>
        <h1 className="text-2xl font-bold text-heading">You&apos;re signed in.</h1>
        <p className="mt-2 text-sm text-text-2">Taking you to your dashboard…</p>
      </div>
    </AuthShell>
  )
  return (
    <AuthShell title="Welcome back." subtitle="Sign in to your NEXORA operations command center.">
      <form onSubmit={submit} noValidate className="space-y-4">
        {formErr && <div role="alert" className="flex items-start gap-2 rounded-lg bg-danger-bg px-3 py-2.5 text-sm text-danger"><AlertCircle size={16} className="mt-0.5 shrink-0" />{formErr}</div>}
        <Input label="Work email" type="email" autoComplete="email" placeholder="you@company.com" value={email} onChange={(e) => setEmail(e.target.value)} error={errs.email} />
        <PasswordField label="Password" value={password} onChange={setPassword} error={errs.password} autoComplete="current-password" placeholder="Enter your password" />
        <div className="flex items-center justify-between text-sm">
          <label className="flex cursor-pointer items-center gap-2 text-text"><input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} className="size-4 accent-primary" />Remember me</label>
          <Link href="/forgot-password" className="font-medium text-primary hover:underline">Forgot password?</Link>
        </div>
        <Button type="submit" variant="primary" size="lg" className="w-full" loading={loading === 'form'}>{loading === 'form' ? 'Signing in…' : 'Sign In'}</Button>
        <div className="flex items-center gap-3 text-xs text-muted"><span className="h-px flex-1 bg-line" />OR<span className="h-px flex-1 bg-line" /></div>
        <Button type="button" size="lg" className="w-full" loading={loading === 'google'} onClick={google}>{loading !== 'google' && <GoogleIcon />}Sign in with Google</Button>
      </form>
      <div className="mt-5 flex items-center gap-3 rounded-xl border border-dashed border-line-strong bg-surface-2 p-3 text-[13px]">
        <KeyRound size={16} className="shrink-0 text-primary" />
        <div className="min-w-0 flex-1 text-text-2"><p className="font-medium text-heading">Demo credentials</p><p className="truncate">{DEMO.email} / {DEMO.password}</p></div>
        <Button type="button" size="sm" onClick={() => { setEmail(DEMO.email); setPassword(DEMO.password); setErrs({}); setFormErr('') }}>Fill</Button>
      </div>
      <p className="mt-6 text-center text-sm text-text-2">New to NEXORA? <Link href="/business-setup" className="font-semibold text-primary hover:underline">Create a New Workspace</Link></p>
    </AuthShell>
  )
}
