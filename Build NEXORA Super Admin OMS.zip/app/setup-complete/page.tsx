'use client'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import { ArrowRight, Check } from 'lucide-react'
import { ThemeToggle } from '@/components/auth/AuthShell'
import { Logo } from '@/components/layout/Sidebar'
import { SetupSummary } from '@/components/setup/StepReview'
import { Button } from '@/components/ui/core'
import { setupStore, useSetup } from '@/lib/session'
import { hydrateAll } from '@/lib/ui'

const COLORS = ['bg-primary', 'bg-purple', 'bg-cyan', 'bg-blue', 'bg-success']
export default function SetupCompletePage() {
  const router = useRouter()
  const s = useSetup()
  const [ready, setReady] = useState(false)
  useEffect(() => {
    hydrateAll()
    if (!setupStore.get().completed) router.replace('/business-setup'); else setReady(true)
  }, [router])
  if (!ready) return <div className="min-h-screen bg-bg" />
  return (
    <div className="relative min-h-screen overflow-hidden bg-bg">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-72" aria-hidden>
        {Array.from({ length: 28 }).map((_, i) => (
          <span key={i} className={`confetti-piece absolute top-0 h-2.5 w-1.5 rounded-sm opacity-0 ${COLORS[i % 5]}`} style={{ left: `${(i * 37) % 100}%`, animationDelay: `${(i % 9) * 0.18}s` }} />
        ))}
      </div>
      <header className="relative flex items-center justify-between px-5 py-4 sm:px-8"><Logo /><ThemeToggle /></header>
      <main className="relative mx-auto max-w-2xl px-5 pb-16 pt-6 text-center">
        <div className="anim-pop mx-auto mb-6 grid size-20 place-items-center rounded-full bg-success-bg text-success ai-pulse">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path className="draw-check" d="M5 12.5l4.5 4.5L19 7.5" /></svg>
        </div>
        <h1 className="anim-fade text-[30px] font-bold leading-tight text-heading sm:text-[36px]">Your NEXORA workspace is ready.</h1>
        <p className="anim-fade mt-3 text-sm text-text-2" style={{ animationDelay: '120ms' }}>{s.biz.name ? `${s.biz.name} is configured.` : 'Everything is configured.'} Create your admin account to start managing operations.</p>
        <div className="anim-fade mt-8 grid grid-cols-2 gap-3 text-left sm:grid-cols-4" style={{ animationDelay: '240ms' }}>
          {[['Channels', Object.values(s.channels).filter((v) => v === 'Connected' || v === 'Verified').length], ['Warehouses', s.warehouses.length], ['Carriers', s.logistics.partners.length], ['Plan', s.plan.id[0].toUpperCase() + s.plan.id.slice(1)]].map(([k, v]) => (
            <div key={k} className="rounded-xl border border-line bg-surface p-4"><p className="text-xs text-text-2">{k}</p><p className="mt-1 flex items-center gap-1.5 text-xl font-bold text-heading">{v}{typeof v === 'number' && v > 0 && <Check size={14} className="text-success" />}</p></div>
          ))}
        </div>
        <div className="mt-6 text-left"><SetupSummary s={s} /></div>
        <Button variant="primary" size="lg" className="mt-8 w-full sm:w-auto" onClick={() => router.push('/sign-up')}>CONTINUE TO ACCOUNT SETUP<ArrowRight size={16} /></Button>
      </main>
    </div>
  )
}
