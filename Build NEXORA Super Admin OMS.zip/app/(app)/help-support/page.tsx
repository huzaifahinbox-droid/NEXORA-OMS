import { HelpSupport } from '@/components/pages/HelpSupport'

export default function Page() {
  return <HelpSupport />
}
