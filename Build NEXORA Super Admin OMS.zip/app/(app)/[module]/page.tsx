import { redirect } from 'next/navigation'
import { MODULES } from '@/lib/nav'

export const dynamicParams = false
export const generateStaticParams = () => MODULES.map((m) => ({ module: m.slug }))

export default async function ModuleIndex({ params }: { params: Promise<{ module: string }> }) {
  const { module } = await params
  redirect(`/${module}/overview`)
}
