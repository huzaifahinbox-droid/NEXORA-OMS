import { MODULES } from '@/lib/nav'
import { ModuleScreen } from '@/components/modules/ModuleScreen'

export const dynamicParams = false
export const generateStaticParams = () => MODULES.flatMap((m) => m.pages.map((p) => ({ module: m.slug, page: p.slug })))

export default async function ModulePage({ params }: { params: Promise<{ module: string; page: string }> }) {
  const { module, page } = await params
  return <ModuleScreen module={module} page={page} />
}
