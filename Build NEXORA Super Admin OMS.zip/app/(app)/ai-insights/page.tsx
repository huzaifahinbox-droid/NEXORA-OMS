import { AIInsights } from '@/components/pages/AIInsights'

export default function Page() {
  return <AIInsights />
}
