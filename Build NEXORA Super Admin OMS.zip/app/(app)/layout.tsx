'use client'
import { useEffect, useState } from 'react'
import { useRouter, usePathname } from 'next/navigation'
import { Sidebar } from '@/components/layout/Sidebar'
import { Topbar } from '@/components/layout/Topbar'
import { Copilot } from '@/components/layout/Copilot'
import { PageSkeleton } from '@/components/ui/core'
import { authStore } from '@/lib/session'
import { hydrateAll, ui } from '@/lib/ui'

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const path = usePathname()
  const [ready, setReady] = useState(false)
  useEffect(() => {
    hydrateAll()
    if (!authStore.get().signedIn) { router.replace('/login'); return }
    if (window.innerWidth < 1100) ui.set({ collapsed: true })
    setReady(true)
  }, [router])
  if (!ready) return <div className="p-8"><PageSkeleton /></div>
  return (
    <div className="flex h-screen overflow-hidden bg-bg">
      <Sidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar />
        <main id="main" key={path} className="anim-fade flex-1 overflow-y-auto scroll-thin p-4 md:p-5 lg:p-6">
          <div className="mx-auto max-w-[1440px]">{children}</div>
        </main>
      </div>
      <Copilot />
    </div>
  )
}
