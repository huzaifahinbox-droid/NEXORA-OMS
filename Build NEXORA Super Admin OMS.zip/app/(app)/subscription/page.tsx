import { Subscription } from '@/components/pages/Subscription'

export default function Page() {
  return <Subscription />
}
