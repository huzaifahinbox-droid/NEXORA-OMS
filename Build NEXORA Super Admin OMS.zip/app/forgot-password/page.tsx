'use client'
import Link from 'next/link'
import { useState } from 'react'
import { ArrowLeft, MailCheck } from 'lucide-react'
import { AuthShell, isEmail } from '@/components/auth/AuthShell'
import { Button, Input, toast } from '@/components/ui/core'
import { authStore } from '@/lib/session'

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('')
  const [err, setErr] = useState('')
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)
  const send = (resend = false) => {
    if (!email.trim()) { setErr('Email is required.'); return }
    if (!isEmail(email)) { setErr('Enter a valid email address.'); return }
    setErr(''); setLoading(true)
    setTimeout(() => {
      authStore.set((s) => ({ ...s, resetUsed: false }))
      setLoading(false); setSent(true)
      toast(resend ? 'Reset link sent again.' : 'Reset link sent.')
    }, 900)
  }
  if (sent) return (
    <AuthShell>
      <div className="anim-pop text-center" role="status">
        <div className="mx-auto mb-4 grid size-14 place-items-center rounded-full bg-primary-light text-primary"><MailCheck size={26} /></div>
        <h1 className="text-[28px] font-bold text-heading">Check your inbox.</h1>
        <p className="mt-2 text-sm text-text-2">We&apos;ve sent a password reset link to <span className="font-medium text-heading">{email}</span>.</p>
        <div className="mt-6 space-y-3">
          <Link href="/reset-password" className="inline-flex h-11 w-full items-center justify-center rounded-lg bg-primary px-6 text-[15px] font-medium text-white transition-colors hover:bg-primary-hover">Open reset link (demo)</Link>
          <Button size="lg" className="w-full" loading={loading} onClick={() => send(true)}>Resend link</Button>
          <Link href="/login" className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"><ArrowLeft size={14} />Back to Login</Link>
        </div>
      </div>
    </AuthShell>
  )
  return (
    <AuthShell title="Forgot your password?" subtitle="Enter your work email and we'll send you a link to reset it.">
      <form onSubmit={(e) => { e.preventDefault(); send() }} noValidate className="space-y-4">
        <Input label="Work email" type="email" autoComplete="email" placeholder="you@company.com" value={email} onChange={(e) => { setEmail(e.target.value); setErr('') }} error={err} />
        <Button type="submit" variant="primary" size="lg" className="w-full" loading={loading}>Send Reset Link</Button>
      </form>
      <p className="mt-6 text-center text-sm"><Link href="/login" className="inline-flex items-center gap-1.5 font-medium text-primary hover:underline"><ArrowLeft size={14} />Back to Login</Link></p>
    </AuthShell>
  )
}
