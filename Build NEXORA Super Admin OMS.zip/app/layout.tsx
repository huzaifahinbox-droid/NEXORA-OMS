import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import '@/styles/globals.css'
import { Providers, themeScript } from '@/components/theme'
import { Toaster } from '@/components/ui/core'

const inter = Inter({ subsets: ['latin'], variable: '--font-inter', weight: ['400', '500', '600', '700'] })

export const metadata: Metadata = { title: 'NEXORA — Super Admin OMS', icons: { icon: '/favicon.svg' }, description: 'AI-powered order management and operations command center.' }

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={inter.variable} suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: themeScript }} /></head>
      <body>
        <Providers>{children}<Toaster /></Providers>
      </body>
    </html>
  )
}
