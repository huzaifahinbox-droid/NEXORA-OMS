'use client'
import { useState } from 'react'
import Link from 'next/link'
import { ArrowLeft, CheckCircle2 } from 'lucide-react'
import { Logo } from '@/components/layout/Sidebar'
import { ThemeToggle } from '@/components/marketing/Header'
import { Button, Card, Input, Select, Textarea } from '@/components/ui/core'

const SIZES = ['1-10', '11-50', '51-200', '201-1000', '1000+']
const INTERESTS = ['Order Management', 'Procurement', 'Inventory & Forecasting', 'Warehouse & Logistics', 'AI Insights', 'Full platform']
const empty = { name: '', email: '', company: '', phone: '', size: '', interest: '', date: '', message: '' }
type F = typeof empty

export default function BookDemoPage() {
  const [f, setF] = useState<F>(empty)
  const [err, setErr] = useState<Partial<F>>({})
  const [loading, setLoading] = useState(false)
  const [done, setDone] = useState(false)
  const set = (k: keyof F) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => { setF({ ...f, [k]: e.target.value }); if (err[k]) setErr({ ...err, [k]: undefined }) }

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    const x: Partial<F> = {}
    if (f.name.trim().length < 2) x.name = 'Enter your full name'
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(f.email)) x.email = 'Enter a valid work email'
    if (!f.company.trim()) x.company = 'Company is required'
    if (f.phone && !/^[+\d][\d\s()-]{6,}$/.test(f.phone)) x.phone = 'Enter a valid phone number'
    if (!f.size) x.size = 'Select company size'
    if (!f.interest) x.interest = 'Select an area of interest'
    if (f.date && new Date(f.date) < new Date(new Date().toDateString())) x.date = 'Choose a future date'
    setErr(x)
    if (Object.keys(x).length) return
    setLoading(true)
    setTimeout(() => { setLoading(false); setDone(true) }, 1200)
  }

  const summary: [string, string][] = [['Name', f.name], ['Work email', f.email], ['Company', f.company], ['Company size', f.size], ['Interest', f.interest], ['Preferred date', f.date || 'Flexible']]

  return (
    <div className="min-h-screen bg-bg">
      <header className="border-b border-line bg-surface">
        <div className="mx-auto flex h-[68px] max-w-5xl items-center justify-between px-4 sm:px-6">
          <Link href="/" aria-label="NEXORA home"><Logo /></Link>
          <div className="flex items-center gap-2"><Link href="/" className="inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium text-text-2 hover:bg-hover hover:text-heading"><ArrowLeft size={16} />Back to home</Link><ThemeToggle /></div>
        </div>
      </header>
      <main className="mx-auto max-w-2xl px-4 py-12 sm:px-6 sm:py-16">
        {done ? (
          <Card className="anim-pop p-8 text-center sm:p-10">
            <div className="mx-auto grid size-14 place-items-center rounded-full bg-success-bg text-success"><CheckCircle2 size={28} /></div>
            <h1 className="mt-5 text-2xl font-bold text-heading">Your demo request is confirmed</h1>
            <p className="mt-2 text-text-2">Thanks, {f.name.split(' ')[0]}. A specialist will email {f.email} within one business day.</p>
            <dl className="mt-7 divide-y divide-line rounded-xl border border-line bg-surface-2 text-left text-sm">
              {summary.map(([k, v]) => <div key={k} className="flex justify-between gap-4 px-4 py-2.5"><dt className="text-text-2">{k}</dt><dd className="truncate font-medium text-heading">{v}</dd></div>)}
            </dl>
            <Link href="/" className="mt-7 inline-flex h-10 items-center justify-center rounded-lg bg-primary px-5 text-sm font-medium text-white hover:bg-primary-hover">Back to home</Link>
          </Card>
        ) : (
          <>
            <h1 className="text-3xl font-bold tracking-tight text-heading">Book a demo</h1>
            <p className="mt-2 text-text-2">Tell us about your operation and we will tailor a 30 minute walkthrough.</p>
            <Card className="mt-8 p-6 sm:p-8">
              <form onSubmit={submit} noValidate className="grid gap-5 sm:grid-cols-2">
                <Input label="Full name" required value={f.name} onChange={set('name')} error={err.name} autoComplete="name" />
                <Input label="Work email" type="email" required value={f.email} onChange={set('email')} error={err.email} autoComplete="email" />
                <Input label="Company" required value={f.company} onChange={set('company')} error={err.company} autoComplete="organization" />
                <Input label="Phone" type="tel" value={f.phone} onChange={set('phone')} error={err.phone} autoComplete="tel" />
                <Select label="Company size" required options={SIZES} value={f.size} onChange={set('size')} error={err.size} />
                <Select label="Area of interest" required options={INTERESTS} value={f.interest} onChange={set('interest')} error={err.interest} />
                <div className="sm:col-span-2"><Input label="Preferred date" type="date" value={f.date} onChange={set('date')} error={err.date} /></div>
                <div className="sm:col-span-2"><Textarea label="Message" value={f.message} onChange={set('message')} placeholder="Anything we should know before the call?" /></div>
                <div className="sm:col-span-2"><Button type="submit" variant="primary" size="lg" loading={loading} className="w-full">{loading ? 'Submitting…' : 'Request demo'}</Button></div>
              </form>
            </Card>
          </>
        )}
      </main>
    </div>
  )
}
