'use client'
import Link from 'next/link'
import { useSearchParams } from 'next/navigation'
import { Suspense, useEffect, useState } from 'react'
import { CheckCircle2, TimerOff } from 'lucide-react'
import { AuthShell, PasswordField, passwordScore } from '@/components/auth/AuthShell'
import { Button, toast } from '@/components/ui/core'
import { authStore, useAuth } from '@/lib/session'
import { hydrateAll } from '@/lib/ui'

function Reset() {
  const params = useSearchParams()
  const { resetUsed } = useAuth()
  const [pw, setPw] = useState('')
  const [cf, setCf] = useState('')
  const [errs, setErrs] = useState<{ pw?: string; cf?: string }>({})
  const [loading, setLoading] = useState(false)
  const [done, setDone] = useState(false)
  useEffect(() => { hydrateAll() }, [])
  const expired = !done && (params.get('expired') === '1' || resetUsed)

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    const n: typeof errs = {}
    if (!pw) n.pw = 'New password is required.'; else if (pw.length < 8) n.pw = 'Use at least 8 characters.'; else if (passwordScore(pw) < 3) n.pw = 'Add uppercase, numbers or symbols for a stronger password.'
    if (cf !== pw) n.cf = 'Passwords do not match.'
    setErrs(n)
    if (Object.keys(n).length) return
    setLoading(true)
    setTimeout(() => {
      authStore.set((s) => ({ ...s, resetUsed: true, account: s.account ? { ...s.account, password: pw } : s.account }))
      setLoading(false); setDone(true); toast('Password updated.')
    }, 900)
  }
  if (done) return (
    <AuthShell>
      <div className="anim-pop text-center" role="status">
        <div className="mx-auto mb-4 grid size-14 place-items-center rounded-full bg-success-bg text-success"><CheckCircle2 size={28} /></div>
        <h1 className="text-[28px] font-bold text-heading">Password updated.</h1>
        <p className="mt-2 text-sm text-text-2">Your password has been changed. You can now sign in.</p>
        <Link href="/login" className="mt-6 inline-flex h-11 w-full items-center justify-center rounded-lg bg-primary px-6 text-[15px] font-medium text-white hover:bg-primary-hover">Back to Login</Link>
      </div>
    </AuthShell>
  )
  if (expired) return (
    <AuthShell>
      <div className="anim-pop text-center" role="alert">
        <div className="mx-auto mb-4 grid size-14 place-items-center rounded-full bg-warning-bg text-warning"><TimerOff size={26} /></div>
        <h1 className="text-[28px] font-bold text-heading">Your password reset link has expired.</h1>
        <p className="mt-2 text-sm text-text-2">For your security, reset links can only be used once and expire quickly.</p>
        <div className="mt-6 space-y-3">
          <Link href="/forgot-password" className="inline-flex h-11 w-full items-center justify-center rounded-lg bg-primary px-6 text-[15px] font-medium text-white hover:bg-primary-hover">Request New Link</Link>
          <Link href="/login" className="inline-flex h-11 w-full items-center justify-center rounded-lg border border-line-strong bg-surface px-6 text-[15px] font-medium text-heading hover:bg-hover">Back to Login</Link>
        </div>
      </div>
    </AuthShell>
  )
  return (
    <AuthShell title="Set a new password." subtitle="Choose a strong password you haven't used before.">
      <form onSubmit={submit} noValidate className="space-y-4">
        <PasswordField label="New password" strength value={pw} onChange={(v) => { setPw(v); setErrs((x) => ({ ...x, pw: '' })) }} error={errs.pw} autoComplete="new-password" />
        <PasswordField label="Confirm password" value={cf} onChange={(v) => { setCf(v); setErrs((x) => ({ ...x, cf: '' })) }} error={errs.cf} autoComplete="new-password" />
        <Button type="submit" variant="primary" size="lg" className="w-full" loading={loading}>Reset Password</Button>
      </form>
      <p className="mt-6 text-center text-sm"><Link href="/login" className="font-medium text-primary hover:underline">Back to Login</Link></p>
    </AuthShell>
  )
}
export default function ResetPasswordPage() { return <Suspense fallback={null}><Reset /></Suspense> }
