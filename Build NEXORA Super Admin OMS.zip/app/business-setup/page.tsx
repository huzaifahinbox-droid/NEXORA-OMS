import { Wizard } from '@/components/setup/Wizard'

export default function BusinessSetupPage() { return <Wizard /> }
