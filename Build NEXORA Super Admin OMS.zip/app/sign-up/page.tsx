'use client'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import { AuthShell, GoogleIcon, PasswordField, isEmail, passwordScore } from '@/components/auth/AuthShell'
import { Button, Input, toast } from '@/components/ui/core'
import { authStore, setupStore } from '@/lib/session'
import { hydrateAll } from '@/lib/ui'

export default function SignUpPage() {
  const router = useRouter()
  const [f, setF] = useState({ name: '', email: '', phone: '', password: '', confirm: '', terms: false })
  const [errs, setErrs] = useState<Record<string, string>>({})
  const [loading, setLoading] = useState<'' | 'form' | 'google'>('')
  useEffect(() => {
    hydrateAll()
    if (authStore.get().signedIn) { router.replace('/dashboard'); return }
    const b = setupStore.get().biz
    setF((x) => ({ ...x, email: x.email || b.email, phone: x.phone || b.phone }))
  }, [router])
  const set = (k: keyof typeof f, v: string | boolean) => { setF((x) => ({ ...x, [k]: v })); setErrs((e) => ({ ...e, [k]: '' })) }
  const create = (name: string, email: string, password: string) => {
    authStore.set((s) => ({ ...s, account: { name, email: email.trim().toLowerCase(), password }, signedIn: false, resetUsed: false, profile: { ...s.profile, name, email: email.trim().toLowerCase(), phone: f.phone || s.profile.phone } }))
    toast('Account created. Please sign in.')
    router.push('/login')
  }
  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    const n: Record<string, string> = {}
    if (f.name.trim().length < 2) n.name = 'Full name is required.'
    if (!f.email.trim()) n.email = 'Work email is required.'; else if (!isEmail(f.email)) n.email = 'Enter a valid email address.'
    if (!/^[+\d][\d\s-]{6,}$/.test(f.phone.trim())) n.phone = 'Enter a valid phone number.'
    if (!f.password) n.password = 'Password is required.'; else if (f.password.length < 8) n.password = 'Use at least 8 characters.'; else if (passwordScore(f.password) < 3) n.password = 'Add uppercase, numbers or symbols for a stronger password.'
    if (f.confirm !== f.password) n.confirm = 'Passwords do not match.'
    if (!f.terms) n.terms = 'You must accept the terms to continue.'
    setErrs(n)
    if (Object.keys(n).length) return
    setLoading('form')
    setTimeout(() => create(f.name.trim(), f.email, f.password), 800)
  }
  const google = () => { setLoading('google'); setTimeout(() => create(f.name.trim() || 'Google User', f.email || 'google.user@gmail.com', 'Nexora@2026'), 900) }
  return (
    <AuthShell title="Create your account." subtitle="Set up your admin account to access the new workspace." wide>
      <form onSubmit={submit} noValidate className="space-y-4">
        <Input label="Full name" required autoComplete="name" value={f.name} onChange={(e) => set('name', e.target.value)} error={errs.name} placeholder="Aditi Rao" />
        <div className="grid gap-4 sm:grid-cols-2">
          <Input label="Work email" required type="email" autoComplete="email" value={f.email} onChange={(e) => set('email', e.target.value)} error={errs.email} placeholder="you@company.com" />
          <Input label="Phone" required type="tel" autoComplete="tel" value={f.phone} onChange={(e) => set('phone', e.target.value)} error={errs.phone} placeholder="+91 98765 43210" />
        </div>
        <PasswordField label="Password" strength value={f.password} onChange={(v) => set('password', v)} error={errs.password} autoComplete="new-password" placeholder="At least 8 characters" />
        <PasswordField label="Confirm password" value={f.confirm} onChange={(v) => set('confirm', v)} error={errs.confirm} autoComplete="new-password" placeholder="Re-enter password" />
        <div>
          <label className="flex cursor-pointer items-start gap-2 text-sm text-text"><input type="checkbox" checked={f.terms} onChange={(e) => set('terms', e.target.checked)} className="mt-0.5 size-4 accent-primary" />I agree to the Terms of Service and Privacy Policy.</label>
          {errs.terms && <p role="alert" className="mt-1 text-xs text-danger">{errs.terms}</p>}
        </div>
        <Button type="submit" variant="primary" size="lg" className="w-full" loading={loading === 'form'}>Create Account</Button>
        <div className="flex items-center gap-3 text-xs text-muted"><span className="h-px flex-1 bg-line" />OR<span className="h-px flex-1 bg-line" /></div>
        <Button type="button" size="lg" className="w-full" loading={loading === 'google'} onClick={google}>{loading !== 'google' && <GoogleIcon />}Sign up with Google</Button>
      </form>
      <p className="mt-6 text-center text-sm text-text-2">Already have an account? <Link href="/login" className="font-semibold text-primary hover:underline">Sign in</Link></p>
    </AuthShell>
  )
}
